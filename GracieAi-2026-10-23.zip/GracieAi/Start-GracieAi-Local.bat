@echo off
cd /d "%~dp0"
title Gracie - Local assistant
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js LTS first.
 pause
 exit /b 1
)
if not exist "node_modules\" (
 call npm ci --no-audit --no-fund
 if errorlevel 1 exit /b 1
)
set "GRACIE_LOCAL_ONLY=1"
set "OLLAMA_MODEL=gracie-assistant:latest"
set "GRACIE_AUTOSTART_OLLAMA=1"
set "VITE_DEV_SERVER_URL="
node scripts\setup-local.cjs
if errorlevel 1 (
 echo Local setup failed. Install qwen3.5:4b with Ollama, then try again.
 pause
 exit /b 1
)
if not exist "dist\index.html" (
 call npm run build
 if errorlevel 1 exit /b 1
)
call npm start
pause
