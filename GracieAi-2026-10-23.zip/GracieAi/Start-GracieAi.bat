@echo off
cd /d "%~dp0"
title GracieAi
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js LTS from https://nodejs.org/ then try again.
 pause
 exit /b 1
)
if not exist ".env.local" copy ".env.example" ".env.local" >nul
if not exist "node_modules\" (
 call npm ci
 if errorlevel 1 (
  pause
  exit /b 1
 )
)
if not exist "dist\index.html" (
 call npm run build
 if errorlevel 1 exit /b 1
)
set "VITE_DEV_SERVER_URL="
call npm start
pause
