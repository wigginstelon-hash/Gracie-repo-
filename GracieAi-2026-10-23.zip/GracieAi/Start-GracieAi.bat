@echo off
cd /d "%~dp0"
set "PATH=C:\Program Files\nodejs;C:\Program Files\Git\cmd;%PATH%"
call "%~dp0Start-GracieAi-Local.bat"
