# GracieAi for Windows

Electron desktop AI companion with Ollama chat, project tools, app building and an Ollama app launcher. OpenAI voice is separately selected and requires your own API key. Fully local voice is not implemented.

## Start

1. Extract this entire ZIP to a writable folder.
2. Install Node.js LTS (https://nodejs.org/) and Ollama (https://ollama.com/).
3. Run `ollama pull qwen3.5:4b` in a terminal.
4. Double-click `Start-GracieAi.bat`. The first run downloads npm dependencies and Electron. Internet access is required for installation.
5. In Settings choose Ollama and `qwen3.5:4b`. Choose a coding folder and enable only the project permissions you need.

The optional `.env.local` is copied from `.env.example` on first launch. Put your own OpenAI key there only if using OpenAI features. Never commit that file.

## Contents and privacy

Includes source, Electron scripts, tests and the built web interface. Excludes API keys, conversations, generated projects, personal settings, model weights, backups and node_modules. Gracie creates fresh data locally. This ZIP is not a standalone Windows executable; Node.js and first-run dependency installation are required.

The Ollama app launcher opens third-party applications with the selected model. Each tool owns its configuration and may require installation. Launching a terminal is not proof the application completed setup.

## Development

`npm ci`, `npm run build`, `npm test`.

## License

See LICENSE for the license supplied with this project.
