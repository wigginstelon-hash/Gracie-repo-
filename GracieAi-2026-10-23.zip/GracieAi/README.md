# GracieAi for Windows

Electron desktop AI companion with Ollama chat, project tools, app building and an Ollama app launcher. OpenAI voice is separately selected and requires your own API key. Local English dictation and Windows speech playback are supported after setup.

## Start

1. Extract this entire ZIP to a writable folder.
2. Install Node.js LTS (https://nodejs.org/) and Ollama (https://ollama.com/).
3. Run `ollama pull qwen3.5:4b` in a terminal.
4. Double-click `Start-GracieAi.bat`. The first run downloads npm dependencies and Electron. Internet access is required for installation.
5. In Settings choose Ollama and `qwen3.5:4b`. Choose a coding folder and enable only the project permissions you need.

The optional `.env.local` is copied from `.env.example` on first launch. Put your own OpenAI key there only if using OpenAI features. Never commit that file.

## Contents and privacy

Includes source, Electron scripts, tests and the built web interface. Excludes API keys, conversations, generated projects, personal settings, model weights, backups and node_modules. Gracie creates fresh data locally. This ZIP is not a standalone Windows executable; Node.js and first-run dependency installation are required.

The Ollama app launcher opens third-party applications with the selected model. Each tool owns its configuration and may require installation. Launching a terminal is not proof the application completed setup.

## Development

`npm ci`, `npm run build`, `npm test`.

## License

See LICENSE for the license supplied with this project.

Run `npm run package` to build, run every test, and regenerate the ZIP and SHA-256 file in the parent folder. The package script includes an explicit list of source and build files; it excludes installed dependencies and private data.

## Dedicated local Gracie

Double-click Start-GracieAi-Local.bat. Setup checks Ollama and creates gracie-assistant:latest from the already-installed qwen3.5:4b. It reuses those weights with Gracie's identity and modest context settings; it is not training a foundation model. If the base is missing, setup stops and tells you to install it. To create the profile from a different compact installed base, run npm run setup:local -- <exact-model-tag> before first launch. An existing Gracie profile is preserved.

Local assistant mode blocks cloud inference, OpenAI voice, online model discovery/downloads, and automatic web research in the app. Typed chat, local document/image attachments, persistent memory, project helpers and app building use local weights. Explicit browser tasks and trusted project scripts may still access the network; this mode is not a network sandbox. Local microphone transcription and Windows speech playback are supported after local speech setup.

Use npm run doctor for connection, model and memory diagnostics. Conversation data stays in data/ next to this copy of the app. Keep that folder when updating; the downloadable ZIP never includes private data. Close Gracie before copying an older data/ folder into a new install, and keep the original as a backup.


## Local speech on Windows

Run `npm run setup:speech` once with 64-bit Python 3.14 installed. Setup downloads a small English Whisper model and pinned Python dependencies; runtime transcription then uses CPU int8 and local files only. No OpenAI key or hosted audio API is used. Restart Gracie afterward.

The microphone records at most 45 seconds, transcribes on this PC, and inserts the text into the composer for review. It does not automatically send text or execute tools. The speaker reads up to 4,000 characters from the latest reply using an installed Windows voice. Stop cancels recording, transcription or playback. Raw recordings and synthesized speech files are temporary and removed after the request. Restarting the app stops active speech work. English is the supported transcription language.

`Start-GracieAi.bat` now opens local mode by default. `Start-GracieAi-Online.bat` keeps the optional online provider available. Existing API keys and data are preserved.
