import { useCallback, useEffect, useRef, useState } from "react";
import { isAppBuildRequest } from './lib/build-intent.mjs';
import { ArrowUp, BrainCircuit, Check, ChevronDown, ChevronRight, ClipboardPaste, Code2, Expand, FolderOpen, History, Keyboard, LayoutGrid, Link2, MessageCircle, Mic, MicOff, Minus, Monitor, MonitorCog, MoreHorizontal, Paperclip, PanelsTopLeft, Pause, Play, Plus, Settings2, Sparkles, Square, X } from "lucide-react";
import { OverlayDialog } from "./components/OverlayDialog";
import { ActionMenu } from "./components/ActionMenu";
import { ModelFinder } from "./components/ModelFinder";
import { ChatPanel } from "./components/ChatPanel";
import { OllamaApps } from "./components/OllamaApps";
import { ProjectsPanel } from "./components/ProjectsPanel";
import { WorkspaceControls } from "./components/WorkspaceControls";
import { ArtifactPanel } from "./components/ArtifactPanel";
import { GracieFace } from "./components/GracieFace";
import { newEntry, GracieRealtimeClient, type MouthShape, type GracieConnectionState, type GracieMood, type TranscriptEntry } from "./lib/realtime";
import type { GracieArtifact, OllamaStatus, MemorySnapshot, SavedEntry, AttachmentInfo, ResearchSource, PausedWork, AppProject } from "./vite-env";

type GracieMode = "display" | "computer";
type ChatProvider = "openai" | "ollama";

export default function App() {
  const [activePage,setActivePage]=useState<'chat'|'apps'|'sources'|'activity'|'canvas'>('chat');
  const [showSettings,setShowSettings]=useState(false);
  const [showPortrait,setShowPortrait]=useState(false);
  const composerRef=useRef<HTMLTextAreaElement>(null);
  const [connectionState, setConnectionState] = useState<GracieConnectionState>("idle");
  const [mood, setMood] = useState<GracieMood>("idle");
  const [mode, setMode] = useState<GracieMode>("display");
  const [artifact, setArtifact] = useState<GracieArtifact | null>(null);
  const [artifactVisible, setArtifactVisible] = useState(true);
  const [artifactFullscreen, setArtifactFullscreen] = useState(false);
  const [showLog, setShowLog] = useState(false);
  const [showTypeInput, setShowTypeInput] = useState(true);
  const [mouthShape, setMouthShape] = useState<MouthShape>({ open: 0, width: 0.18, round: 0, teeth: 0 });
  const [transcript, setTranscript] = useState<TranscriptEntry[]>([
    newEntry("system", "Gracie is ready. Your conversations and preferences are saved for future chats."),
  ]);
  const [status, setStatus] = useState("Idle");
  const [textPrompt, setTextPrompt] = useState("");
  const [expandedComposer,setExpandedComposer]=useState(false);
  const [composeIntent,setComposeIntent]=useState<'chat'|'build'|'agent'>('chat');
  useEffect(()=>{const field=composerRef.current;if(field){field.style.maxHeight=(expandedComposer?420:220)+'px';field.style.height='auto';field.style.height=Math.min(expandedComposer?420:220,Math.max(64,field.scrollHeight))+'px';}},[textPrompt,showTypeInput,mode,expandedComposer]);
  const [chatProvider, setChatProvider] = useState<ChatProvider>(() => saved("provider", "ollama") === "openai" ? "openai" : "ollama");
  const [useLocalTools, setUseLocalTools] = useState(() => saved("computerTools", "true") !== "false");
  const [computerActive,setComputerActive]=useState(false);
  useEffect(()=>window.gracie.onComputerState(state=>setComputerActive(state.mode==="computer")),[]);
  useEffect(()=>save("computerTools",String(useLocalTools)),[useLocalTools]);
  const [fastMode, setFastMode] = useState(() => saved('fastMode', 'true') !== 'false');
  const [codingFolder, setCodingFolder] = useState("");
  const [allowProjectEdits,setAllowProjectEdits]=useState(false);
  const [allowProjectChecks,setAllowProjectChecks]=useState(false);
  function syncCodingFolder(result:{folder:string;allowEdits?:boolean;allowChecks?:boolean}){setCodingFolder(result.folder);setAllowProjectEdits(Boolean(result.allowEdits));setAllowProjectChecks(Boolean(result.allowChecks));}
  const [includeSavedContext, setIncludeSavedContext] = useState(false);
  const [showModelFinder, setShowModelFinder] = useState(false);
  const [ollamaStatus, setOllamaStatus] = useState<OllamaStatus | null>(null);
  const [memory, setMemory] = useState<MemorySnapshot | null>(null);
  const [memoryError, setMemoryError] = useState("");
  const [showMemory, setShowMemory] = useState(false);
  const [memoryText, setMemoryText] = useState("");
  const [editingMemory, setEditingMemory] = useState<string | undefined>();
  const [memoryBusy, setMemoryBusy] = useState(false);
  const lastVoiceStatus = useRef("");
  const [model, setModel] = useState(() => saved("model", ""));
  const selectedModelRef = useRef(model);
  selectedModelRef.current = model;
  const [sending, setSending] = useState(false);
  const [chatError, setChatError] = useState("");
  const [attachedFiles,setAttachedFiles]=useState<AttachmentInfo[]>([]);
  const [referenceLinks,setReferenceLinks]=useState<string[]>([]);
  const [researchMode,setResearchMode]=useState<'auto'|'off'|'search'|'deep'>(()=>{const value=saved('researchMode','auto');return ['off','search','deep'].includes(value)?value as 'off'|'search'|'deep':'auto';});
  useEffect(()=>save('researchMode',researchMode),[researchMode]);
  const [sources,setSources]=useState<ResearchSource[]>([]);
  const [pausedWork,setPausedWork]=useState<PausedWork|null>(null);
  const [workBusy,setWorkBusy]=useState(false);
  const [projects,setProjects]=useState<AppProject[]>([]);
  const [appOutputFolder,setAppOutputFolder]=useState('');
  const [projectId,setProjectId]=useState(()=>saved('projectId',''));
  const [workMode,setWorkMode]=useState<'chat'|'build'|'agent'>('chat');
  const sendingRef = useRef(false);
  const sendFinishedRef=useRef<Promise<void>>(Promise.resolve());
  const updatingBuildRef=useRef(false);
  const clientRef = useRef<GracieRealtimeClient | null>(null);

  const isConnected = connectionState === "connected";
  const localModeInitialized=useRef(false);
  const localOnly=ollamaStatus?.localOnly===true;
  const selectedCloud = /(?::cloud|-cloud)$/.test(model) || Boolean(ollamaStatus?.modelDetails?.find(item => item.name === model)?.cloud);

  const refreshOllamaStatus = useCallback(async () => {
    const nextStatus: OllamaStatus = await window.gracie.getOllamaStatus().catch((error) => ({ ok: false, available: false, url: "", models: [], message: String(error), defaultModel: "" }));
    setOllamaStatus(nextStatus);
    if(nextStatus.localOnly){setChatProvider('ollama');setResearchMode('off');setIncludeSavedContext(false);}
    if (nextStatus.available) {
      if(nextStatus.localOnly&&!localModeInitialized.current){localModeInitialized.current=true;const savedLocal=saved('localModel','');setModel(nextStatus.models.includes(savedLocal)?savedLocal:nextStatus.defaultModel||'');}
      else setModel(current=>current||nextStatus.defaultModel||'');
    }
    return nextStatus;
  }, []);

  useEffect(() => {
    void refreshOllamaStatus();
    void window.gracie.getCodingFolder().then(syncCodingFolder).catch(() => {});
    void window.gracie.getPausedWork().then(saved=>{setPausedWork(saved);if(saved){setAttachedFiles(saved.files);setReferenceLinks(saved.links);setSources(saved.sources);setModel(current=>saved.model||current);setFastMode(saved.fastMode);setUseLocalTools(saved.useLocalTools);setResearchMode(saved.researchMode);setProjectId(saved.projectId||'');setWorkMode(saved.workMode||'chat');}}).catch(error=>setChatError(String(error)));
    void refreshProjects();
    void window.gracie.getAppOutputSettings().then(result=>setAppOutputFolder(result.folder)).catch(error=>setChatError(String(error)));
    void refreshMemory(true);
    const timer = window.setInterval(() => void refreshOllamaStatus(), 30000);
    return () => { clearInterval(timer); clientRef.current?.disconnect(); };
  }, []);

  useEffect(() => { if(ollamaStatus?.localOnly)save("localModel",model);else if(ollamaStatus){save("provider",chatProvider);save("model",model);} }, [chatProvider, model, ollamaStatus]);
  useEffect(() => { save('fastMode', String(fastMode)); }, [fastMode]);
  useEffect(()=>{save('projectId',projectId);},[projectId]);
  async function refreshProjects(){try{setProjects(await window.gracie.listProjects());}catch(error){setChatError(String(error));}}
  async function chooseAppOutputFolder(){setWorkBusy(true);try{const result=await window.gracie.chooseAppOutputFolder();setAppOutputFolder(result.folder);setStatus('Finished apps will be saved in this folder. Existing apps stay where they are.');}catch(error){setChatError(String(error));}finally{setWorkBusy(false);}}
  async function projectAction(id:string,kind:'open'|'folder'|'source'|'windows'){
    setWorkBusy(true);setChatError('');setStatus('Preparing your app folder…');try{if(kind==='open'){await window.gracie.openProject(id);setStatus('Your finished app is running.');}else if(kind==='folder'){await window.gracie.showProjectFolder(id);setStatus('App folder opened. Double-click GracieApp.exe to test it.');}else{const result=await window.gracie.downloadProject(id,kind);if(result.saved)setStatus('Saved your '+(kind==='windows'?'Windows app':'app source')+' ZIP.');}}catch(error){setChatError(String(error));}finally{setWorkBusy(false);void refreshProjects();}
  }

  function displayEntry(entry: SavedEntry): TranscriptEntry { return { ...entry, at: new Date(entry.at).toLocaleString() }; }
  async function refreshMemory(restore = false) {
    try { const next = await window.gracie.getMemory(); setMemory(next); setMemoryError(next.warning); if (restore) setTranscript(next.entries.map(displayEntry)); }
    catch (error) { setMemoryError("Could not read saved chats: " + String(error)); }
  }
  async function recordEntry(entry: TranscriptEntry, provider = "openai") {
    try { const savedEntry = await window.gracie.recordEntry({ role: entry.role, text: entry.text, provider }); setTranscript(items => [displayEntry(savedEntry), ...items].slice(0, 80)); await refreshMemory(); }
    catch (error) { setMemoryError("Could not save this entry: " + String(error)); setTranscript(items => [entry, ...items].slice(0, 80)); }
  }
  async function loadOlder() {
    if (!transcript.length) return;
    try { const next = await window.gracie.getMemory(transcript[transcript.length - 1].id); setTranscript(items => [...items, ...next.entries.map(displayEntry)]); setMemory(current => current ? { ...current, hasOlder: next.hasOlder } : next); }
    catch (error) { setMemoryError(String(error)); }
  }
  async function updateMemory(forgetId?: string) {
    setMemoryBusy(true);
    try { if (forgetId) await window.gracie.forgetMemory(forgetId); else { await window.gracie.saveMemory({ id: editingMemory, text: memoryText }); setMemoryText(""); setEditingMemory(undefined); } await refreshMemory(); }
    catch (error) { setMemoryError(String(error)); }
    finally { setMemoryBusy(false); }
  }

  async function connect() {
    if (connectionState === "connecting" || sendingRef.current) return;
    if (localOnly) {setChatError('OpenAI voice is disabled in Local assistant mode. Type to use Gracie locally.');return;}
    if (chatProvider !== 'openai') {
      const message = 'Ollama is selected. Voice is currently available only through OpenAI. Type your message to use the selected Ollama model, or choose OpenAI voice in Settings. Local speech recognition and playback are not installed in Gracie.';
      setChatError(message);
      setStatus(message);
      setShowSettings(true);
      return;
    }
    setChatError('');
    const client = new GracieRealtimeClient({
      getLocalModel: () => selectedModelRef.current,
      onConnectionState: (state) => {
        setConnectionState(state);
        if (state === "error") setShowLog(true);
      },
      onMood: setMood,
      onMouthShape: setMouthShape,
      onTranscript: (entry) => { void recordEntry(entry); },
      onArtifact: (nextArtifact) => {
        setArtifact(nextArtifact);
        setActivePage("canvas");
        setArtifactVisible(true);
        if (nextArtifact.fullscreen) setArtifactFullscreen(true);
      },
      onMode: (nextMode) => {
        setMode(nextMode);
        if (nextMode === "computer") {
          setArtifactVisible(false);
          setArtifactFullscreen(false);
          setShowLog(false);
          setShowTypeInput(false);
        } else {
          setArtifactVisible(true);
        }
      },
      onStatus: (message) => {
        setStatus(message);
        if (lastVoiceStatus.current !== message) { lastVoiceStatus.current = message; void recordEntry(newEntry("system", message)); }
      },
      onThumbnailReady: playThumbnailReadySound,
    });
    clientRef.current = client;
    await client.connect("gracie");
  }

  function disconnect() {
    clientRef.current?.disconnect();
    clientRef.current = null;
    setStatus("Disconnected");
  }

  async function switchMode(nextMode: GracieMode) {
    setMode(nextMode);
    if(nextMode==='computer')await window.gracie.beginComputerTask('Use my computer for my requested task.');
    const result = await window.gracie.executeTool({ name: "set_mode", arguments: { mode: nextMode } });
    if (result.artifact) setArtifact(result.artifact);
    if (nextMode === "computer") {
      setArtifactVisible(false);
      setArtifactFullscreen(false);
      setShowLog(false);
      setShowTypeInput(false);
    } else {
      setArtifactVisible(true);setShowTypeInput(true);
    }
    void recordEntry(newEntry("system", `Mode switched to ${nextMode}.`), chatProvider);
  }

  function sendTextPrompt(buildApp=composeIntent==='build') {
    const helperTask=composeIntent==='agent'&&!buildApp;
    if(helperTask&&(!codingFolder||!allowProjectEdits||!allowProjectChecks||selectedCloud)){setChatError('Project helpers need a local model, a coding folder, and project edits and checks enabled in Settings. Your draft is kept.');setShowSettings(true);return;}
    buildApp=buildApp||(!helperTask&&isAppBuildRequest(textPrompt));
    if(!buildApp&&chatProvider==='ollama'&&sendingRef.current&&workMode==='build'){void askDuringBuild();return;}
    if(pausedWork&&(buildApp||helperTask||pausedWork.workMode!=='build')){setChatError('Resume the saved work, or choose New task to start another task. Your message is kept.');return;}
    const trimmed = textPrompt.trim() || (attachedFiles.length||referenceLinks.length ? 'Review the attached files and references for this project.' : '');
    if (!trimmed || sendingRef.current || workBusy) return;
    if(trimmed.length>200000){setChatError('This message is over 200,000 characters. Send it in smaller parts or attach it as a text file. Your full draft is kept.');return;}
    if (chatProvider === "ollama" || buildApp || helperTask) {
      if(buildApp||helperTask){if(isConnected)disconnect();setChatProvider('ollama');setComposeIntent('chat');}
      void sendOllamaPrompt(trimmed,false,helperTask?'agent':buildApp?'build':'chat');
      return;
    }
    if (!isConnected) { const message="OpenAI is disconnected. Open Settings and connect voice, or select Ollama for typed chat. Your draft is kept."; setStatus(message);setChatError(message);setShowSettings(true);return; }
    const sent = clientRef.current?.sendText(trimmed) ?? false;
    setShowLog(true);
    if (sent) {
      setChatError('');
      setTextPrompt("");
      setShowTypeInput(true);
    } else setChatError('The OpenAI connection is not ready. Reconnect in Settings and try again. Your draft is kept.');
  }

  async function askDuringBuild(){
    const draft=textPrompt,note=draft.trim();
    if(!note||workBusy||updatingBuildRef.current)return;
    if(note.length>200000){setChatError('Keep this question under 200,000 characters. Your draft is kept.');return;}
    updatingBuildRef.current=true;setWorkBusy(true);
    const finished=sendFinishedRef.current;
    try{
      const saved=await window.gracie.pauseWork({model});
      await finished;setPausedWork(saved);
      setTextPrompt(current=>current===draft?'':current);
      void sendOllamaPrompt(note,false,'chat',undefined,true);
    }catch(error){setChatError(String(error));}
    finally{updatingBuildRef.current=false;setWorkBusy(false);}
  }

  async function sendBuildUpdate(){
    const draft=textPrompt,note=draft.trim();
    if(!note||workBusy||updatingBuildRef.current)return;
    updatingBuildRef.current=true;setWorkBusy(true);setChatError('');
    const finished=sendFinishedRef.current;
    try{
      setStatus('Saving your build update and pausing the current generation.');
      const saved=await window.gracie.updateBuild(note);
      await finished;
      setPausedWork(saved);setProjectId(saved.projectId||'');setWorkMode('build');
      setTranscript(items=>[newEntry('user',note),...items].slice(0,80));
      setTextPrompt(current=>current===draft?'':current);
      void sendOllamaPrompt(saved.message,true,undefined,saved,true);
    }catch(error){setChatError(String(error));setStatus('The update could not continue. Your draft and saved build are retained.');setTextPrompt(current=>current||note);setPausedWork(await window.gracie.getPausedWork().catch(()=>null));}
    finally{updatingBuildRef.current=false;setWorkBusy(false);}
  }

  async function pasteMessage(){
    const field=composerRef.current;
    const start=field?.selectionStart??textPrompt.length,end=field?.selectionEnd??start;
    const draft=textPrompt;
    try{
      const text=await window.gracie.readClipboardText();
      if(!text){setChatError('The clipboard has no text. Copy your message, then click Paste.');return;}
      setTextPrompt(current=>current===draft?draft.slice(0,start)+text+draft.slice(end):current+text);
      setShowTypeInput(true);setChatError('');
      requestAnimationFrame(()=>{const input=composerRef.current;if(input){input.focus();const caret=input.value.length===draft.length-(end-start)+text.length?start+text.length:input.value.length;input.setSelectionRange(caret,caret);}});
    }catch(error){setChatError('Could not paste: '+String(error)+'. Try Ctrl+V in the message box.');}
  }

  async function sendOllamaPrompt(message: string, resuming=false,requestedMode?:'build'|'chat'|'agent',resumeSnapshot?:PausedWork,preserveComposer=false) {
    const workSnapshot=resumeSnapshot||pausedWork;
    if (sendingRef.current) return;
    let finishSend!:()=>void;sendFinishedRef.current=new Promise<void>(resolve=>{finishSend=resolve;});
    sendingRef.current = true; setSending(true); setChatError("");setActivePage("chat");
    if (!resuming) setSources([]);
    const requestId = crypto.randomUUID();
    const reply = { ...newEntry("gracie", resuming ? workSnapshot?.partial||'' : ''), id: requestId };
    setTranscript(items => [reply, ...(resuming?[]:[newEntry("user", message)]), ...items].slice(0, 80));
    if(!preserveComposer)setTextPrompt(""); setMood("thinking"); setShowLog(false); setShowTypeInput(true);
    setStatus(requestedMode==='agent'?'Starting project helpers…':requestedMode==='build'?'Starting your app build…':'Connecting to Ollama and waiting for the first words…');
    let unsubscribe: (() => void) | undefined;
    let activeMode:'chat'|'build'|'agent'=resuming?workSnapshot?.workMode||'chat':requestedMode||'chat';
    setWorkMode(activeMode);
    try {
      // Check at send time, rather than silently relying on a stale polling result.
      const state=await refreshOllamaStatus();
      if(!state.available)throw new Error(state.message||'Ollama is offline. Open the Ollama app, then send your message again.');
      const chosenModel=(resuming?workSnapshot?.model:undefined)||model||state.defaultModel;
      if(chosenModel&&!state.models.includes(chosenModel)&&!/(?::cloud|-cloud)$/.test(chosenModel))throw new Error('The selected model is unavailable. Choose an installed model in Settings. Gracie has not switched models.');
      if(!chosenModel)throw new Error('No AI model is available. Open Settings to choose or download a model.');
      if(chosenModel!==model)setModel(chosenModel);
      unsubscribe = window.gracie.onOllamaChunk(update => {
        if (update.requestId !== requestId) return;
        if(update.warning){setChatError(update.warning);return;}
        if(update.mode){activeMode=update.mode;setWorkMode(update.mode);if(update.mode==='build')setProjectId('');}
        if(update.stage){setStatus(update.stage);if(update.mode==='build'||update.mode==='agent')setTranscript(items=>items.map(item=>item.id===requestId?{...item,text:update.stage!}:item));return;}
        setTranscript(items => items.map(item => item.id === requestId ? { ...item, text: item.text + update.text } : item));
        setStatus("Gracie is replying…");
      });
      const result = resuming ? await window.gracie.resumeWork(requestId) : await window.gracie.chatWithOllama({ message, model:chosenModel, requestId, projectId, workMode:requestedMode,fastMode, includeSavedContext: selectedCloud && includeSavedContext, useLocalTools:useLocalTools&&!(requestedMode==='chat'&&(preserveComposer||workSnapshot?.workMode==='build')),attachmentIds:attachedFiles.map(file=>file.id),links:referenceLinks,researchMode });
      if(result.project){setProjectId(result.project.id);setWorkMode('build');}
      if(!result.ok&&result.project)setPausedWork(await window.gracie.getPausedWork());
      if(!result.ok&&!result.project&&activeMode==='build')setProjectId('');
      if(!result.ok&&activeMode==='agent')setPausedWork(await window.gracie.getPausedWork());
      if(result.paused){setTranscript(items=>items.map(item=>item.id===requestId?{...item,text:result.content||'Paused before the first words. Resume when you are ready.'}:item));setPausedWork(await window.gracie.getPausedWork());setMood('idle');setStatus('Paused. Your checkpoint is saved on this PC.');return;}
      if (!result.ok || !result.content) throw new Error(result.error || "Ollama could not reply. Click Reconnect and try again.");
      setSources(result.sources||[]);
      if(result.project){setProjectId(result.project.id);setWorkMode('build');}
      if(resuming){setPausedWork(null);if(result.model)setModel(result.model);}
      setTranscript(items => items.map(item => item.id === requestId ? { ...item, text: result.content! } : item));
      if (result.warning) setChatError(result.warning);
      else await refreshMemory(false);
      setMood("idle");
      setStatus(result.project?(result.project.outputFolder?'Your app is ready. Choose Run app or Open app folder.':'App built. Choose Open app folder to prepare its runnable files.'):activeMode==='agent'?'Project helpers finished. Review the files and check results.':requestedMode==='chat'?'Reply complete. Saved builds stay paused until you choose Resume.':result.truncated ? 'Fast reply limit reached. Turn off Fast local replies for a longer answer.' : `Gracie replied ${selectedCloud ? "through Ollama Cloud" : "locally"} with ${result.model || "Ollama"}.`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      setMood("error"); setStatus(detail); setChatError(detail); setTextPrompt(current=>current||message);
      setTranscript(items => items.map(item => item.id === requestId && !item.text ? { ...item, text: activeMode==='build'?'The app build did not finish. Project files and check results are preserved; see details below.':"No reply received. See the connection message below." } : item));
      void refreshOllamaStatus();
    } finally { try{unsubscribe?.();}finally{sendingRef.current = false; setSending(false);finishSend();void refreshProjects();} }
  }

  async function resumeProject(id:string){
    if(sendingRef.current||workBusy)return;setWorkBusy(true);
    try{const snapshot=await window.gracie.loadProjectCheckpoint(id);setPausedWork(snapshot);setProjectId(id);setWorkMode('build');setActivePage('chat');await sendOllamaPrompt(snapshot.message,true,undefined,snapshot);}
    catch(error){setChatError(String(error));}finally{setWorkBusy(false);}
  }
  async function attachFiles(){
    setWorkBusy(true);try{const result=await window.gracie.chooseAttachments();setAttachedFiles(current=>[...current,...result.files].slice(0,6));if(result.errors.length)setChatError(result.errors.join(' '));else setChatError('');}catch(error){setChatError(String(error));}finally{setWorkBusy(false);}
  }
  async function pauseWork(){
    if(workBusy)return;setWorkBusy(true);
    try{const saved=await window.gracie.pauseWork({model});setPausedWork(saved);setStatus(saved?'Paused. Your checkpoint is saved on this PC.':'No checkpoint was saved.');}
    catch(error){setChatError(String(error));}finally{setWorkBusy(false);}
  }
  async function resumeWork(){
    if(!pausedWork||workBusy||sending)return;
    if(!pausedWork.completed){await sendOllamaPrompt(pausedWork.message,true);return;}
    setWorkBusy(true);try{const result=await window.gracie.resumeWork(crypto.randomUUID());if(!result.ok)throw Error(result.error);setPausedWork(null);if(result.model)setModel(result.model);const folder=await window.gracie.getCodingFolder();syncCodingFolder(folder);setStatus('Project resumed. Send your next instruction.');}catch(error){setChatError(String(error));}finally{setWorkBusy(false);}
  }
  async function newTask(){try{const saved=await window.gracie.startNewTask();setPausedWork(saved);if(!saved)setStatus('Ready for a new task. Your chat archive is preserved.');}catch(error){setChatError(String(error));}}

  async function reconnectOllama(){
    if(workBusy||sendingRef.current)return;
    setWorkBusy(true);setStatus('Opening Ollama and reconnecting.');
    try{const state=await window.gracie.reconnectOllama();setOllamaStatus(state);
      if(!state.available)throw Error(state.message||'Ollama could not start. Open it manually, then retry.');
      setModel(current=>current||state.defaultModel||'');
      setChatError('');setStatus('Ollama is connected. Your draft is ready to send.');
    }catch(error){setChatError(String(error));}finally{setWorkBusy(false);}
  }

  function shareScreen() {
    void clientRef.current?.shareScreen();
  }

  if (mode === "computer") {
    return (
      <main className="app-shell app-shell-mini">
        <section className="mini-companion" aria-label="Gracie computer use mini mode">
          <GracieFace mood={mood} mouthShape={mouthShape} />
          <button
            className="mini-restore-button"
            onClick={() => void switchMode("display")}
            aria-label="Return to full Gracie window"
            title="Return to full Gracie window"
          >
            <Expand size={14} />
          </button>
        </section>
      </main>
    );
  }

  const busy=sending||workBusy;
  const selectedProject=projects.find(project=>project.id===projectId);
  const pageTitles={chat:'Gracie',apps:'Your apps',sources:'Files & research',activity:'Activity',canvas:'Canvas'};
  const canUpdateBuild=chatProvider==='ollama'&&((sending&&workMode==='build')||pausedWork?.workMode==='build');
  const canSend=canUpdateBuild?Boolean(textPrompt.trim())&&!workBusy&&(!sending||workMode==='build'):Boolean(textPrompt.trim()||attachedFiles.length||referenceLinks.length)&&!busy;
  const providerLabel=isConnected?'OpenAI voice connected':chatProvider==='openai'?'OpenAI voice':selectedCloud?'Cloud model':ollamaStatus?.available?'On this PC':'Ollama offline';
  const stopComputer=()=>{void window.gracie.stopComputerTask();if(isConnected)disconnect();setStatus('Computer actions stopped.');};

  return <main className="gracie-app">
    <ModelFinder open={showModelFinder} onClose={()=>setShowModelFinder(false)} status={ollamaStatus} selected={model} onSelect={setModel} onRefresh={refreshOllamaStatus} busy={sending}/>
    <aside className="app-rail" aria-label="Main navigation">
      <div className="rail-brand"><span className="brand-mark">g<span>·</span></span><span className="brand-name">gracie<span>Your space to think.</span></span></div>
      <nav className="rail-nav">
        <button aria-label="Chat" onClick={()=>setActivePage('chat')} aria-current={activePage==='chat'?'page':undefined} title="Chat"><MessageCircle size={19}/><span>Chat</span></button>
        <button aria-label="Your apps" onClick={()=>setActivePage('apps')} aria-current={activePage==='apps'?'page':undefined} title="Your apps"><LayoutGrid size={19}/><span>Your apps</span>{!!projects.filter(project=>project.readyRevision>0).length&&<small>{projects.filter(project=>project.readyRevision>0).length}</small>}</button>
        <button aria-label="Files & research" onClick={()=>setActivePage('sources')} aria-current={activePage==='sources'?'page':undefined} title="Files and research"><Paperclip size={19}/><span>Files & research</span>{!!(attachedFiles.length+referenceLinks.length)&&<small>{attachedFiles.length+referenceLinks.length}</small>}</button>
      </nav>
      <div className="rail-space"><span className="rail-flower" aria-hidden="true">✳</span><p>A little clarity.<br/>A little possibility.</p></div>
      <div className="rail-bottom">
        <ActionMenu label="More features" icon={<><MoreHorizontal size={19}/><span>More</span></>}>
          <button onClick={()=>{setActivePage('canvas');setArtifactVisible(true);}}><PanelsTopLeft size={16}/>Canvas & artifacts</button>
          <button onClick={()=>{setActivePage('activity');setShowLog(true);}}><History size={16}/>Activity & history</button>
          <button onClick={()=>{setShowMemory(true);void refreshMemory();}}><BrainCircuit size={16}/>Gracie’s memory</button>
          <button onClick={()=>void switchMode('computer')} disabled={busy}><MonitorCog size={16}/>Mini companion</button>
          {chatProvider==='ollama'&&<button onClick={()=>void pauseWork()} disabled={busy||!!pausedWork}><Pause size={16}/>Save a checkpoint</button>}
        </ActionMenu>
        <button className="rail-settings" onClick={()=>setShowSettings(true)} title="Settings"><Settings2 size={19}/><span>Settings</span></button>
      </div>
    </aside>

    <section className="app-main">
      <header className="app-header">
        <button className="header-portrait" onClick={()=>setShowPortrait(true)} aria-label="Focus on Gracie" title="Focus on Gracie"><GracieFace mood={mood} mouthShape={mouthShape}/></button>
        <div className="header-title"><h1>{pageTitles[activePage]}</h1><span>{activePage==='chat'?'A conversation. A project. Whatever’s next.':activePage==='apps'?'Everything you’ve created, in one place.':activePage==='sources'?'Bring a little context. Gracie handles the rest.':activePage==='canvas'?'Your images, notes, charts and results.':'Your saved conversations and actions.'}</span></div>
        <div className="header-actions"><button className={`provider-pill ${chatProvider==='ollama'&&!ollamaStatus?.available?'is-offline':''}`} onClick={()=>setShowSettings(true)} title={chatProvider==='ollama'?model:'OpenAI Realtime'}><span className="presence-dot"/>{providerLabel}<ChevronDown size={13}/></button><div className="window-actions"><button aria-label="Minimize window" title="Minimize" onClick={()=>void window.gracie.minimize()}><Minus size={16}/></button><button aria-label="Close window" title="Close" onClick={()=>void window.gracie.close()}><X size={16}/></button></div></div>
      </header>

      <div className="page-stack">
        <section className="page-view conversation-view" hidden={activePage!=='chat'} aria-label="Conversation">
          <ChatPanel active={activePage==='chat'} entries={transcript} sending={sending||mood==='thinking'||mood==='speaking'} model={chatProvider==='ollama'?model:'OpenAI'} error={chatError} workStage={status} sources={sources} onOpenSource={url=>void window.gracie.openResearchSource(url).catch(error=>setChatError(String(error)))} hasOlder={Boolean(memory?.hasOlder)} onLoadOlder={()=>void loadOlder()}/>
        </section>
        <section className="page-view content-page" hidden={activePage!=='apps'} aria-label="Apps library"><OllamaApps model={model} cloud={selectedCloud} folder={codingFolder} onChooseModel={()=>setShowSettings(true)}/><ProjectsPanel onResume={id=>void resumeProject(id)} outputFolder={appOutputFolder} onChooseFolder={()=>void chooseAppOutputFolder()} projects={projects} selected={projectId} onSelect={setProjectId} onAction={(id,kind)=>void projectAction(id,kind)} busy={busy} mode={workMode} cloud={selectedCloud}/></section>
        <section className="page-view content-page" hidden={activePage!=='sources'} aria-label="Files and research"><WorkspaceControls attachments={attachedFiles} links={referenceLinks} researchMode={researchMode} onResearchMode={setResearchMode} onAttach={()=>void attachFiles()} onRemoveAttachment={id=>setAttachedFiles(files=>files.filter(file=>file.id!==id))} onLinks={setReferenceLinks} busy={busy} localOnly={localOnly} cloud={selectedCloud||chatProvider==='openai'}/></section>
        <section className="page-view content-page" hidden={activePage!=='activity'} aria-label="Saved activity"><div className="page-intro"><span className="eyebrow">YOUR HISTORY</span><h2>Pick up the thread.</h2><p>{memory?.count||transcript.length} saved entries on this PC.</p></div><div className="activity-list">{transcript.map(entry=><article className={`activity-entry activity-${entry.role}`} key={entry.id}><header><strong>{entry.role==='gracie'?'Gracie':entry.role==='user'?'You':entry.role==='tool'?'Action':'Status'}</strong><time>{entry.at}</time></header>{entry.text.length>1600?<details><summary>{entry.text.slice(0,180)}… <span>Read full entry</span></summary><p>{entry.text}</p></details>:<p>{entry.text}</p>}</article>)}{memory?.hasOlder&&<button className="quiet-button" onClick={()=>void loadOlder()}>Load older entries</button>}</div></section>
        <section className="page-view canvas-page" hidden={activePage!=='canvas'} aria-label="Canvas"><ArtifactPanel artifact={artifact} visible={artifactVisible} fullscreen={artifactFullscreen} onToggleVisible={()=>setArtifactVisible(value=>!value)} onToggleFullscreen={()=>setArtifactFullscreen(value=>!value)}/></section>
      </div>

      <footer className="conversation-footer">
        {memoryError&&<details className="subtle-notice"><summary>Something needs attention</summary><p role="alert">{memoryError}</p></details>}
        {pausedWork&&<section className="checkpoint-banner" aria-label="Paused work"><div><strong>Saved for when you’re ready.</strong><span>{pausedWork.failure?'Progress saved for repair':pausedWork.workMode==='build'?'App build paused':'Work paused'} · Your progress is on this PC.</span><details><summary>View checkpoint</summary><p>{pausedWork.message}</p>{pausedWork.partial&&<p>{pausedWork.partial}</p>}<small>{pausedWork.workMode==='build'?'Resume keeps completed build steps and retries an interrupted generation.':'Resume continues from the saved checkpoint with a new generation.'}</small></details></div><div className="checkpoint-actions"><button className="primary-button" disabled={busy} onClick={()=>void resumeWork()}><Play size={14}/>Resume</button><button className="quiet-button" disabled={busy} onClick={()=>void newTask()}>New task</button></div></section>}
        {activePage==='chat'&&selectedProject&&selectedProject.readyRevision>0&&workMode==='build'&&!sending&&<section className="finished-app" aria-label="Your app is ready"><span className="finished-icon"><Check size={18}/></span><div><strong>{selectedProject.title}</strong><span>Version {selectedProject.readyRevision} · Ready to try</span></div><button className="quiet-button" disabled={busy} onClick={()=>void projectAction(selectedProject.id,'folder')} title="Open app folder"><FolderOpen size={17}/><span>Folder</span></button><button className="primary-button" disabled={busy} onClick={()=>void projectAction(selectedProject.id,'open')}><Play size={14}/>Run app</button></section>}
        <div className="work-strip"><details className={`work-status ${mood==='error'?'status-error':''}`}><summary><span className={`presence-dot ${sending||computerActive?'is-working':''}`}/>{sending?status:computerActive?'Computer use active':pausedWork?.failure?'Saved work needs attention':pausedWork?'Work is paused':mood==='error'?'Something needs attention':isConnected?'Voice connected':'Ready when you are'}</summary><p>{status}</p></details><div className="work-actions">{sending&&chatProvider==='ollama'&&!(pausedWork?.workMode==='build'&&workMode==='chat')&&<button disabled={workBusy} onClick={()=>void pauseWork()} title="Pause and save progress"><Pause size={14}/>Pause</button>}{sending?<button onClick={()=>void window.gracie.cancelOllamaChat().catch(error=>setChatError(String(error)))} aria-label="Stop reply" title="Stop reply"><Square size={12}/>Stop</button>:computerActive?<button onClick={stopComputer} title="Stop computer actions"><Square size={12}/>Stop</button>:null}</div></div>
        {showTypeInput?<div className={`message-composer ${pausedWork?'composer-paused':''}`}>
          <textarea ref={composerRef} value={textPrompt} onChange={event=>setTextPrompt(event.target.value)} onKeyDown={event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.nativeEvent.isComposing){event.preventDefault();sendTextPrompt();}}} rows={1} aria-label="Message Gracie" placeholder={canUpdateBuild?'Ask a question, or choose Update build for changes...':pausedWork?'Resume your work when you’re ready.':'Ask anything, or describe what you want to build…'}/>
          <div className="composer-toolbar"><div className="composer-left"><select className="compose-intent" aria-label="Message purpose" value={composeIntent} disabled={busy} onChange={event=>setComposeIntent(event.target.value as 'chat'|'build'|'agent')}><option value="chat">Auto · ask or build</option><option value="build">Build Windows app</option><option value="agent">Project helpers</option></select><button className="icon-button" onMouseDown={event=>event.preventDefault()} onClick={()=>void pasteMessage()} aria-label="Paste message" title="Paste clipboard text"><ClipboardPaste size={18}/></button><ActionMenu label="Message actions" icon={<Plus size={19}/>}><button onClick={()=>void attachFiles()} disabled={busy||selectedCloud||chatProvider==='openai'||attachedFiles.length>=6}><Paperclip size={16}/>Attach files</button><button onClick={()=>setActivePage('sources')}><Link2 size={16}/>Add a reference link</button><button onClick={()=>sendTextPrompt(true)} disabled={!textPrompt.trim()||busy||!!pausedWork||!ollamaStatus?.available||!model}><Code2 size={16}/>Build app from this message</button><button onClick={shareScreen} disabled={!isConnected}><Monitor size={16}/>Share screen</button></ActionMenu><button className="composer-mode" onClick={()=>setActivePage('sources')} title="Research settings"><Sparkles size={13}/>{researchMode==='auto'?'Gracie Auto':researchMode==='deep'?'Deep research':researchMode==='search'?'Web search':'Research off'}</button>{!!(attachedFiles.length+referenceLinks.length)&&<button className="context-count" onClick={()=>setActivePage('sources')}>{attachedFiles.length+referenceLinks.length} attached</button>}</div><div className="composer-right"><button className="icon-button" aria-label={expandedComposer?"Collapse message box":"Expand message box"} onClick={()=>setExpandedComposer(value=>!value)}>{expandedComposer?"↙":"↗"}</button>{canUpdateBuild&&<button className="build-update-button" disabled={!textPrompt.trim()||busy&&workMode!=='build'||workBusy} onClick={()=>void sendBuildUpdate()}>Update build</button>}<button className={`icon-button voice-button ${isConnected?'is-connected':''}`} onClick={()=>void(isConnected?disconnect():connect())} disabled={sending||connectionState==='connecting'} aria-label={isConnected?'Disconnect OpenAI voice':chatProvider==='openai'?'Connect OpenAI voice':'Voice provider settings'} title={isConnected?'End OpenAI voice conversation':chatProvider==='openai'?'Talk through OpenAI voice':'Ollama selected · type locally; open voice settings'}>{isConnected?<MicOff size={18}/>:<Mic size={18}/>}</button><button className="send-button"  onClick={()=>sendTextPrompt()} disabled={!canSend} aria-label={composeIntent==="agent"?"Run project helpers":composeIntent==="build"?"Build Windows app":"Send question"} title={composeIntent==="agent"?"Plan, edit, test and review the selected project":composeIntent==="build"?"Build a Windows app from this message":"Send message; explicit app requests start a build"}><ArrowUp size={19}/></button></div></div>
        </div>:<button className="show-composer" onClick={()=>setShowTypeInput(true)}><Keyboard size={16}/>Show message box</button>}
        {chatProvider==='ollama'&&!ollamaStatus?.available&&<button className="quiet-button" disabled={busy} onClick={()=>void reconnectOllama()}>Open Ollama / Reconnect</button>}
        {canUpdateBuild&&<p role="status">Send asks a question and keeps your build paused. Update build applies your message to the app. Resume continues saved work.</p>}<div className="composer-footnote"><span>{localOnly?'Gracie · local assistant':chatProvider==='ollama'?(selectedCloud?'Cloud AI · apps built on this PC':'Local AI · your computer'):'OpenAI · voice & tools'}{isConnected?' · OpenAI voice connected':''}</span><span>{textPrompt.length.toLocaleString()} characters · Enter to send · Shift + Enter for a new line</span></div>
      </footer>
    </section>

    <OverlayDialog open={showSettings} onClose={()=>setShowSettings(false)} title="Make Gracie yours" description="Your models and preferences, together in one place.">
      <section className="settings-section"><h3>Connection</h3>{localOnly&&<p className="setting-note" role="status">Local assistant mode: Gracie uses weights and memory on this PC. OpenAI and automatic web research are disabled. Explicit browser actions and project scripts can still access the network.</p>}<label className="field-label">Conversation<select aria-label="Conversation provider" value={chatProvider} disabled={localOnly||sending||connectionState==='connecting'} onChange={event=>{if(isConnected)disconnect();setChatProvider(event.target.value as ChatProvider);setShowTypeInput(true);}}><option value="ollama">Ollama · local & cloud</option><option value="openai">OpenAI · voice & tools</option></select></label>
        {chatProvider==='ollama'?<><label className="field-label">AI model<select aria-label="Ollama model" value={model} disabled={sending||!ollamaStatus?.available} onChange={event=>setModel(event.target.value)}>{!ollamaStatus?.models.length&&<option value="">No models available</option>}{model&&!ollamaStatus?.models.includes(model)&&<option value={model}>{model}{selectedCloud?' · Cloud':' · unavailable'}</option>}{ollamaStatus?.models.map(name=>{const details=ollamaStatus.modelDetails?.find(item=>item.name===name);return <option key={name} value={name}>{name}{details?.parameters?' · '+details.parameters:''}</option>;})}</select></label><div className="settings-actions"><button className="quiet-button" onClick={()=>{setShowSettings(false);setShowModelFinder(true);}}>Find a model</button><button className="quiet-button" disabled={sending} onClick={()=>void reconnectOllama()}>Open Ollama / Reconnect</button></div><p className="setting-note">{localOnly?'Gracie answers typed messages locally. Local microphone recognition and speech playback are not implemented.':'Voice is unavailable in Ollama mode. Typed messages use the selected Ollama model. To speak through OpenAI, change the conversation provider.'}</p><p className="setting-note" role="status">{ollamaStatus?.available?'Connected to Ollama on this PC.':'Ollama is not connected.'}{ollamaStatus?.message?' '+ollamaStatus.message:''}{selectedCloud?' This model sends messages to Ollama Cloud; account limits apply.':''}</p></>:<><p className="setting-note">Talk, share your screen and use tools with OpenAI. Your existing API key is used.</p><button className="quiet-button" onClick={()=>void(isConnected?disconnect():connect())} disabled={connectionState==='connecting'||sending}>{isConnected?'Disconnect OpenAI voice':'Connect OpenAI voice'}</button></>}
      </section>
      <section className="settings-section"><h3>How Gracie works</h3>{chatProvider==='ollama'&&<><label className="setting-row"><span><strong>Fast local replies</strong><small>Shorter answers and less past context. Applies to local models.</small></span><input type="checkbox" checked={fastMode} disabled={sending} onChange={event=>setFastMode(event.target.checked)}/></label><label className="setting-row"><span><strong>Automatic computer tools</strong><small>Let your Ollama model act on requested tasks. Sensitive actions still ask. Cloud models receive requested screen, page and project context.</small></span><input type="checkbox" checked={useLocalTools} disabled={sending} onChange={event=>setUseLocalTools(event.target.checked)}/></label>{selectedCloud&&<label className="setting-row"><span><strong>Saved context in cloud chats</strong><small>Include remembered preferences and recent history when using Ollama Cloud.</small></span><input type="checkbox" checked={includeSavedContext} disabled={sending} onChange={event=>setIncludeSavedContext(event.target.checked)}/></label>}<div className="folder-setting"><strong>Coding folder</strong><p>{codingFolder||'Choose a trusted project folder for the Planner, Builder, Tester and Reviewer helpers.'}</p><div className="settings-actions"><button className="quiet-button" disabled={sending} onClick={()=>void window.gracie.chooseCodingFolder().then(syncCodingFolder).catch(error=>setStatus(String(error)))}>Choose folder</button>{codingFolder&&<label className="setting-row"><span><strong>Allow project edits</strong><small>Create and update source files in this folder. Existing-file edits check for changes first.</small></span><input type="checkbox" checked={allowProjectEdits} disabled={busy} onChange={event=>void window.gracie.setProjectEdits(event.target.checked).then(syncCodingFolder).catch(error=>setChatError(String(error)))}/></label>}{codingFolder&&<label className="setting-row"><span><strong>Allow project checks</strong><small>Run test, build and typecheck scripts automatically. Scripts execute with the permissions of Gracie and can access files or the network. Enable only for projects you trust.</small></span><input type="checkbox" checked={allowProjectChecks} disabled={busy} onChange={event=>void window.gracie.setProjectChecks(event.target.checked).then(syncCodingFolder).catch(error=>setChatError(String(error)))}/></label>}{codingFolder&&<button className="quiet-button" disabled={sending} onClick={()=>void window.gracie.clearCodingFolder().then(()=>syncCodingFolder({folder:''})).catch(error=>setStatus(String(error)))}>Forget folder</button>}</div></div></>}
        <button className="setting-link" onClick={()=>{setShowSettings(false);setActivePage('sources');}}><span><strong>Research preferences</strong><small>{researchMode==='auto'?'Automatic · Gracie decides when to look things up':researchMode==='off'?'Online research is off':researchMode==='deep'?'Deep research':'Web search'}</small></span><ChevronRight size={18}/></button><button className="setting-link" onClick={()=>{setShowSettings(false);setShowMemory(true);void refreshMemory();}}><span><strong>Memory & saved preferences</strong><small>{memory?.memories.length||0} remembered · {memory?.count||0} saved entries</small></span><ChevronRight size={18}/></button>
      </section>
      <section className="settings-section"><h3>Your view</h3><label className="setting-row"><span><strong>Message box</strong><small>Keep typing available alongside voice.</small></span><input type="checkbox" checked={showTypeInput} onChange={event=>setShowTypeInput(event.target.checked)}/></label><div className="settings-actions"><button className="quiet-button" onClick={()=>{setShowSettings(false);setShowPortrait(true);}}>Focus on Gracie</button><button className="quiet-button" disabled={busy} onClick={()=>{setShowSettings(false);void switchMode('computer');}}>Mini companion</button><button className="quiet-button" onClick={()=>{setShowSettings(false);setActivePage('canvas');setArtifactVisible(true);}}>Canvas & artifacts</button><button className="quiet-button" onClick={()=>{setShowSettings(false);setActivePage('activity');}}>Activity & history</button><button className="quiet-button" onClick={stopComputer}>Stop computer actions</button></div></section>
    </OverlayDialog>

    <OverlayDialog open={showMemory} onClose={()=>setShowMemory(false)} title="Gracie’s memory" description="The little things that make this feel like you.">
      <p className="setting-note">Chats and activity stay on this PC. Gracie recalls relevant messages and saved preferences. OpenAI voice includes remembered context; reconnect voice after editing it.</p>{memoryError&&<p role="alert" className="finder-error">{memoryError}</p>}<label className="field-label" htmlFor="memory-text">{editingMemory?'Edit memory':'Something to remember'}<textarea id="memory-text" value={memoryText} maxLength={400} onChange={event=>setMemoryText(event.target.value)} placeholder="For example: I prefer concise answers with practical steps."/></label><div className="settings-actions"><button className="primary-button" disabled={memoryBusy||!memoryText.trim()} onClick={()=>void updateMemory()}>Save memory</button>{editingMemory&&<button className="quiet-button" onClick={()=>{setEditingMemory(undefined);setMemoryText('');}}>Cancel edit</button>}</div><div className="memory-cards">{memory?.memories.map(item=><article key={item.id}><p>{item.text}</p><small>{item.source}</small><div className="settings-actions"><button className="quiet-button" disabled={memoryBusy} onClick={()=>{setEditingMemory(item.id);setMemoryText(item.text);}}>Edit</button><button className="quiet-button" disabled={memoryBusy} onClick={()=>void updateMemory(item.id)}>Remove from memory</button></div></article>)}{!memory?.memories.length&&<p className="setting-note">No saved preferences yet. Say “Remember that…” in conversation, or add one here.</p>}</div><p className="setting-note">Removing a memory stops its reuse. Your chat archive stays intact.</p>
    </OverlayDialog>
    <OverlayDialog open={showPortrait} onClose={()=>setShowPortrait(false)} title="Right here with you."><div className="portrait-focus"><GracieFace mood={mood} mouthShape={mouthShape}/><p>{isConnected?'Voice is connected. You can speak naturally.':'Talk it through, or return to the conversation.'}</p><button className="primary-button" disabled={sending||connectionState==='connecting'} onClick={()=>void(isConnected?disconnect():connect())}>{isConnected?<MicOff size={16}/>:<Mic size={16}/>} {isConnected?'End voice conversation':'Talk with Gracie'}</button></div></OverlayDialog>
  </main>;

}

function playThumbnailReadySound() {
  try {
    const AudioContextClass = window.AudioContext;
    const audio = new AudioContextClass();
    const gain = audio.createGain();
    const osc = audio.createOscillator();

    osc.type = "sine";
    osc.frequency.setValueAtTime(880, audio.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1320, audio.currentTime + 0.08);
    gain.gain.setValueAtTime(0.0001, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.035, audio.currentTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, audio.currentTime + 0.13);

    osc.connect(gain);
    gain.connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + 0.14);
    window.setTimeout(() => void audio.close(), 220);
  } catch {
    // Audio cues are optional; ignore browsers that block short sounds.
  }
}

function saved(key: string, fallback: string) { try { return localStorage.getItem(`gracie.${key}`) || fallback; } catch { return fallback; } }
function save(key: string, value: string) { try { localStorage.setItem(`gracie.${key}`, value); } catch { /* Settings storage can be unavailable. */ } }
