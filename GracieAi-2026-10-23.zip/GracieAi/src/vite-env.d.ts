/// <reference types="vite/client" />

export type GracieArtifact = {
  title: string;
  kind:
    | "text"
    | "markdown"
    | "code"
    | "table"
    | "notes"
    | "mermaid"
    | "image"
    | "imageLoading"
    | "thumbnailBoard"
    | "progress";
  content: string;
  language?: string;
  fullscreen?: boolean;
};

export type GracieToolSpec = {
  type: "function";
  name: string;
  description: string;
  parameters: Record<string, unknown>;
};

export type GracieToolCall = {
  name: string;
  arguments: Record<string, unknown>;
  taskId?:string;
};

export type GracieToolResult = {
  ok: boolean;
  artifact?: GracieArtifact;
  mode?: "display" | "computer";
  message?: string;
  error?: string;
  [key: string]: unknown;
};

export type SavedMemory = { id: string; text: string; source: string; updatedAt: string };
export type SavedEntry = { id: string; role: "user" | "gracie" | "system" | "tool"; text: string; at: string; provider: string };
export type MemorySnapshot = { entries: SavedEntry[]; memories: SavedMemory[]; count: number; hasOlder: boolean; warning: string };
export type Personality = { id: string; name: string; description: string; source: string };

export type OllamaStatus = {
  localOnly?: boolean;
  ok: boolean;
  available: boolean;
  url: string;
  models: string[];
  modelDetails?: { name: string; size: number; parameters: string; quantization: string; family: string; cloud?: boolean }[];
  defaultModel?: string;
  message?: string;
};

export type OllamaChatResult = {
  ok: boolean;
  model?: string;
  content?: string;
  error?: string;
  toolActivity?: string[];
  warning?: string;
  truncated?: boolean;
  paused?: boolean;
  projectResumed?: boolean;
  sources?: ResearchSource[];
  mode?: 'chat'|'build'|'agent';
  project?: AppProject;
};
export type AppProject={id:string;title:string;summary:string;revision:number;readyRevision:number;status:string;updatedAt:string;model?:string;cloud?:boolean;hasWindows?:boolean;outputFolder?:string;outputRevision?:number;nativeCapabilities?:string[];buildProgress?:{stage:string;strategy:string;completedParts:string[];history:string[];lastError:string;resumable:boolean};error?:string;sources?:ResearchSource[];checks?:{checks:string[];functional:number}};
export type AttachmentInfo = { id: string; name: string; kind: 'image' | 'document'; size: number; thumbnail?: string; truncated?: boolean };
export type ResearchSource = { id: number; title: string; url: string; excerpt: string };
export type PausedWork = { failure?:string; paused: boolean; completed: boolean; message: string; partial: string; model: string; savedAt: string; attachmentIds: string[]; files:AttachmentInfo[]; links:string[];researchMode:'auto'|'off'|'search'|'deep';fastMode:boolean;useLocalTools:boolean;sources: ResearchSource[];projectId?:string;workMode?:'chat'|'build'|'agent' };
export type ModelDownload = { name: string; active: boolean; status: string; completed: number; total: number; error: string; done: boolean };
export type CloudModel = { name: string; tag: string };

declare global {
  interface Window {
    gracie: {
      getLocalSpeechStatus: () => Promise<{transcription:boolean;synthesis:boolean;language:string;maxRecordingSeconds:number}>;
      transcribeLocalAudio: (input:{audio:string;mimeType:string}) => Promise<{text:string}>;
      synthesizeLocalSpeech: (input:{text:string}) => Promise<{audio:string;mimeType:string}>;
      cancelLocalSpeech: () => Promise<void>;
      getMemory: (beforeId?: string) => Promise<MemorySnapshot>;
      recordEntry: (entry: { role: string; text: string; provider: string }) => Promise<SavedEntry>;
      saveMemory: (memory: { id?: string; text: string }) => Promise<void>;
      forgetMemory: (id: string) => Promise<void>;
      getProfiles: () => Promise<Personality[]>;
      minimize: () => Promise<void>;
      close: () => Promise<void>;
      createRealtimeToken: (personality?: string) => Promise<{ value: string; expiresAt: number | null }>;
      captureScreen: () => Promise<{ dataUrl: string; displayWidth: number; displayHeight: number }>;
      executeTool: (toolCall: GracieToolCall) => Promise<GracieToolResult>;
      getToolSpecs: () => Promise<GracieToolSpec[]>;
      beginComputerTask:(message:string)=>Promise<{enabled:boolean;taskId?:string}>;
      endComputerTask:(taskId?:string)=>Promise<void>;
      stopComputerTask:()=>Promise<{ok:boolean}>;
      onComputerState:(callback:(state:{mode:'display'|'computer'})=>void)=>()=>void;
      reconnectOllama: () => Promise<OllamaStatus>;
      readClipboardText: () => Promise<string>;
      listOllamaApps:()=>Promise<{id:string;name:string;supported:boolean}[]>;
      launchOllamaApp:(input:{id:string;model:string})=>Promise<{opened:boolean;name:string;model:string}>;
      getOllamaStatus: () => Promise<OllamaStatus>;
      loadProjectCheckpoint:(id:string)=>Promise<PausedWork>;
      setProjectEdits:(enabled:boolean)=>Promise<{folder:string;allowEdits:boolean;allowChecks?:boolean}>;
      setProjectChecks:(enabled:boolean)=>Promise<{folder:string;allowEdits:boolean;allowChecks:boolean}>;
      listProjects:()=>Promise<AppProject[]>;
      getAppOutputSettings:()=>Promise<{folder:string}>;
      chooseAppOutputFolder:()=>Promise<{folder:string}>;
      openProject:(id:string)=>Promise<{ok:boolean}>;
      showProjectFolder:(id:string)=>Promise<{ok:boolean}>;
      downloadProject:(id:string,kind:'source'|'windows')=>Promise<{saved:boolean;path?:string}>;
      onOllamaChunk: (callback: (update: { requestId: string; text: string; warning?:string; stage?: string;mode?:'chat'|'build'|'agent' }) => void) => () => void;
      cancelOllamaChat: () => Promise<void>;
      chooseAttachments: () => Promise<{ files: AttachmentInfo[]; errors: string[] }>;
      getPausedWork: () => Promise<PausedWork | null>;
      pauseWork: (preferences?: {model: string}) => Promise<PausedWork | null>;
      updateBuild: (message: string) => Promise<PausedWork>;
      resumeWork: (requestId: string) => Promise<OllamaChatResult>;
      startNewTask: () => Promise<PausedWork | null>;
      openResearchSource: (url: string) => Promise<void>;
      getCodingFolder: () => Promise<{ folder: string; allowEdits?:boolean;allowChecks?:boolean }>;
      chooseCodingFolder: () => Promise<{ folder: string; allowEdits?:boolean;allowChecks?:boolean }>;
      clearCodingFolder: () => Promise<{ folder: string; allowEdits?:boolean;allowChecks?:boolean }>;
      getCloudModels: () => Promise<{ ok: boolean; models: CloudModel[]; error?: string }>;
      startModelDownload: (name: string) => Promise<{ ok: boolean; job?: ModelDownload; error?: string }>;
      getModelDownload: () => Promise<ModelDownload | null>;
      cancelModelDownload: () => Promise<ModelDownload | null>;
      openModelLibrary: (query?: string, cloud?: boolean) => Promise<void>;
      openCloudHelp: () => Promise<void>;
      chatWithOllama: (request: {
        message: string;
        requestId?: string;
        fastMode?: boolean;
        attachmentIds?: string[];
        links?: string[];
        researchMode?: 'auto' | 'auto' | 'off' | 'search' | 'deep';
        includeSavedContext?: boolean;
        useLocalTools?: boolean;
        model?: string;
        projectId?: string;
        workMode?: 'build'|'chat'|'agent';
        personality?: string;
        history?: Array<{ role: "user" | "assistant"; content: string }>;
      }) => Promise<OllamaChatResult>;
    };
  }
}
