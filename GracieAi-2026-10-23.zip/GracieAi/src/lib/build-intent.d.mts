export function isAppBuildRequest(message: string): boolean;
