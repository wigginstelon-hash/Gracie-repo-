import type { CSSProperties } from "react";
import type { MouthShape, GracieMood } from "../lib/realtime";
import realisticAvatar from "../assets/gracie-realistic-avatar.jpg";

type GracieFaceProps = {
  mood: GracieMood;
  mouthShape: MouthShape;
};

export function GracieFace({ mood, mouthShape }: GracieFaceProps) {
  return (
    <div
      className={`face realistic-avatar face-${mood}`}
      style={
        {
          "--voice-level": mouthShape.open.toFixed(3),
          "--voice-width": mouthShape.width.toFixed(3),
        } as CSSProperties
      }
      aria-label={`Gracie mood: ${mood}`}
    >
      <img className="realistic-avatar-photo" src={realisticAvatar} alt="Gracie, your AI companion" />
      <div className="realistic-avatar-light" aria-hidden="true" />
      <div className="realistic-avatar-presence" aria-hidden="true" />
      <div className="realistic-avatar-voice" aria-hidden="true">
        <span />
        <span />
        <span />
      </div>
    </div>
  );
}

