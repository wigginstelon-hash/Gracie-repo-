import { useEffect, useRef, type ReactNode } from 'react';

export function ActionMenu({label,icon,children,align='left'}:{label:string;icon:ReactNode;children:ReactNode;align?:'left'|'right'}){
  const root=useRef<HTMLDetailsElement>(null);
  useEffect(()=>{
    const outside=(event:PointerEvent)=>{if(root.current?.open&&!root.current.contains(event.target as Node))root.current.open=false;};
    const escape=(event:KeyboardEvent)=>{if(event.key==='Escape'&&root.current?.open){event.stopPropagation();root.current.open=false;root.current.querySelector('summary')?.focus();}};
    document.addEventListener('pointerdown',outside);document.addEventListener('keydown',escape);
    return()=>{document.removeEventListener('pointerdown',outside);document.removeEventListener('keydown',escape);};
  },[]);
  return <details ref={root} className={`action-menu action-menu-${align}`}><summary aria-label={label} title={label}>{icon}</summary><div className="action-menu-content" aria-label={label} onClick={event=>{if((event.target as Element).closest('button:not(:disabled)')&&root.current)root.current.open=false;}}>{children}</div></details>;
}
