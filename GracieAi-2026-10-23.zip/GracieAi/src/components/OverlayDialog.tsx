import { useEffect, useId, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

export function OverlayDialog({open,onClose,title,description,children,wide=false}:{open:boolean;onClose:()=>void;title:string;description?:string;children:ReactNode;wide?:boolean}) {
  const dialog=useRef<HTMLDialogElement>(null);
  const titleId=useId();
  useEffect(()=>{
    const element=dialog.current;if(!element)return;
    if(open&&!element.open)element.showModal();else if(!open&&element.open)element.close();
  },[open]);
  return <dialog ref={dialog} className={`calm-dialog ${wide?'calm-dialog-wide':''}`} aria-labelledby={titleId} onCancel={event=>{event.preventDefault();onClose();}} onClick={event=>{
    if(event.target!==event.currentTarget)return;
    const box=event.currentTarget.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)onClose();
  }}>
    <header className="dialog-heading"><div><h2 id={titleId}>{title}</h2>{description&&<p>{description}</p>}</div><button className="icon-button" onClick={onClose} aria-label={`Close ${title}`} title="Close"><X size={19}/></button></header>
    <div className="dialog-content">{children}</div>
  </dialog>;
}
