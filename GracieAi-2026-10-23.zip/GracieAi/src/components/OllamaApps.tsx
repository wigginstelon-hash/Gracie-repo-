import { useEffect, useState } from 'react';
import { ArrowUpRight, Terminal } from 'lucide-react';
type App = {id:string;name:string;supported:boolean};
export function OllamaApps({model,cloud,folder,onChooseModel}:{model:string;cloud:boolean;folder:string;onChooseModel:()=>void}) {
  const [apps,setApps]=useState<App[]>([]);
  const [loading,setLoading]=useState(true);
  const [pending,setPending]=useState('');
  const [error,setError]=useState('');
  const [message,setMessage]=useState('');
  async function refresh(){setLoading(true);setError('');try{setApps(await window.gracie.listOllamaApps());}catch(error){setError(String(error));}finally{setLoading(false);}}
  useEffect(()=>{void refresh();},[]);
  async function launch(app:App){setPending(app.id);setError('');setMessage('');try{const result=await window.gracie.launchOllamaApp({id:app.id,model});setMessage(`${result.name}: terminal opened with ${result.model}. Complete any setup prompts there; app startup and errors appear in that terminal.`);}catch(error){setError(String(error));}finally{setPending('');}}
  return <section className="surface-card ollama-apps" aria-label="Ollama apps">
    <div className="library-heading"><div><span className="eyebrow">POWERED BY OLLAMA</span><h2>Launch your tools.</h2></div><button className="quiet-button" disabled={loading||!!pending} onClick={()=>void refresh()}>{loading?'Checking…':'Refresh'}</button></div>
    <p>Open an app with your selected Ollama model. Ollama may offer installation or configuration in the terminal.</p>
    <div className="ollama-launch-context"><button className="quiet-button" disabled={!!pending} onClick={onChooseModel}>{model||'Choose a model'} · {cloud?'Ollama Cloud':'Local model'}</button><p>Working folder: {folder||'Gracie workspace'}</p></div>
    <p className="setting-note">App names identify the tool; the selected Ollama model supplies its answers. These apps run separately from Gracie and manage their own settings and sessions.</p>
    {error&&<p role="alert">{error}</p>}{message&&<p role="status">{message}</p>}
    <div className="ollama-app-grid">{apps.map(app=><button className="ollama-app-tile" key={app.id} disabled={!app.supported||!model||!!pending||loading} onClick={()=>void launch(app)} title={!app.supported?'Update Ollama to enable this integration':`Open ${app.name} with ${model}`}><span className="ollama-app-mark" aria-hidden="true">{app.id==='terminal'?<Terminal size={20}/>:app.name.slice(0,2)}</span><span><strong>{app.name}</strong><small>{pending===app.id?'Opening terminal…':app.supported?'Launch with Ollama':'Requires newer Ollama'}</small></span><ArrowUpRight size={16} aria-hidden="true"/></button>)}</div>
  </section>;
}
