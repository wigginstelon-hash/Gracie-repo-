import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, Sparkles } from 'lucide-react';
import type { TranscriptEntry } from '../lib/realtime';
import type { ResearchSource } from '../vite-env';

export function ChatPanel({active,entries,sending,model,error,workStage,sources,onOpenSource,hasOlder,onLoadOlder}:{active:boolean;entries:TranscriptEntry[];sending:boolean;model:string;error:string;workStage:string;sources:ResearchSource[];onOpenSource:(url:string)=>void;hasOlder:boolean;onLoadOlder:()=>void}) {
  const scroll=useRef<HTMLDivElement>(null);
  const pinned=useRef(true);
  const loadingOlder=useRef(false);
  const [away,setAway]=useState(false);
  const [elapsed,setElapsed]=useState(0);
  const messages=entries.filter(entry=>entry.role==='user'||entry.role==='gracie').slice().reverse();
  useEffect(()=>{if(!sending){setElapsed(0);return;}const started=Date.now();const timer=window.setInterval(()=>setElapsed(Math.floor((Date.now()-started)/1000)),1000);return()=>window.clearInterval(timer);},[sending]);
  useEffect(()=>{const element=scroll.current;if(!element||!active)return;if(loadingOlder.current){loadingOlder.current=false;return;}if(pinned.current)element.scrollTop=element.scrollHeight;},[active,entries,sending]);
  function jump(){const element=scroll.current;if(element){element.scrollTop=element.scrollHeight;pinned.current=true;setAway(false);}}
  return <div className="conversation-surface"><div ref={scroll} className="conversation-scroll" onScroll={event=>{if(!active)return;const element=event.currentTarget;pinned.current=element.scrollHeight-element.scrollTop-element.clientHeight<100;setAway(!pinned.current);}}><div className="conversation-content">
    {hasOlder&&<button className="older-messages" onClick={()=>{loadingOlder.current=true;onLoadOlder();}}>Earlier messages</button>}
    {!messages.length&&<div className="conversation-welcome"><span className="welcome-glyph" aria-hidden="true"><Sparkles size={30} strokeWidth={1.3}/></span><span className="eyebrow">A LITTLE SPACE FOR WHAT’S NEXT</span><h2>What’s on your mind?</h2><p>Talk it through. Research an idea.<br/>Or describe an app you’d love to make.</p></div>}
    <div role="log" aria-label="Chat messages" aria-live="polite" aria-relevant="additions text">{messages.map(entry=><article key={entry.id} className={`message message-${entry.role}`}><div className="message-label"><span>{entry.role==='user'?'You':'Gracie'}</span>{entry.role==='gracie'&&<span className="message-star" aria-hidden="true">✳</span>}</div>{entry.text.length>4000?<details className="long-message" open><summary>{entry.text.slice(0,180)}… <span>Read full message</span></summary><p>{entry.text}</p></details>:<p>{entry.text||(sending?<span className="thinking-text"><span className="thinking-dots" aria-hidden="true"><i/><i/><i/></span> {workStage||'Gracie is thinking…'}</span>:'')}</p>}</article>)}</div>
    {sending&&<div className="conversation-progress" role="status"><span className="thinking-dots" aria-hidden="true"><i/><i/><i/></span><span>Working with {model||'your model'} · {elapsed}s</span></div>}
    {!!sources.length&&<details className="source-disclosure"><summary>{sources.length} reference{sources.length===1?'':'s'} used</summary><div>{sources.map(source=><button key={source.url} onClick={()=>onOpenSource(source.url)}><span><strong>[{source.id}] {source.title}</strong><small>{source.url}</small></span><ArrowUpRight size={15}/></button>)}</div></details>}
    {error&&<p className="conversation-error" role="alert">{error}</p>}
  </div></div>{away&&<button className="jump-latest" onClick={jump} aria-label="Jump to latest message"><ArrowDown size={15}/>Latest</button>}</div>;
}
