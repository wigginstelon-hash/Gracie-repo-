import { useEffect, useRef, useState } from 'react';
import { Mic, Square, Volume2 } from 'lucide-react';

export function LocalVoice({ disabled, reply, onTranscript }: { disabled: boolean; reply: string; onTranscript: (text: string) => void }) {
  const [ready, setReady] = useState({ transcription: false, synthesis: false });
  const [phase, setPhase] = useState<'idle' | 'opening' | 'recording' | 'transcribing' | 'speaking'>('idle');
  const [message, setMessage] = useState('');
  const recorder = useRef<MediaRecorder | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const player = useRef<HTMLAudioElement | null>(null);
  const playerUrl = useRef('');
  const generation = useRef(0);
  const mounted = useRef(true);
  function releaseMicrophone() { stream.current?.getTracks().forEach(track => track.stop()); stream.current = null; clearTimeout(timer.current); }
  function releasePlayer() { player.current?.pause(); player.current = null; if (playerUrl.current) URL.revokeObjectURL(playerUrl.current); playerUrl.current = ''; }
  useEffect(() => {
    mounted.current = true;
    void window.gracie.getLocalSpeechStatus().then(result => { if (mounted.current) setReady(result); }).catch(() => {});
    return () => { mounted.current = false; generation.current++; if (recorder.current?.state === 'recording') recorder.current.stop(); releaseMicrophone(); releasePlayer(); void window.gracie.cancelLocalSpeech(); };
  }, []);
  function stop() {
    generation.current++;
    if (recorder.current?.state === 'recording') recorder.current.stop();
    releaseMicrophone(); releasePlayer(); void window.gracie.cancelLocalSpeech(); setPhase('idle'); setMessage('Stopped.');
  }
  useEffect(() => { if (disabled && phase !== 'idle') stop(); }, [disabled]);
  async function record() {
    if (phase === 'recording') { recorder.current?.stop(); releaseMicrophone(); return; }
    if (disabled || phase !== 'idle') return;
    const id = ++generation.current; setMessage('Opening microphone…'); setPhase('opening');
    try {
      const input = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true }, video: false });
      if (!mounted.current || generation.current !== id) { input.getTracks().forEach(track => track.stop()); return; }
      stream.current = input;
      const mimeType = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/webm'].find(type => MediaRecorder.isTypeSupported(type));
      if (!mimeType) throw Error('This runtime cannot record a supported audio format.');
      const recording = new MediaRecorder(input, { mimeType }); recorder.current = recording;
      const chunks: Blob[] = []; let bytes = 0;
      recording.ondataavailable = event => { if (event.data.size) { bytes += event.data.size; chunks.push(event.data); if (bytes > 8 * 1024 * 1024) recording.stop(); } };
      recording.onerror = () => { releaseMicrophone(); if (generation.current === id) { setPhase('idle'); setMessage('Microphone recording failed. Try again.'); } };
      recording.onstop = () => {
        releaseMicrophone(); recorder.current = null;
        if (!mounted.current || generation.current !== id) return;
        setPhase('transcribing'); setMessage('Transcribing on this PC…');
        const blob = new Blob(chunks, { type: mimeType });
        if (!blob.size || bytes > 8 * 1024 * 1024) { setPhase('idle'); setMessage('Recording was empty or too large. Try a shorter recording.'); return; }
        const reader = new FileReader();
        reader.onerror = () => { if (generation.current === id) { setPhase('idle'); setMessage('Could not read this recording.'); } };
        reader.onload = () => {
          if (generation.current !== id || !mounted.current) return;
          const audio = String(reader.result).split(',')[1];
          void window.gracie.transcribeLocalAudio({ audio, mimeType }).then(result => {
            if (generation.current !== id || !mounted.current) return;
            if (result.text) { onTranscript(result.text); setMessage('Transcription added. Review it, then press Send.'); }
            else setMessage('No speech detected. Try again.');
          }).catch(error => { if (generation.current === id && mounted.current) setMessage(String(error)); })
            .finally(() => { if (generation.current === id && mounted.current) setPhase('idle'); });
        };
        reader.readAsDataURL(blob);
      };
      recording.start(1000); setPhase('recording'); setMessage('Listening locally · tap microphone to finish · 45-second limit');
      timer.current = setTimeout(() => { if (recording.state === 'recording') recording.stop(); }, 45000);
    } catch (error) { releaseMicrophone(); if (mounted.current && generation.current === id) { setPhase('idle'); setMessage(String(error)); } }
  }
  async function speak() {
    if (disabled || phase !== 'idle' || !reply.trim()) return;
    const id = ++generation.current; setPhase('speaking'); setMessage('Preparing Windows speech on this PC…');
    try {
      const result = await window.gracie.synthesizeLocalSpeech({ text: reply.slice(0, 4000) });
      if (!mounted.current || generation.current !== id) return;
      const bytes = Uint8Array.from(atob(result.audio), character => character.charCodeAt(0));
      playerUrl.current = URL.createObjectURL(new Blob([bytes], { type: result.mimeType }));
      const audio = new Audio(playerUrl.current); player.current = audio;
      audio.onended = () => { releasePlayer(); if (mounted.current && generation.current === id) { setPhase('idle'); setMessage(reply.length > 4000 ? 'Read the first 4,000 characters.' : 'Finished reading.'); } };
      audio.onerror = () => { releasePlayer(); if (mounted.current && generation.current === id) { setPhase('idle'); setMessage('Audio playback failed. Check your output device.'); } };
      await audio.play(); if (generation.current === id) setMessage('Reading locally · Stop ends playback');
    } catch (error) { releasePlayer(); if (mounted.current && generation.current === id) { setPhase('idle'); setMessage(String(error)); } }
  }
  return <div className="local-voice-controls">
    <button className={`icon-button ${phase === 'recording' ? 'is-active' : ''}`} onClick={() => void record()} disabled={disabled || !ready.transcription || (phase !== 'idle' && phase !== 'recording')} aria-label={phase === 'recording' ? 'Finish local recording' : 'Record local voice message'} title={ready.transcription ? 'Transcribe English speech on this PC; review before sending' : 'Run local speech setup to enable microphone transcription'}><Mic size={18}/></button>
    <button className="icon-button" onClick={() => void speak()} disabled={disabled || !ready.synthesis || !reply.trim() || phase !== 'idle'} aria-label="Read latest reply aloud" title="Read the latest reply using an installed Windows voice"><Volume2 size={18}/></button>
    {phase !== 'idle' && <button className="icon-button" onClick={stop} aria-label="Stop local speech"><Square size={16}/></button>}
    {message && <span className="local-voice-status" role="status">{message}</span>}
  </div>;
}
