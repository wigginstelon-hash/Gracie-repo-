import { useEffect, useRef, useState } from 'react';
import type { CloudModel, ModelDownload, OllamaStatus } from '../vite-env';

export function ModelFinder({ open, onClose, status, selected, onSelect, onRefresh, busy }: {
  open: boolean; onClose: () => void; status: OllamaStatus | null; selected: string;
  onSelect: (name: string) => void; onRefresh: () => Promise<unknown>; busy: boolean;
}) {
  const [tab, setTab] = useState<'installed' | 'discover' | 'cloud'>('installed');
  const [query, setQuery] = useState('');
  const [tag, setTag] = useState('');
  const [cloud, setCloud] = useState<CloudModel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [job, setJob] = useState<ModelDownload | null>(null);
  const [review, setReview] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null);
  const completed = useRef('');

  useEffect(() => {
    if (open && !dialog.current?.open) dialog.current?.showModal();
    else if (!open && dialog.current?.open) dialog.current.close();
  }, [open]);
  useEffect(() => {
    if (!open) return;
    let disposed = false;
    const poll = async () => {
      try {
        const next = await window.gracie.getModelDownload();
        if (disposed) return;
        setJob(next);
        if (next?.done && !next.error && completed.current !== next.name) {
          completed.current = next.name; await onRefresh();
        }
      } catch { if (!disposed) setError('Could not check the download. Reopen Find a model to retry.'); }
    };
    void poll(); const timer = window.setInterval(() => void poll(), 1000);
    return () => { disposed = true; clearInterval(timer); };
  }, [open, onRefresh]);
  useEffect(() => {
    if (open && tab === 'cloud') void loadCloud();
  }, [open, tab]);
  async function loadCloud() {
    setLoading(true); setError('');
    try {
      const result = await window.gracie.getCloudModels();
      if (!result.ok) throw new Error(result.error || 'Cloud catalog unavailable.');
      setCloud(result.models);
    } catch (e) { setError(String(e instanceof Error ? e.message : e)); }
    finally { setLoading(false); }
  }
  async function download() {
    setError(''); setReview(false);
    try {
      const result = await window.gracie.startModelDownload(tag.trim());
      if (!result.ok) throw new Error(result.error || 'Could not start the download.');
      completed.current = ''; setJob(result.job || null);
    } catch (e) { setError(String(e instanceof Error ? e.message : e)); }
  }
  async function external(action: () => Promise<void>) {
    try { await action(); } catch { setError('Could not open your browser. Visit ollama.com/search.'); }
  }
  const matches = (name: string) => name.toLowerCase().includes(query.toLowerCase().trim());
  const installed = (status?.models || []).filter(matches);
  const cloudModels = cloud.filter(m => matches(m.name));
  const select = (name: string) => { onSelect(name); onClose(); };

  return <dialog ref={dialog} className="model-finder" aria-labelledby="model-finder-title" onCancel={onClose} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="finder-heading"><div><span className="eyebrow">OLLAMA MODEL LIBRARY</span><h2 id="model-finder-title">Find a model</h2></div><button aria-label="Close model finder" onClick={onClose}>×</button></div>
    <input autoFocus className="finder-search" aria-label="Find a model" placeholder="Find a model…" value={query} onChange={e => setQuery(e.target.value)} />
    <div className="finder-tabs" role="tablist" aria-label="Model sources">
      {(['installed', 'discover', 'cloud'] as const).map(value => <button key={value} role="tab" id={`finder-tab-${value}`} aria-controls="finder-content" aria-selected={tab === value} onClick={() => { setTab(value); setError(''); setReview(false); }}>{value === 'installed' ? `Installed · ${status?.models.length || 0}` : value === 'discover' ? 'Discover & download' : 'Ollama Cloud'}</button>)}
    </div>
    <div id="finder-content" role="tabpanel" aria-labelledby={`finder-tab-${tab}`} className="finder-content">
      {tab === 'installed' && <>
        <p className="finder-note">Choose any installed Ollama chat model, including imported weights. Ollama controls loading; large models may be slow or fail if memory is insufficient.</p>
        {!status?.available && <p role="status">Ollama is offline. Open its desktop app, then refresh.</p>}
        {status?.available && !installed.length && <p>No matching installed models. Try Discover & download.</p>}
        {installed.map(name => { const details = status?.modelDetails?.find(m => m.name === name); return <button className="finder-model" key={name} disabled={busy || !status?.available} onClick={() => select(name)}>
          <span><strong>{name}</strong><small>{[details?.parameters, details?.cloud ? 'Runs in Ollama Cloud' : details?.size ? `${(details.size / 1e9).toFixed(1)} GB · On this PC` : 'On this PC', details?.quantization].filter(Boolean).join(' · ')}</small></span><span className="finder-badge">{selected === name ? 'Selected ✓' : details?.cloud ? 'Cloud' : 'Use model'}</span>
        </button>; })}
        <button className="finder-secondary" onClick={() => void onRefresh()}>Refresh installed models</button>
      </>}
      {tab === 'discover' && <>
        <h3>Explore Ollama’s full library</h3><p className="finder-note">Search the official library in your browser to compare models, sizes, and exact tags. Full-library results are not mirrored inside Gracie.</p>
        <button className="finder-primary" onClick={() => void external(() => window.gracie.openModelLibrary(query))}>Search library{query.trim() ? ` for “${query.trim()}”` : ''} ↗</button>
        <div className="finder-download"><h3>Download a model to this PC</h3><p className="finder-note">Copy an exact model tag from the library. Downloads can use several GB of storage and internet data. They run only after you start them.</p>
          <label htmlFor="model-download-tag">Model tag</label><input id="model-download-tag" placeholder="e.g. qwen3:4b" value={tag} disabled={job?.active} onChange={e => { setTag(e.target.value); setReview(false); }} />
          {!review ? <button className="finder-primary" disabled={!tag.trim() || job?.active || !status?.available} onClick={() => setReview(true)}>Review download</button> : <div className="finder-review"><p>Download <strong>{tag.trim()}</strong> into Ollama’s library on this PC? Check its size in the official library first.</p><button className="finder-primary" onClick={() => void download()}>Start download</button><button className="finder-secondary" onClick={() => setReview(false)}>Go back</button></div>}
          {!status?.available && <p>Open Ollama and refresh before downloading.</p>}
        </div>
      </>}
      {tab === 'cloud' && <>
        <p className="finder-cloud-note">Runs on Ollama’s servers. Sending shares your current message with Ollama Cloud; your account’s usage limits or charges apply. Saved memory and chat history stay on this PC unless you enable “Include saved context” in the chat settings. Sign in through the Ollama app first.</p>
        <div className="finder-toolbar"><button className="finder-secondary" onClick={() => void loadCloud()} disabled={loading}>Refresh cloud list</button><button className="finder-secondary" onClick={() => void external(() => window.gracie.openCloudHelp())}>Cloud & sign-in help ↗</button></div>
        {loading && <p role="status">Loading Ollama’s live cloud catalog…</p>}
        {!loading && !error && !cloudModels.length && <p>No matching cloud models.</p>}
        {!loading && cloudModels.map(item => <button className="finder-model" key={item.tag} disabled={busy || !status?.available} onClick={() => select(item.tag)}><span><strong>{item.name}</strong><small>No weight download · Requires Ollama sign-in</small></span><span className="finder-badge cloud">{selected === item.tag ? 'Selected ✓' : 'Use cloud'}</span></button>)}
        {!status?.available && <p>Open Ollama to use a cloud model through your signed-in app.</p>}
        <button className="finder-secondary" onClick={() => void external(() => window.gracie.openModelLibrary(query, true))}>Browse official cloud library ↗</button>
      </>}
    </div>
    {job && <div className="finder-progress" role="status" aria-live="polite"><strong>{job.name}</strong><p>{job.error || (job.done ? 'Ready in Ollama’s installed library.' : job.status)}</p>{job.active && <><progress max={job.total || 1} value={job.total ? job.completed : undefined} /><small>{job.total ? `${(job.completed / 1e9).toFixed(2)} / ${(job.total / 1e9).toFixed(2)} GB · current layer` : 'Preparing download…'}</small><button className="finder-secondary" onClick={() => void window.gracie.cancelModelDownload().catch(() => setError('Could not stop the download. Try again.'))}>Stop download</button></>}{job.done && !job.error && <button disabled={busy} className="finder-primary" onClick={() => select(job.name)}>Use downloaded model</button>}</div>}
    {error && <p className="finder-error" role="alert">{error}</p>}
  </dialog>;
}
