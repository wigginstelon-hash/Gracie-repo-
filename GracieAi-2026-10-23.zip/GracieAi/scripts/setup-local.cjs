const {setupLocalAssistant}=require('../electron/local-assistant.cjs');
const {createOllamaClient}=require('../electron/ollama.cjs');
const {spawn}=require('node:child_process');
const fs=require('node:fs/promises');
const path=require('node:path');
async function main(){
  const client=createOllamaClient();
  client.baseUrl();
  let state=await client.status();
  if(!state.available&&process.platform==='win32'){
    const exe=path.join(process.env.LOCALAPPDATA||'','Programs','Ollama','ollama app.exe');
    await fs.access(exe);
    await new Promise((resolve,reject)=>{const child=spawn(exe,[],{detached:true,stdio:'ignore',windowsHide:true});child.once('error',reject);child.once('spawn',()=>{child.unref();resolve();});});
    for(let attempt=0;attempt<30&&!state.available;attempt++){await new Promise(resolve=>setTimeout(resolve,1000));state=await client.status();}
  }
  if(!state.available)throw Error(state.message||'Open Ollama and try again.');
  const result=await setupLocalAssistant({baseModel:process.argv[2]||'qwen3.5:4b',url:client.baseUrl()});
  console.log((result.created?'Created':'Using existing')+' local Gracie profile: '+result.name);
  console.log('This profile reuses installed local weights. It is not a newly trained foundation model. Memory remains in Gracie data files.');
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
