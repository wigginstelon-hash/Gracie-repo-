import pathlib
import sys
import win32com.client

text_file, output_file = sys.argv[1:3]
text = pathlib.Path(text_file).read_text(encoding='utf-8')
voice = win32com.client.Dispatch('SAPI.SpVoice')
stream = win32com.client.Dispatch('SAPI.SpFileStream')
try:
    stream.Open(str(pathlib.Path(output_file).resolve()), 3, False)
    voice.AudioOutputStream = stream
    voice.Speak(text, 16)  # SVSFIsNotXML: model replies are plain text, never SSML.
finally:
    stream.Close()
