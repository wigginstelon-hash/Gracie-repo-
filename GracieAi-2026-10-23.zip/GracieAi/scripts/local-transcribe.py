import json
import os
import sys

os.environ['HF_HUB_OFFLINE'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
from faster_whisper import WhisperModel
import av
import numpy as np

model_folder, audio_file = sys.argv[1:3]
chunks = []
samples = 0
resampler = av.AudioResampler(format='s16', layout='mono', rate=16000)
with av.open(audio_file, mode='r') as container:
    for frame in container.decode(audio=0):
        for converted in resampler.resample(frame):
            samples += converted.samples
            if samples > 46 * 16000:
                raise ValueError('Recording exceeds the 45-second limit.')
            chunks.append(converted.to_ndarray().flatten().astype(np.float32) / 32768.0)
    for converted in resampler.resample(None):
        samples += converted.samples
        if samples > 46 * 16000:
            raise ValueError('Recording exceeds the 45-second limit.')
        chunks.append(converted.to_ndarray().flatten().astype(np.float32) / 32768.0)
audio = np.concatenate(chunks) if chunks else np.empty(0, dtype=np.float32)
if len(audio) < 1600:
    print(json.dumps({'text': ''}))
    sys.exit(0)
model = WhisperModel(model_folder, device='cpu', compute_type='int8', cpu_threads=4, local_files_only=True)
segments, info = model.transcribe(audio, language='en', beam_size=3, condition_on_previous_text=False, vad_filter=True)
text = ' '.join(segment.text.strip() for segment in segments).strip()
print(json.dumps({'text': text}, ensure_ascii=False))
