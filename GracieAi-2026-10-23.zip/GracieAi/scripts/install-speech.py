import json
import pathlib
import sys
from huggingface_hub import HfApi, snapshot_download

folder = pathlib.Path(sys.argv[1])
repo = 'Systran/faster-whisper-tiny.en'
revision = HfApi().model_info(repo).sha
snapshot_download(repo, revision=revision, local_dir=str(folder),
                  allow_patterns=['config.json', 'model.bin', 'tokenizer.json', 'vocabulary.json', 'vocabulary.txt', 'preprocessor_config.json'])
(folder / 'gracie-model-source.json').write_text(json.dumps({'repository': repo, 'revision': revision}, indent=2))
print('Local English transcription model is ready.')
