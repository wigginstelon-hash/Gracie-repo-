const path = require('node:path');
const fs = require('node:fs/promises');
const { spawn } = require('node:child_process');
const root = path.resolve(__dirname, '..');
function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: 'inherit', windowsHide: true });
    child.once('error', reject); child.once('close', code => code === 0 ? resolve() : reject(Error('Local speech setup failed. Check that 64-bit Python 3.14 is installed and internet access is available for setup.')));
  });
}
(async () => {
  if (process.platform !== 'win32') throw Error('This local speech setup requires Windows and 64-bit Python 3.14.');
  const folder = path.join(root, 'models', 'speech'), venv = path.join(folder, 'venv');
  await fs.mkdir(folder, { recursive: true });
  const python = path.join(venv, 'Scripts', 'python.exe');
  if (!(await fs.access(python).then(() => true, () => false))) await run('py', ['-3.14', '-m', 'venv', venv]);
  await run(python, ['-m', 'pip', 'install', '--only-binary=:all:', '-r', path.join(__dirname, 'speech-requirements.txt')]);
  await run(python, [path.join(__dirname, 'install-speech.py'), path.join(folder, 'whisper-tiny.en')]);
  console.log('Local speech is installed. Restart Gracie to refresh its controls. Runtime transcription uses local files only.');
})().catch(error => { console.error(error.message); process.exitCode = 1; });
