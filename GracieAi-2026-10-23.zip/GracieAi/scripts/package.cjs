const fs = require('node:fs/promises');
const { createWriteStream } = require('node:fs');
const path = require('node:path');
const { createHash } = require('node:crypto');
const { pipeline } = require('node:stream/promises');
const archiver = require('archiver');

async function main() {
  const root = path.resolve(__dirname, '..');
  const filename = 'GracieAi-2026-10-23.zip';
  const output = path.join(root, '..', filename);
  const temporary = output + '.tmp';
  // An explicit content list keeps credentials, user data and dependencies out.
  const entries = ['.env.example', '.gitattributes', '.gitignore', 'LICENSE', 'README.md',
    'Start-GracieAi.bat', 'Start-GracieAi-Local.bat', 'Start-GracieAi-Online.bat', 'Setup-Local-Speech.bat', 'dist', 'electron', 'src', 'scripts', 'index.html',
    'local-models.json', 'package-lock.json', 'package.json', 'tsconfig.json', 'vite.config.ts'];
  await fs.access(path.join(root, 'dist/index.html'));
  const archive = archiver('zip', { zlib: { level: 9 } });
  archive.on('warning', error => archive.destroy(error));
  const completion = pipeline(archive, createWriteStream(temporary));
  completion.catch(() => {}); // Register rejection handling while entries are collected.
  async function append(relative) {
    const absolute = path.join(root, relative);
    const info = await fs.lstat(absolute);
    if (info.isSymbolicLink()) throw Error('Refusing to package symlink: ' + relative);
    if (info.isDirectory()) {
      for (const child of (await fs.readdir(absolute)).sort()) await append(path.join(relative, child));
    } else if (info.isFile()) {
      archive.file(absolute, { name: 'GracieAi/' + relative.split(path.sep).join('/') });
    } else throw Error('Unsupported package entry: ' + relative);
  }
  try {
    for (const entry of entries) await append(entry);
    await Promise.all([archive.finalize(), completion]);
    await fs.rename(temporary, output);
    const checksum = createHash('sha256').update(await fs.readFile(output)).digest('hex');
    await fs.writeFile(output.replace(/\.zip$/, '.sha256'), checksum + '  ' + filename + '\n');
    console.log('Packaged ' + filename + '\nSHA-256: ' + checksum);
  } catch (error) {
    archive.destroy(error);
    await completion.catch(() => {});
    await fs.rm(temporary, { force: true });
    throw error;
  }
}
main().catch(error => { console.error(error); process.exitCode = 1; });
