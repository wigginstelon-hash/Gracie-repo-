const os=require('node:os');
const {createOllamaClient}=require('../electron/ollama.cjs');
async function main(){
 const client=createOllamaClient();const status=await client.status();
 console.log(JSON.stringify({node:process.version,platform:process.platform,ramGiB:Number((os.totalmem()/1024**3).toFixed(2)),freeRamGiB:Number((os.freemem()/1024**3).toFixed(2)),localOnly:process.env.GRACIE_LOCAL_ONLY==='1',ollamaAvailable:status.available,message:status.message,defaultModel:status.defaultModel,models:status.modelDetails?.map(({name,size,parameters,cloud})=>({name,sizeGiB:Number((size/1024**3).toFixed(2)),parameters,cloud}))},null,2));
 if(!status.available)process.exitCode=1;
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
