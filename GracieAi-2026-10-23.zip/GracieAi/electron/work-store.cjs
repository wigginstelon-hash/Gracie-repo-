const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const {renameWithRetry}=require('./atomic-file.cjs');
function createWorkStore(directory) {
  const file = path.join(directory, 'paused-work.json');
  let queue = Promise.resolve();
  function save(state) {
    const serialized = JSON.stringify({ ...state, savedAt: new Date().toISOString() });
    if (Buffer.byteLength(serialized) > 20 * 1024 * 1024) throw new Error('This work checkpoint is too large to save.');
    const result = queue.then(async () => {
      await fs.mkdir(directory, {recursive:true});
      const temporary = `${file}.${crypto.randomUUID()}.tmp`;
      await fs.writeFile(temporary, serialized, { mode: 0o600 }); await renameWithRetry(temporary, file);
    });
    queue = result.catch(()=>{}); return result;
  }
  async function load() { await queue; try { return JSON.parse(await fs.readFile(file,'utf8')); } catch(e) { if(e.code==='ENOENT')return null; throw new Error('The saved checkpoint could not be read. It has been preserved.'); } }
  async function clear() { await queue; await fs.unlink(file).catch(e=>{if(e.code!=='ENOENT')throw e;}); }
  return {save,load,clear};
}
module.exports = { createWorkStore };
