// One inference-time personality adapted from the bundled Heretic themes.
const original = require('./gracie-personality.json');
const { applyStandards } = require('./engineering-standards.cjs');
const personality = { ...original, prompt: applyStandards(original.prompt) };
// Legacy profile IDs all resolve to the same Gracie.
module.exports = { personality, getProfile: () => personality, profiles: [personality] };
