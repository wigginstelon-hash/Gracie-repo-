const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {createProjectChecks}=require('./project-checks.cjs');
const {createLocalTools}=require('./local-tools.cjs');
async function fixture(t,scripts={test:'node check.cjs'}){
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-checks-'));
 t.after(()=>fs.rm(root,{recursive:true,force:true}));
 await fs.writeFile(path.join(root,'package.json'),JSON.stringify({scripts}));
 await fs.writeFile(path.join(root,'check.cjs'),'console.log("real output");process.exit(7);');
 return root;
}
test('script checks report real failures and output; reject disabled, arbitrary, and absent commands',async t=>{
 const root=await fixture(t);let enabled=false;
 const checks=createProjectChecks({getRoot:()=>root,isEnabled:()=>enabled});
 await assert.rejects(checks.run('test'),/Allow project checks/);enabled=true;
 await assert.rejects(checks.run('test && whoami'),/Command strings/);
 await assert.rejects(checks.run('build'),/no build script/);
 const result=await checks.run('test');assert.equal(result.ok,false);assert.equal(result.exitCode,7);assert.match(result.output,/real output/);assert.equal(result.executed,true);
});
test('permission is per selected folder and cloud cannot run project checks',async t=>{
 const root=await fixture(t);const tools=createLocalTools();await tools.setProjectRoot(root);
 assert.equal((await tools.execute('project_run_check',{script:'test'},{enabled:true})).ok,false);
 tools.setCheckPermission(true);assert.equal(tools.projectStatus().allowChecks,true);
 assert.equal((await tools.execute('project_run_check',{script:'test'},{enabled:true,cloud:true})).ok,false);
 assert.equal((await tools.execute('project_run_check',{script:'test',command:'whoami'},{enabled:true})).ok,false);
 await tools.setProjectRoot(root);assert.equal(tools.projectStatus().allowChecks,true);
 const other=path.join(root,'other');await fs.mkdir(other);await tools.setProjectRoot(other);assert.equal(tools.projectStatus().allowChecks,false);
});
test('script timeout and cancellation terminate the running process tree',async t=>{
 const root=await fixture(t);await fs.writeFile(path.join(root,'check.cjs'),'setInterval(()=>{},1000);');
 const timeout=createProjectChecks({getRoot:()=>root,isEnabled:()=>true,timeoutMs:500});
 const result=await timeout.run('test');assert.equal(result.ok,false);assert.equal(result.timedOut,true);
 const controller=new AbortController();const checks=createProjectChecks({getRoot:()=>root,isEnabled:()=>true});
 const task=checks.run('test',{signal:controller.signal});setTimeout(()=>controller.abort(),500);
 const cancelled=await task;assert.equal(cancelled.ok,false);assert.equal(cancelled.cancelled,true);
});
module.exports={fixture};
