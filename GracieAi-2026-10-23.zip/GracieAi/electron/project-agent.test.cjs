const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto');
const {createProjectAgent}=require('./project-agent.cjs');
const {createLocalTools}=require('./local-tools.cjs');
const action=(type,extras={})=>({action:type,path:'',query:'',offset:0,content:'',expectedHash:null,script:'none',summary:'Observed task results',...extras});
async function fixture(t){
 const root=await fs.realpath(await fs.mkdtemp(path.join(os.tmpdir(),'gracie-agent-')));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 await fs.writeFile(path.join(root,'package.json'),JSON.stringify({scripts:{test:'node --test verify.cjs'}}));
 await fs.writeFile(path.join(root,'sum.cjs'),'module.exports=(a,b)=>a-b;');
 await fs.writeFile(path.join(root,'verify.cjs'),"const test=require('node:test'),assert=require('node:assert/strict');test('adds positive and negative values',()=>{const sum=require('./sum.cjs');assert.equal(sum(2,3),5);assert.equal(sum(-2,3),1);});");
 const tools=createLocalTools();await tools.setProjectRoot(root);tools.setEditPermission(true);tools.setCheckPermission(true);return {root,tools};
}
test('helpers observe a real failing test, edit conflict-safely, rerun successfully, and review',async t=>{
 const {root,tools}=await fixture(t);const digest=crypto.createHash('sha256').update('module.exports=(a,b)=>a-b;').digest('hex');
 const queue=[{steps:['Inspect implementation','Repair addition','Run tests']},action('read',{path:'sum.cjs'}),action('run',{script:'test'}),action('write',{path:'sum.cjs',expectedHash:digest,content:'module.exports=(a,b)=>a+b;'}),action('run',{script:'test'}),action('finish'),action('finish')];
 const states=[],prompts=[];const agent=createProjectAgent({tools,complete:async input=>{prompts.push(input);return {content:JSON.stringify(queue.shift())};}});
 const result=await agent.run({message:'Fix addition without weakening tests',model:'local',onCheckpoint:async state=>states.push(state)});
 assert.equal(result.ok,true);assert.match(result.content,/Verified scripts: test/);assert.match(await fs.readFile(path.join(root,'sum.cjs'),'utf8'),/a\+b/);
 const events=states.at(-1).events.filter(e=>e.action==='run');assert.equal(events.length,2);assert.equal(events[0].result.ok,false,JSON.stringify(events[0].result));assert.equal(events[1].result.ok,true);
 assert.ok(states.some(s=>s.pending?.action==='write'));assert.ok(prompts.some(p=>p.messages[0].content.includes('Reviewer helper')));
});
test('completion cannot reuse a passed test from before the latest edit',async t=>{
 const {tools}=await fixture(t);let calls=0;const digest=crypto.createHash('sha256').update('module.exports=(a,b)=>a-b;').digest('hex');
 const queue=[{steps:['Repair addition']},action('read',{path:'sum.cjs'}),action('write',{path:'sum.cjs',expectedHash:digest,content:'module.exports=(a,b)=>a+b;'}),action('finish'),action('finish')];
 const agent=createProjectAgent({tools,maxSteps:8,complete:async()=>({content:JSON.stringify(queue[calls++]||action('finish'))})});
 await assert.rejects(agent.run({message:'Fix addition',model:'local'}),/action limit/);
});
test('interrupted actions are reported uncertain instead of replayed and folder/model mismatches stop resume',async t=>{
 const {root,tools}=await fixture(t);let saved;
 const agent=createProjectAgent({tools,maxSteps:1,complete:async()=>({content:JSON.stringify(action('read',{path:'sum.cjs'}))})});
 const checkpoint={kind:'agent',version:1,root,model:'local',message:'Fix',phase:'build',plan:['Inspect'],events:[],steps:1,pending:{action:'write',path:'sum.cjs'},edited:[],checks:[],editVersion:0};
 await assert.rejects(agent.run({message:'Fix',model:'different',checkpoint}),/different folder, model/);
 await assert.rejects(agent.run({message:'Fix',model:'local',checkpoint,onCheckpoint:async state=>{saved=state;}}),/action limit/);
 assert.equal(saved.pending,null);assert.match(saved.events[0].result.error,/completion is unknown/);assert.equal(saved.events[1].action,'read');
});
