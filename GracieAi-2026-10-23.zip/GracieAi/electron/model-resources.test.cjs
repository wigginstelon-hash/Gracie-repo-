const test=require('node:test');const assert=require('node:assert/strict');
const {assessModelMemory,createResourceCheck}=require('./model-resources.cjs');
const GiB=1024**3;
test('oversized local models are refused while GPU-fitting models retain Windows memory headroom',()=>{
  const pc={gpuBytes:8*GiB,totalBytes:16*GiB,freeBytes:9*GiB};
  assert.equal(assessModelMemory({...pc,size:17.7e9}).allowed,false);
  assert.equal(assessModelMemory({...pc,size:18.6e9}).allowed,false);
  assert.equal(assessModelMemory({...pc,size:6.6e9}).allowed,true);
  assert.equal(assessModelMemory({...pc,size:4.7e9}).allowed,true);
  assert.equal(assessModelMemory({...pc,gpuBytes:24*GiB,size:18.6e9}).allowed,true);
});
test('evictable CPU weights count once and unknown GPU hardware is not guessed',()=>{
  const pc={gpuBytes:8*GiB,totalBytes:16*GiB,freeBytes:GiB,size:11*GiB};
  assert.equal(assessModelMemory(pc).allowed,false);
  assert.equal(assessModelMemory({...pc,loaded:[{size:12*GiB,size_vram:5*GiB}]}).allowed,true);
  assert.equal(assessModelMemory({...pc,gpuBytes:0}).allowed,true);
});
test('hardware queries are bounded and cached while available RAM is read again for every large request',async()=>{
  let queries=0,free=9*GiB;
  const check=createResourceCheck({memory:{totalmem:()=>16*GiB,freemem:()=>free},gpuQuery:async()=>{queries++;return '8192\r\n';}});
  await check({model:{size:6.6e9}});
  await assert.rejects(check({model:{size:17.7e9}}),/stopped before loading/);
  free=14*GiB;await check({model:{size:11*GiB}});assert.equal(queries,1);
});
