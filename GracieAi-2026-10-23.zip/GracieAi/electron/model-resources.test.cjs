const {test}=require('node:test');
const assert=require('node:assert/strict');
const {assessModelMemory,createResourceCheck}=require('./model-resources.cjs');
const GiB=1024**3;

test('oversized local models are estimated not to fit while GPU-fitting models retain Windows headroom',()=>{
  const pc={gpuBytes:8*GiB,totalBytes:16*GiB,freeBytes:9*GiB};
  assert.equal(assessModelMemory({...pc,size:17.7e9}).allowed,false);
  assert.equal(assessModelMemory({...pc,size:18.6e9}).allowed,false);
  assert.equal(assessModelMemory({...pc,size:6.6e9}).allowed,true);
  assert.equal(assessModelMemory({...pc,size:4.7e9}).allowed,true);
  assert.equal(assessModelMemory({...pc,gpuBytes:24*GiB,size:18.6e9}).allowed,true);
});

test('resident weights are reused only for the selected model; unknown GPU and size stay conservative',()=>{
  const pc={gpuBytes:2*GiB,totalBytes:16*GiB,freeBytes:5*GiB,size:11*GiB,modelName:'selected'};
  const loaded=[{name:'selected',size:11*GiB,size_vram:7*GiB}];
  assert.equal(assessModelMemory(pc).allowed,false);
  assert.equal(assessModelMemory({...pc,loaded}).allowed,true);
  assert.equal(assessModelMemory({...pc,loaded:[{...loaded[0],name:'other'}]}).allowed,false);
  assert.equal(assessModelMemory({...pc,gpuBytes:0}).allowed,false);
  assert.equal(assessModelMemory({...pc,size:0}).allowed,false);
});

test('resource estimates warn without refusing a load and refresh both free GPU and RAM measurements',async()=>{
  let queries=0,free=9*GiB,gpu='8192\r\n';
  const check=createResourceCheck({memory:{totalmem:()=>16*GiB,freemem:()=>free},gpuQuery:async()=>{queries++;return gpu;}});
  assert.equal((await check({model:{size:6.6e9}})).warning,undefined);
  const large=await check({model:{size:17.7e9}});
  assert.equal(large.allowed,true);assert.equal(large.estimatedFit,false);assert.match(large.warning,/may exceed/);
  free=14*GiB;assert.equal((await check({model:{size:11*GiB}})).estimatedFit,true);
  gpu='0';assert.equal((await check({model:{size:11*GiB}})).estimatedFit,false);
  assert.equal(queries,4);
});

test('failed GPU discovery falls back to RAM and unknown model sizes produce a warning',async()=>{
  const check=createResourceCheck({memory:{totalmem:()=>16*GiB,freemem:()=>9*GiB},gpuQuery:async()=>{throw Error('No GPU');}});
  const result=await check({model:{size:11*GiB}});
  assert.equal(result.gpuBytes,0);assert.equal(result.estimatedFit,false);assert.equal(result.allowed,true);
  assert.match((await check({model:{size:0}})).warning,/size is unknown/);
});
