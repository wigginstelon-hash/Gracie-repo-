const validTag = value => typeof value === 'string' && value.length <= 200 && /^[a-zA-Z0-9][a-zA-Z0-9._/-]*(?::[a-zA-Z0-9][a-zA-Z0-9._-]*)?$/.test(value) && !value.includes('..');
const cloudTag = name => name.includes(':') ? `${name}-cloud` : `${name}:cloud`;
const isCloudTag = name => /(?::cloud|-cloud)$/.test(name);

function createModelLibrary({ fetchImpl = globalThis.fetch, baseUrl = () => 'http://127.0.0.1:11434', localOnly = false } = {}) {
  let catalog;
  let cachedAt = 0;
  let job = null;
  let controller;
  async function cloudModels() {
    if (localOnly) throw Error('Cloud model discovery is disabled in Local assistant mode.');
    if (catalog && Date.now() - cachedAt < 300000) return catalog;
    const response = await fetchImpl('https://ollama.com/api/tags', { signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new Error('Could not load Ollama’s cloud catalog. Try again or open the official library.');
    const data = await response.json();
    if (!Array.isArray(data.models)) throw new Error('Ollama returned an unreadable cloud catalog.');
    catalog = data.models.filter(m => validTag(m?.name)).map(m => ({ name: m.name, tag: cloudTag(m.name) })).sort((a, b) => a.name.localeCompare(b.name));
    cachedAt = Date.now();
    return catalog;
  }
  function pullStatus() { return job ? { ...job } : null; }
  function startPull(name) {
    if (localOnly) throw Error('Downloads need an internet connection. Close Local assistant mode and install models with the setup script or Ollama first.');
    if (!validTag(name) || isCloudTag(name)) throw new Error('Enter an exact local model tag from Ollama’s library. Cloud models do not need a download.');
    if (job?.active) throw new Error('A model download is already running.');
    controller = new AbortController();
    const activeController = controller;
    job = { name, active: true, status: 'Connecting to Ollama…', completed: 0, total: 0, digest: '', error: '', done: false };
    const timeout = setTimeout(() => activeController.abort(), 3600000);
    const consume = line => {
      if (!line.trim()) return;
      const update = JSON.parse(line);
      if (update.error) throw new Error(update.error);
      job.status = String(update.status || 'Downloading…');
      if (update.digest && update.digest !== job.digest) {
        job.digest = String(update.digest); job.total = 0; job.completed = 0;
      }
      if (update.total !== undefined) { job.total = Number(update.total) || 0; job.completed = Number(update.completed) || 0; }
      if (update.completed !== undefined) job.completed = Number(update.completed) || 0;
      if (update.status === 'success') job.done = true;
    };
    (async () => {
      try {
        const response = await fetchImpl(new URL('/api/pull', baseUrl()), {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model: name, stream: true }), signal: activeController.signal,
        });
        if (!response.ok) throw new Error(`Ollama could not download this model (${response.status}). Check its exact tag in the library.`);
        if (!response.body) throw new Error('Ollama returned no download progress.');
        const decoder = new TextDecoder();
        let pending = '';
        for await (const bytes of response.body) {
          pending += decoder.decode(bytes, { stream: true });
          const lines = pending.split('\n'); pending = lines.pop();
          lines.forEach(consume);
        }
        pending += decoder.decode(); consume(pending);
        if (!job.done) throw new Error('The download ended before Ollama confirmed success. Try again to resume.');
      } catch (error) {
        job.error = activeController.signal.aborted ? 'Download stopped. Ollama can reuse partial files when you retry.' : String(error.message || error);
      } finally { clearTimeout(timeout); job.active = false; }
    })();
    return pullStatus();
  }
  function cancelPull() { controller?.abort(); return pullStatus(); }
  return { cloudModels, startPull, pullStatus, cancelPull };
}
module.exports = { createModelLibrary, validTag, cloudTag, isCloudTag };
