const fs=require('node:fs');
const path=require('node:path');
const {fileURLToPath}=require('node:url');
async function checkPage(checks, timeoutMs) {
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const errors = () => { if (window.__gracieErrors?.length) throw Error(window.__gracieErrors.slice(0, 3).join('; ')); };
  async function until(read, description) {
    const deadline = performance.now() + timeoutMs;
    do { errors(); const result = read(); if (result) return result; await sleep(25); } while (performance.now() < deadline);
    errors(); const failure=description();throw failure instanceof Error?failure:Error(failure);
  }
  function interactionFailure(index,check,message){
    const target=document.querySelector(check.selector),output=document.querySelector(check.expectSelector);
    const describe=element=>element?{tag:element.tagName.toLowerCase(),id:element.id,type:element.type||'',disabled:Boolean(element.disabled),visible:element.getClientRects().length>0,display:getComputedStyle(element).display,value:'value' in element?String(element.value).slice(0,300):undefined,valid:element.validity?.valid,validationMessage:element.validationMessage||'',min:element.min,max:element.max,text:element.textContent.trim().slice(0,300)}:null;
    const error=Error(message);
    error.checkFailure={index:index+1,check,completed:checks.slice(0,index),target:describe(target),output:describe(output),buttons:[...document.querySelectorAll('button,input[type="submit"],input[type="button"]')].filter(element=>element.getClientRects().length&&!element.matches(':disabled,[aria-disabled="true"]')).slice(0,12).map(describe),hint:check.event==='input'&&check.expectSelector!==check.selector?'Entering a value dispatches input/change only. If the app calculates on a button or form submit, first assert the entered input value, then explicitly click that control and assert the result. Do not remove the result assertion.':undefined};
    error.checkFailure.formControls=[...(target?.form?.elements||[])].slice(0,16).map(describe);
    if(error.checkFailure.formControls.some(control=>control.valid===false&&checks.slice(0,index).some(step=>step.event==='input'&&step.selector==='#'+control.id&&step.value===control.value)))error.checkFailure.hint='Native form validation can prevent the submit handler from running. Keep rejecting invalid values and show the requested inline error by handling the invalid event in capture phase, or use noValidate with complete explicit validation. Do not change the failing values or remove their assertions.';
    error.checkFailure.matchingOutputs=[...document.querySelectorAll('[id]')].filter(element=>element.getClientRects().length&&!element.matches('input,textarea,select,button,nav')&&/output|list|result|total|count|summary/i.test(element.id+' '+element.tagName)&&element.textContent.includes(check.includes)).slice(0,6).map(describe);
    return error;
  }
  await until(() => document.body && (document.body.innerText.trim() || document.body.querySelector('canvas,svg,input,button')), () => 'The app has no visible content.');
  for (let index = 0; index < checks.length; index++) {
    const check = checks[index];
    const target = await until(() => {
      const el = document.querySelector(check.selector);
      return el && (check.event === 'none' || !el.matches(':disabled,[aria-disabled="true"]') && el.getClientRects().length > 0) && el;
    }, () => interactionFailure(index,check,`Check ${index + 1}: missing or disabled control: ${check.selector}`));
    if (check.event === 'click') target.click();
    if (check.event === 'input') {
      if (!('value' in target) || target.readOnly || target.type === 'file') throw Error(`Check ${index + 1}: ${check.selector} is not an editable text/select control.`);
      const proto = target instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : target instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, 'value').set.call(target, check.value || '');
      target.dispatchEvent(new Event('input', {bubbles:true}));
      target.dispatchEvent(new Event('change', {bubbles:true}));
    }
    await until(() => {
      const output = document.querySelector(check.expectSelector);
      return output && String(output[check.property]).includes(check.includes);
    }, () => {
      const output = document.querySelector(check.expectSelector);
      const actual = output ? JSON.stringify(String(output[check.property]).slice(0, 200)) : '(output element missing)';
      return interactionFailure(index,check,`Interaction check failed for ${check.expectSelector}: expected ${check.includes}; got ${actual}. Check ${index + 1}, after ${check.event} on ${check.selector}; waited ${timeoutMs}ms. Checks run in order on the same page; repair the app or incorrect test sequence, never remove a failing check.`);
    });
  }
  await sleep(100); errors();
  return {checks:['JavaScript syntax','App opened without startup errors',checks.length+' interaction check(s)'],functional:checks.length};
}
function createAppPreview({BrowserWindow,session,ipcMain,dialog}){
  const windows=new Set();
  function create(source,projectId,show,capabilities=[]){
    const channelId=require('node:crypto').randomUUID();
    const root=fs.realpathSync(source);const isolated=session.fromPartition(show?'persist:gracie-built-'+projectId:'gracie-test-'+require('node:crypto').randomUUID());
    isolated.setPermissionRequestHandler((_web,_permission,callback)=>callback(false));isolated.setPermissionCheckHandler(()=>false);
    isolated.webRequest.onBeforeRequest((details,callback)=>{try{if(details.url.startsWith('data:'))return callback({cancel:false});if(!details.url.startsWith('file:'))return callback({cancel:true});const file=fs.realpathSync(fileURLToPath(details.url.split('#')[0]));const relative=path.relative(root,file);callback({cancel:relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative)});}catch{callback({cancel:true});}});
    const win=new BrowserWindow({width:1100,height:800,show,title:'Gracie app',webPreferences:{...(capabilities.length?{preload:path.join(root,'native-preload.cjs'),additionalArguments:['--gracie-native-id='+channelId]}:{}),session:isolated,contextIsolation:true,nodeIntegration:false,sandbox:true,backgroundThrottling:false}});
    if(capabilities.length)require('./native-host.cjs').installNativeHost({ipcMain,dialog,window:win,root,capabilities,channelId,simulation:!show});
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));win.webContents.on('will-navigate',event=>event.preventDefault());
    windows.add(win);win.once('closed',()=>windows.delete(win));return win;
  }
  async function smoke({source,draft,projectId,signal,checkTimeout=5000}){
    signal?.throwIfAborted();const win=create(source,projectId,false,draft.nativeCapabilities);let timer;let abort;
    const timeoutMs = Math.max(100, Math.min(10000, Number(checkTimeout) || 5000));
    try{return await Promise.race([
      (async()=>{await win.loadFile(path.join(source,'index.html'));signal?.throwIfAborted();
        const outcome=await win.webContents.executeJavaScript(`(async()=>{try{return {ok:true,result:await (${checkPage.toString()})(${JSON.stringify(draft.checks)},${timeoutMs})};}catch(error){return {ok:false,message:String(error.message||error),checkFailure:error.checkFailure};}})()`);signal?.throwIfAborted();if(!outcome.ok){const error=Error(outcome.message);if(outcome.checkFailure)error.checkFailure=outcome.checkFailure;throw error;}if(draft.nativeCapabilities?.length){outcome.result.checks.push('Native interface tested with simulated responses; live Windows coverage is checked when you run a scan.');outcome.result.nativeSimulation=true;}return outcome.result;})(),
      new Promise((_resolve,reject)=>{timer=setTimeout(()=>reject(Error('App startup check timed out.')),15000+timeoutMs*(1+draft.checks.length*2));abort=()=>reject(Error('Build stopped.'));signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();})
    ]);}finally{clearTimeout(timer);signal?.removeEventListener('abort',abort);if(!win.isDestroyed())win.destroy();}
  }
  async function open({path:source,project}){const win=create(source,project.id,true,project.nativeCapabilities);await win.loadFile(path.join(source,'index.html'));win.setTitle(project.title);return {ok:true};}
  return {smoke,open};
}
module.exports={createAppPreview};
