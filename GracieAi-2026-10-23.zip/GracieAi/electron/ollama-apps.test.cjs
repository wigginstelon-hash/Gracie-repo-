const test=require('node:test');
const assert=require('node:assert/strict');
const {EventEmitter}=require('node:events');
const {createOllamaApps,launchScript}=require('./ollama-apps.cjs');
function fixture(overrides={}) {
  const calls=[];
  const apps=createOllamaApps({platform:'win32',env:{LOCALAPPDATA:'C:\\Users\\Test',SystemRoot:'C:\\Windows'},access:async()=>{},status:async()=>({available:true,url:'http://127.0.0.1:11435',models:['qwen:latest']}),run:async()=>({stdout:'Supported integrations:\n  codex           Codex\n  claude          Claude Code\n'}),start:(exe,args,options)=>{calls.push({exe,args,options});const child=new EventEmitter();child.unref=()=>{};queueMicrotask(()=>child.emit('spawn'));return child;},...overrides});
  return {apps,calls};
}
test('catalog distinguishes CLI support from app installation and includes Terminal',async()=>{
  const {apps}=fixture();const rows=await apps.list();
  assert.equal(rows.length,14);
  assert.equal(rows.find(app=>app.id==='codex').supported,true);
  assert.equal(rows.find(app=>app.id==='hermes').supported,false);
  assert.equal(rows.find(app=>app.id==='terminal').supported,true);
});
test('launch passes selected model and folder to visible persistent terminal without automatic setup approval',async()=>{
  const {apps,calls}=fixture();const result=await apps.launch({id:'codex',model:'qwen:latest',folder:'C:\\My Project'});
  assert.equal(result.opened,true);assert.equal(calls.length,1);
  const call=calls[0],script=Buffer.from(call.args.at(-1),'base64').toString('utf16le');
  assert.match(script,/'launch' 'codex' '--model' 'qwen:latest'/);
  assert.doesNotMatch(script,/--yes/);
  assert.equal(call.options.env.OLLAMA_HOST,'http://127.0.0.1:11435');assert.equal(call.options.cwd,'C:\\My Project');assert.equal(call.options.windowsHide,false);
  assert.ok(call.args.includes('-NoExit'));
});
test('unknown integrations, unsupported apps and unavailable models never open a terminal',async()=>{
  const {apps,calls}=fixture();
  for(const input of [{id:'evil'},{id:'hermes',model:'qwen:latest'},{id:'codex',model:'missing'}])await assert.rejects(apps.launch(input));
  assert.equal(calls.length,0);
});
test('terminal runs Ollama and validates shell input; executable apostrophes are literal',()=>{
  assert.match(launchScript("C:\\O'Brien\\ollama.exe",'terminal','qwen:latest'),/O''Brien/);
  assert.match(launchScript('ollama.exe','terminal','qwen:latest'),/'run' 'qwen:latest'/);
  for(const model of ['--help',"a'; exit",'$(whoami)','a\nb'])assert.throws(()=>launchScript('ollama.exe','codex',model));
});
test('offline server and terminal spawn failure propagate errors',async()=>{
  const offline=fixture({status:async()=>({available:false,message:'Server offline'})});
  await assert.rejects(offline.apps.launch({id:'codex',model:'qwen:latest'}),/Server offline/);
  assert.equal(offline.calls.length,0);
  const failed=fixture({start:()=>{const child=new EventEmitter();queueMicrotask(()=>child.emit('error',Error('Cannot open terminal')));return child;}});
  await assert.rejects(failed.apps.launch({id:'codex',model:'qwen:latest'}),/Cannot open terminal/);
});
