const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {createAttachments}=require('./attachments.cjs');
const {createWorkStore}=require('./work-store.cjs');
const {createResearch,checkedUrl,publicAddress}=require('./research.cjs');
const {createOllamaClient}=require('./ollama.cjs');
const reply=data=>new Response(JSON.stringify(data));
async function temporary(t){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-workspace-'));t.after(()=>fs.rm(dir,{recursive:true,force:true}));return dir;}

test('attachments persist as immutable local snapshots and only registered IDs can be retrieved',async t=>{
  const dir=await temporary(t),file=path.join(dir,'project.txt');await fs.writeFile(file,'Project color is blue.');
  const store=createAttachments(path.join(dir,'files'));const info=await store.add(file);
  await fs.writeFile(file,'Changed source');
  const [saved]=await createAttachments(path.join(dir,'files')).get([info.id]);
  assert.equal(saved.text,'Project color is blue.');assert.equal(info.kind,'document');
  await assert.rejects(store.get(['../../secret']),/Invalid/);
  await assert.rejects(store.get(Array(7).fill(info.id)),/six/);
  assert.match(store.excerpts([saved],'color')[0].excerpt,/blue/);
});
test('attachment validation rejects binary, unsupported, oversized, and unreadable documents',async t=>{
  const dir=await temporary(t),store=createAttachments(path.join(dir,'files'),{extractPdf:async()=>''});
  for(const [name,text,pattern] of [['app.exe','data',/picture/],['binary.txt','a\0b',/binary/],['empty.pdf','test',/no readable/]]){
    const file=path.join(dir,name);await fs.writeFile(file,text);await assert.rejects(store.add(file),pattern);
  }
  const file=path.join(dir,'large.txt');await fs.writeFile(file,'x'.repeat(1048577));await assert.rejects(store.add(file),/1 MB/);
});
test('image attachment data stays in the main-process store and document extraction is bounded',async t=>{
  const dir=await temporary(t);const store=createAttachments(path.join(dir,'files'),{imageToJpeg:async()=>({image:'BASE64',thumbnail:'data:image/jpeg;base64,THUMB'}),extractDocx:async()=> 'a'.repeat(70000)});
  const image=path.join(dir,'picture.png');await fs.writeFile(image,'test');const meta=await store.add(image);
  assert.equal(meta.image,undefined);assert.equal((await store.get([meta.id]))[0].image,'BASE64');
  const doc=path.join(dir,'notes.docx');await fs.writeFile(doc,'test');const document=await store.add(doc);assert.equal(document.truncated,true);assert.equal((await store.get([document.id]))[0].text.length,60000);
});
test('PDF and Word parsers extract actual text fixtures without executing document content',async t=>{
  const dir=await temporary(t);const {PDFParse}=require('pdf-parse');const mammoth=require('mammoth');
  const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 300 300] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
  const stream='BT /F1 12 Tf 20 200 Td (Gracie PDF fixture) Tj ET';objects.push(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);
  let pdf='%PDF-1.4\n',offsets=[0];for(let i=0;i<objects.length;i++){offsets.push(Buffer.byteLength(pdf));pdf+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`;}
  const xref=Buffer.byteLength(pdf);pdf+=`xref\n0 6\n0000000000 65535 f \n${offsets.slice(1).map(n=>String(n).padStart(10,'0')+' 00000 n ').join('\n')}\ntrailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  const pdfFile=path.join(dir,'sample.pdf');await fs.writeFile(pdfFile,pdf);
  const zip=new(require('jszip'))();zip.file('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');zip.file('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');zip.file('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>Gracie Word fixture</w:t></w:r></w:p></w:body></w:document>');
  const docFile=path.join(dir,'sample.docx');await fs.writeFile(docFile,await zip.generateAsync({type:'nodebuffer'}));
  const store=createAttachments(path.join(dir,'files'),{extractPdf:async buffer=>{const p=new PDFParse({data:new Uint8Array(buffer),isEvalSupported:false});try{return(await p.getText()).text;}finally{await p.destroy();}},extractDocx:async buffer=>(await mammoth.extractRawText({buffer})).value});
  const a=await store.add(pdfFile),b=await store.add(docFile);const files=await store.get([a.id,b.id]);assert.match(files[0].text,/Gracie PDF fixture/);assert.match(files[1].text,/Gracie Word fixture/);
});
test('paused checkpoints survive restart, atomically replace progress, and clear on completion',async t=>{
  const dir=await temporary(t),store=createWorkStore(dir);assert.equal(await store.load(),null);
  await store.save({request:{model:'local',attachmentIds:['fixture']},partial:'First sentence',checkpoint:{messages:[{role:'tool',content:'completed'}]}});
  const restarted=createWorkStore(dir),saved=await restarted.load();assert.equal(saved.partial,'First sentence');assert.equal(saved.checkpoint.messages[0].role,'tool');assert.ok(saved.savedAt);
  await restarted.save({...saved,partial:'More progress'});assert.equal((await store.load()).partial,'More progress');await store.clear();assert.equal(await restarted.load(),null);
});
test('public-reference reader blocks local addresses, non-web protocols, credentials and unsafe redirects',async()=>{
  for(const ip of ['127.0.0.1','10.0.0.1','192.168.1.1','169.254.1.1','172.16.0.1','::1','::ffff:127.0.0.1','fc00::1'])assert.equal(publicAddress(ip),false);
  assert.equal(publicAddress('8.8.8.8'),true);
  for(const url of ['file:///secret','http://localhost/','http://127.0.0.1/','https://name:pass@example.com/','https://example.com:444/'])await assert.rejects(checkedUrl(url));
  await assert.rejects(checkedUrl('https://example.com',async()=>[{address:'10.0.0.1',family:4}]));
  assert.equal((await checkedUrl('https://example.com',async()=>[{address:'8.8.8.8',family:4}])).address.address,'8.8.8.8');
});
test('research performs bounded multi-query discovery, reads sources, and deduplicates citations',async()=>{
  const queries=[],pages=[];
  const research=createResearch({env:{EXA_API_KEY:'test'},fetchImpl:async(_url,options)=>{queries.push(JSON.parse(options.body).query);return reply({results:[{title:'Project architecture Docs',url:'https://example.com/docs',text:'project architecture snippet'},{title:'Project architecture Guide',url:'https://example.com/guide',text:'project architecture guide'}]});},readPage:async url=>{pages.push(url);return{url,title:'Page',text:'reference body'};}});
  const result=await research.collect({query:'project architecture',mode:'deep',links:['https://example.com/direct']});
  assert.equal(queries.length,3);assert.ok(pages.length<=4);assert.equal(result.sources.length,3);assert.deepEqual(result.sources.map(s=>s.id),[1,2,3]);
  assert.ok(queries.every(q=>!q.includes('ATTACHED')));
});
test('research reports failures honestly, allows direct links without search credentials, and honors pause cancellation',async()=>{
  const direct=createResearch({env:{},readPage:async url=>({url,title:'Docs',text:'valid text'}),fallbackSearch:async()=>{throw new Error('Search is not configured for this offline test.');}});
  assert.equal((await direct.collect({links:['https://example.com'],mode:'off'})).sources.length,1);
  await assert.rejects(direct.collect({query:'x',mode:'search'}),/not configured/);
  const partial=await direct.collect({query:'x',mode:'search',links:['https://example.com']});assert.equal(partial.warnings.length,1);
  const controller=new AbortController();controller.abort();await assert.rejects(direct.collect({mode:'deep',query:'x',signal:controller.signal}));
  const failing=createResearch({env:{EXA_API_KEY:'test'},fetchImpl:async()=>new Response('',{status:503}),fallbackSearch:async()=>{throw Error('Public search unavailable');}});await assert.rejects(failing.collect({mode:'search',query:'x'}),/503/);
});
test('reference excerpts retain relevant evidence beyond a long page introduction',async()=>{
  const research=createResearch({env:{},readPage:async url=>({url,title:'Documentation',text:'General introduction. '.repeat(160)+'\nImage encoding requires base64 for REST API requests. '+ 'Additional notes. '.repeat(50)})});
  const result=await research.collect({query:'image encoding base64 REST requests',links:['https://example.com/docs']});
  assert.match(result.sources[0].excerpt,/encoding requires base64/);assert.ok(result.sources[0].excerpt.length<=1200);
});
test('public search fallback preserves source URLs when a configured key is rejected',async()=>{
  const {parseSearchRss}=require('./research.cjs');const parsed=parseSearchRss('<rss><channel><item><title>Official &amp; docs</title><link>https://example.com?q=one&amp;x=two</link><description>Reference text</description></item></channel></rss>');
  assert.equal(parsed[0].title,'Official & docs');assert.equal(parsed[0].url,'https://example.com?q=one&x=two');
  const research=createResearch({env:{EXA_API_KEY:'test'},fetchImpl:async()=>new Response('',{status:401}),fallbackSearch:async()=>parsed});
  assert.equal((await research.collect({query:'docs',mode:'search'})).sources[0].url,new URL(parsed[0].url).href);
});
test('Ollama attachments use image arrays only with vision-capable local models and quote references as data',async()=>{
  let body;const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'vision'},{name:'text'},{name:'test:cloud'}]});
    if(url.pathname==='/api/show')return reply({capabilities:JSON.parse(options.body).model==='vision'?['vision']:['completion']});
    body=JSON.parse(options.body);return reply({message:{content:'Red square [1]'}});
  }});
  await client.chat({model:'vision',message:'Describe',images:['IMAGE'],attachmentText:'Quoted document',researchText:'[1] Official reference'});
  assert.deepEqual(body.messages.at(-1).images,['IMAGE']);assert.match(body.messages[0].content,/untrusted data/);assert.match(body.messages.at(-1).content,/Quoted document/);
  await assert.rejects(client.chat({model:'text',message:'Describe',images:['IMAGE']}),/cannot read pictures/);
  await assert.rejects(client.chat({model:'test:cloud',message:'Read',attachmentText:'LOCAL PRIVATE FILE'}),/stay local/);
});
test('resume uses a saved tool checkpoint without repeating completed actions and appends new text',async()=>{
  let calls=0,checkpoint,partial='';const controller=new AbortController();
  const localTools={specs:require('./local-tools.cjs').specs,execute:async()=>{calls++;return{ok:true,message:'already done'};}};
  let round=0;
  const client=createOllamaClient({env:{},localTools,fetchImpl:async(url,{signal}={})=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'local'}]});
    if(++round===1)return new Response('{"message":{"tool_calls":[{"function":{"name":"project_list_files","arguments":{}}}]},"done":true}\n');
    return new Response(new ReadableStream({start(c){c.enqueue(new TextEncoder().encode('{"message":{"content":"First sentence."},"done":false}\n'));signal.addEventListener('abort',()=>c.error(new Error('aborted')));}}));
  }});
  await assert.rejects(client.chat({model:'local',message:'Inspect',history:[{role:'user',content:'Unrelated older project'},{role:'assistant',content:'Old response'}],fastMode:true,attachmentText:'project facts',useLocalTools:true,signal:controller.signal,onCheckpoint:c=>{checkpoint=c;},onChunk:text=>{partial+=text;controller.abort();}}),/Reply stopped/);
  assert.equal(calls,1);assert.equal(checkpoint.messages.at(-1).role,'tool');
  const resumed=createOllamaClient({env:{},localTools,fetchImpl:async(url,options)=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'local'}]});const body=JSON.parse(options.body);assert.ok(body.messages.some(m=>m.role==='tool'));assert.match(body.messages.at(-1).content,/Do not repeat/);assert.match(body.messages.at(-1).content,/interrupted request:\nInspect/);assert.ok(!body.messages.some(m=>m.content==='Unrelated older project'));assert.equal(body.options.num_predict,384);assert.equal(body.options.num_ctx,checkpoint.contextSize);return reply({message:{content:'Next sentence.'}});
  }});
  const result=await resumed.chat({model:'local',message:'Inspect',fastMode:true,useLocalTools:true,resumeState:{...checkpoint,partial}});
  assert.equal(result.content,'First sentence.\nNext sentence.');assert.equal(calls,1);assert.equal(result.toolActivity.length,1);
});
