/**
 * Gracie agent tools: terminal, workspace, multi-tab browser, optional Playwright,
 * and project scan/learn/recall (learn from any folder of files/documents).
 */
const { BrowserWindow } = require("electron");
const { exec, execFile } = require("node:child_process");
const { promisify } = require("node:util");
const path = require("node:path");
const fs = require("node:fs/promises");
const fsSync = require("node:fs");
const crypto = require("node:crypto");

const execAsync = promisify(exec);
const execFileAsync = promisify(execFile);

const browserTabs = new Map();
let activeTabId = null;
let playwrightBrowser = null;
let playwrightPage = null;
let playwrightAvailable = null;

const IGNORE_DIR_NAMES = new Set([
  "node_modules", ".git", ".svn", ".hg", "dist", "build", "out", "release",
  ".next", ".nuxt", ".cache", "coverage", "__pycache__", ".venv", "venv", "env",
  ".tox", "target", ".idea", ".vscode", "vendor", "Pods", "DerivedData",
]);

const TEXT_EXTENSIONS = new Set([
  ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".rb", ".go", ".rs",
  ".java", ".kt", ".swift", ".cs", ".cpp", ".c", ".h", ".hpp", ".md", ".mdx",
  ".txt", ".json", ".jsonc", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf",
  ".css", ".scss", ".html", ".htm", ".vue", ".svelte", ".sql", ".sh", ".bash",
  ".zsh", ".ps1", ".bat", ".cmd", ".xml", ".svg", ".graphql", ".proto",
  ".pdf", ".docx", ".rtf", ".csv", ".log",
]);

const PRIORITY_FILES = [
  "README.md", "readme.md", "package.json", "pyproject.toml", "requirements.txt",
  "Cargo.toml", "go.mod", "Makefile", "Dockerfile", "docker-compose.yml",
  "main.py", "app.py", "index.js", "index.ts", "main.ts", "main.cjs",
  "electron/main.cjs", "src/main.ts", "src/App.tsx", "agent.py", "bot.py",
  "AGENTS.md", "CLAUDE.md", "SYSTEM.md", "prompt.md", "instructions.md",
];

function createAgentTools({ dataDir, requireComputerMode, requiresConfirmation }) {
  const workspaceRoot = path.join(dataDir, "workspace");
  const venvDir = path.join(workspaceRoot, ".venv");
  const knowledgeDir = path.join(dataDir, "knowledge");

  async function ensureWorkspace() {
    await fs.mkdir(workspaceRoot, { recursive: true });
    await fs.mkdir(path.join(workspaceRoot, "scripts"), { recursive: true });
    await fs.mkdir(path.join(workspaceRoot, "output"), { recursive: true });
    return workspaceRoot;
  }

  async function ensureKnowledgeDir() {
    await fs.mkdir(knowledgeDir, { recursive: true });
    return knowledgeDir;
  }

  function platformShell() {
    if (process.platform === "win32") return process.env.ComSpec || "cmd.exe";
    return process.env.SHELL || (process.platform === "darwin" ? "/bin/zsh" : "/bin/bash");
  }

  function venvPython() {
    return process.platform === "win32"
      ? path.join(venvDir, "Scripts", "python.exe")
      : path.join(venvDir, "bin", "python");
  }

  function venvPip() {
    return process.platform === "win32"
      ? path.join(venvDir, "Scripts", "pip.exe")
      : path.join(venvDir, "bin", "pip");
  }

  function venvExists() {
    return fsSync.existsSync(venvPython());
  }

  function slugify(name) {
    return (
      String(name || "project")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 64) || "project"
    );
  }

  function normalizeUrl(raw) {
    const value = String(raw || "").trim();
    if (!value) return "";
    if (/^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(value)) return value;
    return `https://${value}`;
  }

  // ── Terminal ────────────────────────────────────────────────────────────

  async function runTerminalCommand(args, { forceCwd, signal } = {}) {
    const command = String(args.command || "").trim();
    if (!command) return { ok: false, error: "command is required." };
    const cwd =
      typeof forceCwd === "string"
        ? forceCwd
        : typeof args.cwd === "string" && args.cwd.trim()
          ? path.resolve(args.cwd.trim())
          : process.cwd();
    const timeoutMs = Math.max(5000, Math.min(600000, Number(args.timeoutMs) || 120000));
    const maxOutputChars = 24000;
    const env = { ...process.env, FORCE_COLOR: "0", TERM: "dumb" };
    if (venvExists()) {
      const bin =
        process.platform === "win32" ? path.join(venvDir, "Scripts") : path.join(venvDir, "bin");
      env.PATH = `${bin}${path.delimiter}${env.PATH || ""}`;
      env.VIRTUAL_ENV = venvDir;
    }
    try {
      const { stdout, stderr } = await execAsync(command, {
        cwd,
        timeout: timeoutMs,
        maxBuffer: 8 * 1024 * 1024,
        shell: platformShell(),
        env,
        signal,
        windowsHide: true,
      });
      return formatTerm(true, 0, command, cwd, String(stdout || ""), String(stderr || ""), maxOutputChars);
    } catch (error) {
      const err = error && typeof error === "object" ? error : {};
      const timedOut = err.killed === true || /ETIMEDOUT|timeout/i.test(String(error?.message || ""));
      return formatTerm(
        false,
        typeof err.code === "number" ? err.code : 1,
        command,
        cwd,
        String(err.stdout || ""),
        String(err.stderr || error?.message || String(error)),
        maxOutputChars,
        timedOut ? `Command timed out after ${timeoutMs}ms` : undefined,
        timedOut
      );
    }
  }

  function formatTerm(ok, exitCode, command, cwd, stdout, stderr, maxOutputChars, error, timedOut) {
    const trunc = (s) => (s.length > maxOutputChars ? s.slice(0, maxOutputChars) + "\n\n… [truncated]" : s);
    const out = trunc(stdout || "");
    const err = trunc(stderr || "");
    const body = [
      `$ ${command}`,
      `cwd: ${cwd}`,
      timedOut ? "status: timed out" : `exit code: ${exitCode}`,
      "",
      out || "(no stdout)",
      err ? `\n--- stderr ---\n${err}` : "",
    ]
      .filter(Boolean)
      .join("\n");
    return {
      ok,
      exitCode,
      timedOut: Boolean(timedOut),
      cwd,
      command,
      stdout: out,
      stderr: err,
      ...(error ? { error } : {}),
      artifact: { title: "Terminal", kind: "code", language: "bash", content: body },
    };
  }

  // ── Workspace ───────────────────────────────────────────────────────────

  async function workspaceStatus() {
    await ensureWorkspace();
    const hasVenv = venvExists();
    let pythonVersion = null;
    if (hasVenv) {
      try {
        const { stdout } = await execFileAsync(venvPython(), ["--version"]);
        pythonVersion = stdout.trim();
      } catch {
        pythonVersion = "(error)";
      }
    }
    const content = [
      "# Workspace",
      `**Root:** \`${workspaceRoot}\``,
      `**Python venv:** ${hasVenv ? `yes (${pythonVersion})` : "not created"}`,
      "",
      "Folders: `scripts/`, `output/` — knowledge packs in `data/knowledge/`",
    ].join("\n");
    return {
      ok: true,
      workspaceRoot,
      hasVenv,
      pythonVersion,
      artifact: { title: "Workspace", kind: "markdown", content },
    };
  }

  async function workspaceSetup(args) {
    await ensureWorkspace();
    const kind = String(args.kind || "python").toLowerCase();
    const steps = [];
    if (kind === "python" || kind === "both") {
      if (venvExists()) steps.push("Python venv already exists.");
      else {
        const pythonBin = process.platform === "win32" ? "python" : "python3";
        try {
          await execFileAsync(pythonBin, ["-m", "venv", venvDir], { cwd: workspaceRoot, timeout: 120000 });
          steps.push(`Created venv at ${venvDir}`);
        } catch (e) {
          return { ok: false, error: `venv failed: ${e instanceof Error ? e.message : String(e)}` };
        }
      }
      if (Array.isArray(args.packages) && args.packages.length) {
        const pkgs = args.packages.map(String).filter(Boolean);
        try {
          await execFileAsync(venvPip(), ["install", ...pkgs], {
            cwd: workspaceRoot,
            timeout: 300000,
            env: { ...process.env, VIRTUAL_ENV: venvDir },
          });
          steps.push(`pip install: ${pkgs.join(", ")}`);
        } catch (e) {
          return { ok: false, error: `pip failed: ${e instanceof Error ? e.message : String(e)}`, steps };
        }
      }
    }
    if (kind === "node" || kind === "both") {
      const pkg = path.join(workspaceRoot, "package.json");
      if (!fsSync.existsSync(pkg)) {
        await fs.writeFile(pkg, JSON.stringify({ name: "ricky-workspace", version: "1.0.0", private: true }, null, 2));
        steps.push("Created package.json");
      }
      if (kind === "node" && Array.isArray(args.packages) && args.packages.length) {
        const pkgs = args.packages.map(String).filter(Boolean);
        try {
          await execAsync(`npm install ${pkgs.map((p) => JSON.stringify(p)).join(" ")}`, {
            cwd: workspaceRoot,
            timeout: 300000,
          });
          steps.push(`npm install: ${pkgs.join(", ")}`);
        } catch (e) {
          return { ok: false, error: `npm failed: ${e instanceof Error ? e.message : String(e)}`, steps };
        }
      }
    }
    const status = await workspaceStatus();
    return {
      ok: true,
      steps,
      ...status,
      artifact: {
        title: "Workspace Setup",
        kind: "markdown",
        content: ["# Workspace Setup", ...steps.map((s) => `- ${s}`), "", status.artifact.content].join("\n"),
      },
    };
  }

  async function workspaceRun(args) {
    await ensureWorkspace();
    const runtime = String(args.runtime || "shell").toLowerCase();
    const command = String(args.command || "").trim();
    if (runtime === "python") {
      if (!venvExists()) return { ok: false, error: "Call workspace_setup first." };
      const code = String(args.code || command || "").trim();
      if (!code) return { ok: false, error: "code or command required." };
      if (args.code) {
        return runTerminalCommand(
          { command: `${JSON.stringify(venvPython())} -c ${JSON.stringify(code)}`, timeoutMs: args.timeoutMs },
          { forceCwd: workspaceRoot }
        );
      }
      return runTerminalCommand(
        { command: `${JSON.stringify(venvPython())} ${code}`, timeoutMs: args.timeoutMs },
        { forceCwd: workspaceRoot }
      );
    }
    if (runtime === "node") {
      const code = String(args.code || command || "").trim();
      if (!code) return { ok: false, error: "code or command required." };
      if (args.code) {
        return runTerminalCommand(
          { command: `node -e ${JSON.stringify(code)}`, timeoutMs: args.timeoutMs },
          { forceCwd: workspaceRoot }
        );
      }
      return runTerminalCommand({ command: code, timeoutMs: args.timeoutMs }, { forceCwd: workspaceRoot });
    }
    if (!command) return { ok: false, error: "command is required." };
    return runTerminalCommand({ command, timeoutMs: args.timeoutMs }, { forceCwd: workspaceRoot });
  }

  async function workspaceWriteFile(args) {
    await ensureWorkspace();
    const rel = String(args.path || "").replace(/^[/\\]+/, "");
    if (!rel || rel.includes("..")) return { ok: false, error: "relative path only, no .." };
    const full = path.join(workspaceRoot, rel);
    if (!full.startsWith(workspaceRoot)) return { ok: false, error: "path escapes workspace" };
    await fs.mkdir(path.dirname(full), { recursive: true });
    await fs.writeFile(full, String(args.content ?? ""), "utf8");
    return {
      ok: true,
      path: full,
      artifact: { title: "Workspace File", kind: "markdown", content: `Wrote \`${rel}\`` },
    };
  }

  async function workspaceReadFile(args) {
    await ensureWorkspace();
    const rel = String(args.path || "").replace(/^[/\\]+/, "");
    if (!rel || rel.includes("..")) return { ok: false, error: "relative path only, no .." };
    const full = path.join(workspaceRoot, rel);
    if (!full.startsWith(workspaceRoot)) return { ok: false, error: "path escapes workspace" };
    try {
      const content = await fs.readFile(full, "utf8");
      const clipped = content.length > 40000 ? content.slice(0, 40000) + "\n… [truncated]" : content;
      return {
        ok: true,
        path: full,
        content: clipped,
        artifact: { title: rel, kind: "code", language: path.extname(rel).slice(1) || "text", content: clipped },
      };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }

  // ── Project learn / scan / recall ───────────────────────────────────────

  function isProbablyTextFile(filePath) {
    const base = path.basename(filePath).toLowerCase();
    if (["dockerfile", "makefile", "license", "procfile"].includes(base)) return true;
    if (base.startsWith(".env") && !base.endsWith(".local")) return true;
    const ext = path.extname(filePath).toLowerCase();
    // skip true binaries; pdf/docx noted but read as text may fail — still attempt small files
    if ([".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".zip", ".gz", ".exe", ".dll", ".so", ".dylib", ".wasm", ".mp3", ".mp4", ".mov"].includes(ext)) {
      return false;
    }
    if (TEXT_EXTENSIONS.has(ext)) return true;
    if (!ext) return true;
    return false;
  }

  async function walkProject(root, { maxFiles = 400, maxDepth = 10 } = {}) {
    const files = [];
    async function walk(dir, depth) {
      if (files.length >= maxFiles || depth > maxDepth) return;
      let entries;
      try {
        entries = await fs.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const entry of entries) {
        if (files.length >= maxFiles) break;
        const name = entry.name;
        if (name === "." || name === "..") continue;
        if (entry.isDirectory()) {
          if (IGNORE_DIR_NAMES.has(name)) continue;
          if (name.startsWith(".") && name !== ".github") continue;
          await walk(path.join(dir, name), depth + 1);
        } else if (entry.isFile()) {
          const full = path.join(dir, name);
          let size = 0;
          try {
            size = (await fs.stat(full)).size;
          } catch {
            continue;
          }
          files.push({ rel: path.relative(root, full), full, size, ext: path.extname(name).toLowerCase() });
        }
      }
    }
    await walk(root, 0);
    files.sort((a, b) => a.rel.localeCompare(b.rel));
    return files;
  }

  async function safeReadText(full, maxBytes = 100000) {
    try {
      const buf = await fs.readFile(full);
      if (buf.includes(0) && !full.toLowerCase().endsWith(".pdf")) return null;
      const text = buf.slice(0, maxBytes).toString("utf8");
      return buf.length > maxBytes ? text + "\n… [truncated]" : text;
    } catch {
      return null;
    }
  }

  function languageStats(files) {
    const counts = {};
    for (const f of files) {
      const ext = f.ext || "(none)";
      counts[ext] = (counts[ext] || 0) + 1;
    }
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 25)
      .map(([ext, count]) => ({ ext, count }));
  }

  function extractInsights(text) {
    const insights = [];
    for (const line of text.split(/\r?\n/).slice(0, 500)) {
      const t = line.trim();
      if (
        /^(export\s+)?(async\s+)?function\s+\w+/.test(t) ||
        /^export\s+(const|class|default)/.test(t) ||
        /^def\s+\w+/.test(t) ||
        /^class\s+\w+/.test(t) ||
        /^##\s+/.test(t) ||
        /^#\s+[^#]/.test(t)
      ) {
        insights.push(t.slice(0, 180));
      }
      if (insights.length >= 15) break;
    }
    return insights;
  }

  async function projectScan(args) {
    const root = path.resolve(String(args.path || "").trim());
    if (!root) return { ok: false, error: "path is required (folder to scan)." };
    try {
      if (!(await fs.stat(root)).isDirectory()) return { ok: false, error: "path must be a directory." };
    } catch {
      return { ok: false, error: `Directory not found: ${root}` };
    }
    const maxFiles = Math.max(20, Math.min(3000, Number(args.maxFiles) || 500));
    const files = await walkProject(root, { maxFiles });
    const langs = languageStats(files);
    const priorityHits = [];
    for (const pref of PRIORITY_FILES) {
      const hit = files.find((f) => f.rel === pref || f.rel.endsWith("/" + pref));
      if (hit) priorityHits.push(hit.rel);
    }
    const treeSample = files.slice(0, 150).map((f) => f.rel);
    const content = [
      `# Project scan: ${path.basename(root)}`,
      `**Path:** \`${root}\``,
      `**Files:** ${files.length}${files.length >= maxFiles ? " (capped)" : ""}`,
      "",
      "## Extensions",
      ...langs.map((l) => `- \`${l.ext}\`: ${l.count}`),
      "",
      "## Priority files",
      ...(priorityHits.length ? priorityHits.map((r) => `- \`${r}\``) : ["_None found_"]),
      "",
      "## Tree sample",
      "```",
      ...treeSample,
      files.length > treeSample.length ? `… +${files.length - treeSample.length} more` : "",
      "```",
    ].join("\n");
    return {
      ok: true,
      root,
      fileCount: files.length,
      languages: langs,
      priorityFiles: priorityHits,
      files: files.slice(0, 300).map((f) => ({ path: f.rel, size: f.size })),
      artifact: { title: `Scan: ${path.basename(root)}`, kind: "markdown", content },
    };
  }

  async function projectRead(args) {
    const root = path.resolve(String(args.root || args.base || "").trim() || process.cwd());
    const rel = String(args.path || "").trim();
    if (!rel) return { ok: false, error: "path is required." };
    let full = path.isAbsolute(rel) ? rel : path.resolve(root, rel);
    if (!path.isAbsolute(String(args.path || "")) && args.root && !full.startsWith(root)) {
      return { ok: false, error: "path escapes project root." };
    }
    const maxChars = Math.max(1000, Math.min(150000, Number(args.maxChars) || 50000));
    try {
      const st = await fs.stat(full);
      if (!st.isFile()) return { ok: false, error: "Not a file." };
      if (st.size > 5_000_000 && !args.force) {
        return { ok: false, error: `File large (${st.size} bytes). Set force=true to read.` };
      }
      const text = await safeReadText(full, maxChars * 2);
      if (text === null) return { ok: false, error: "Binary or unreadable file." };
      const clipped = text.length > maxChars ? text.slice(0, maxChars) + "\n… [truncated]" : text;
      const display = path.relative(root, full) || full;
      return {
        ok: true,
        path: full,
        relative: display,
        content: clipped,
        artifact: {
          title: display,
          kind: "code",
          language: path.extname(full).slice(1) || "text",
          content: clipped,
        },
      };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }

  async function projectSearch(args) {
    const root = path.resolve(String(args.path || args.root || "").trim());
    const query = String(args.query || "").trim();
    if (!root || !query) return { ok: false, error: "path and query required." };
    try {
      if (!(await fs.stat(root)).isDirectory()) return { ok: false, error: "path must be a directory." };
    } catch {
      return { ok: false, error: `Not found: ${root}` };
    }
    const maxFiles = Math.max(20, Math.min(800, Number(args.maxFiles) || 400));
    const files = await walkProject(root, { maxFiles });
    const q = query.toLowerCase();
    const hits = [];
    for (const f of files) {
      if (!isProbablyTextFile(f.full) || f.size > 500000) continue;
      const text = await safeReadText(f.full, 120000);
      if (!text) continue;
      const lines = text.split(/\r?\n/);
      for (let i = 0; i < lines.length; i++) {
        if (lines[i].toLowerCase().includes(q)) {
          hits.push({ path: f.rel, line: i + 1, text: lines[i].trim().slice(0, 240) });
          if (hits.length >= 50) break;
        }
      }
      if (hits.length >= 50) break;
    }
    return {
      ok: true,
      query,
      root,
      hits,
      artifact: {
        title: `Search: ${query}`,
        kind: "markdown",
        content:
          `# Search: ${query}\nIn: \`${root}\`\n\n` +
          (hits.length ? hits.map((h) => `- \`${h.path}:${h.line}\` — ${h.text}`).join("\n") : "_No matches._"),
      },
    };
  }

  async function projectLearn(args) {
    const root = path.resolve(String(args.path || "").trim());
    if (!root) return { ok: false, error: "path is required — folder of files/documents/bot to learn from." };
    try {
      if (!(await fs.stat(root)).isDirectory()) return { ok: false, error: "path must be a directory." };
    } catch {
      return { ok: false, error: `Directory not found: ${root}` };
    }

    await ensureKnowledgeDir();
    const name = slugify(args.name || path.basename(root));
    const maxFiles = Math.max(30, Math.min(1500, Number(args.maxFiles) || 400));
    const files = await walkProject(root, { maxFiles, maxDepth: 12 });
    const langs = languageStats(files);

    const toRead = [];
    const seen = new Set();
    for (const pref of PRIORITY_FILES) {
      const hit = files.find((f) => f.rel === pref || f.rel.endsWith("/" + pref));
      if (hit && !seen.has(hit.rel)) {
        seen.add(hit.rel);
        toRead.push(hit);
      }
    }
    for (const f of files) {
      if (toRead.length >= 60) break;
      if (seen.has(f.rel)) continue;
      if (!isProbablyTextFile(f.full)) continue;
      if (f.size > 300000) continue;
      seen.add(f.rel);
      toRead.push(f);
    }

    const fileNotes = [];
    for (const f of toRead) {
      const text = await safeReadText(f.full, 80000);
      if (!text) continue;
      fileNotes.push({
        path: f.rel,
        size: f.size,
        preview: text.slice(0, 4000),
        insights: extractInsights(text),
      });
    }

    const briefLines = [
      `# Knowledge: ${name}`,
      "",
      `Learned from: \`${root}\``,
      `Indexed files: ${files.length}`,
      `Deep-read: ${fileNotes.length}`,
      `Saved: ${new Date().toISOString()}`,
      "",
      "## Stack",
      ...langs.slice(0, 15).map((l) => `- \`${l.ext}\`: ${l.count}`),
      "",
      "## Key files & content",
    ];
    for (const note of fileNotes) {
      briefLines.push(`### \`${note.path}\``);
      if (note.insights.length) {
        briefLines.push("Signals:");
        for (const i of note.insights.slice(0, 10)) briefLines.push(`- \`${i}\``);
      }
      briefLines.push("");
      briefLines.push("```");
      briefLines.push(note.preview.slice(0, 2000));
      briefLines.push("```");
      briefLines.push("");
    }

    const pack = {
      id: name,
      root,
      learnedAt: new Date().toISOString(),
      fileCount: files.length,
      languages: langs,
      files: files.map((f) => ({ path: f.rel, size: f.size })),
      notes: fileNotes.map((n) => ({
        path: n.path,
        size: n.size,
        insights: n.insights,
        preview: n.preview.slice(0, 6000),
      })),
      brief: briefLines.join("\n"),
    };

    const outPath = path.join(knowledgeDir, `${name}.json`);
    const briefPath = path.join(knowledgeDir, `${name}.md`);
    await fs.writeFile(outPath, JSON.stringify(pack, null, 2), "utf8");
    await fs.writeFile(briefPath, pack.brief, "utf8");

    // Also append to a master index the model can list quickly
    const indexPath = path.join(knowledgeDir, "index.json");
    let index = [];
    try {
      index = JSON.parse(await fs.readFile(indexPath, "utf8"));
      if (!Array.isArray(index)) index = [];
    } catch {
      index = [];
    }
    index = index.filter((x) => x.id !== name);
    index.unshift({ id: name, root, learnedAt: pack.learnedAt, fileCount: pack.fileCount, deepRead: fileNotes.length });
    await fs.writeFile(indexPath, JSON.stringify(index, null, 2), "utf8");

    return {
      ok: true,
      id: name,
      root,
      fileCount: files.length,
      deepRead: fileNotes.length,
      knowledgePath: outPath,
      briefPath,
      artifact: {
        title: `Learned: ${name}`,
        kind: "markdown",
        content:
          pack.brief.slice(0, 16000) +
          (pack.brief.length > 16000
            ? "\n\n… [truncated in panel — full knowledge saved to data/knowledge/]"
            : ""),
      },
    };
  }

  async function projectRecall(args) {
    await ensureKnowledgeDir();
    const id = args.id ? slugify(args.id) : null;
    if (!id) {
      let list = [];
      try {
        list = JSON.parse(await fs.readFile(path.join(knowledgeDir, "index.json"), "utf8"));
      } catch {
        const entries = await fs.readdir(knowledgeDir).catch(() => []);
        for (const file of entries.filter((e) => e.endsWith(".json") && e !== "index.json")) {
          try {
            const raw = JSON.parse(await fs.readFile(path.join(knowledgeDir, file), "utf8"));
            list.push({
              id: raw.id || file.replace(/\.json$/, ""),
              root: raw.root,
              learnedAt: raw.learnedAt,
              fileCount: raw.fileCount,
            });
          } catch {
            /* skip */
          }
        }
      }
      return {
        ok: true,
        knowledge: list,
        artifact: {
          title: "Knowledge packs",
          kind: "markdown",
          content:
            "# Saved knowledge\n\n" +
            (list.length
              ? list
                  .map(
                    (k) =>
                      `- **${k.id}** — \`${k.root || "?"}\` — ${k.fileCount ?? "?"} files — ${k.learnedAt || ""}`
                  )
                  .join("\n")
              : "_None yet. Ask me to learn from a folder path._"),
        },
      };
    }

    try {
      const pack = JSON.parse(await fs.readFile(path.join(knowledgeDir, `${id}.json`), "utf8"));
      const maxChars = Math.max(2000, Math.min(40000, Number(args.maxChars) || 14000));
      const brief = String(pack.brief || "").slice(0, maxChars);
      return {
        ok: true,
        id: pack.id,
        root: pack.root,
        learnedAt: pack.learnedAt,
        fileCount: pack.fileCount,
        brief,
        notes: (pack.notes || []).slice(0, 40).map((n) => ({
          path: n.path,
          insights: n.insights,
          preview: String(n.preview || "").slice(0, 2000),
        })),
        artifact: {
          title: `Knowledge: ${pack.id}`,
          kind: "markdown",
          content: brief + (String(pack.brief || "").length > maxChars ? "\n… [truncated]" : ""),
        },
      };
    } catch {
      return { ok: false, error: `No knowledge pack "${id}". Call project_recall with no id to list.` };
    }
  }

  // ── Browser (multi-tab) ─────────────────────────────────────────────────

  function listTabsSummary() {
    const rows = [];
    for (const [id, win] of browserTabs.entries()) {
      if (win.isDestroyed()) continue;
      rows.push({
        id,
        active: id === activeTabId,
        title: win.webContents.getTitle() || "(untitled)",
        url: win.webContents.getURL() || "",
      });
    }
    return rows;
  }

  function tabsArtifact() {
    const tabs = listTabsSummary();
    return {
      title: "Browser Tabs",
      kind: "markdown",
      content:
        "# Agent Browser Tabs\n\n" +
        (tabs.length
          ? tabs
              .map(
                (t) =>
                  `- ${t.active ? "**" : ""}${t.id}${t.active ? "** (active)" : ""} — ${t.title} — ${t.url}`
              )
              .join("\n")
          : "_No tabs open._"),
    };
  }

  function getActiveWindow() {
    if (activeTabId && browserTabs.has(activeTabId)) {
      const win = browserTabs.get(activeTabId);
      if (win && !win.isDestroyed()) return win;
    }
    for (const [id, win] of browserTabs.entries()) {
      if (!win.isDestroyed()) {
        activeTabId = id;
        return win;
      }
    }
    return null;
  }

  function waitForPageLoad(win, timeoutMs = 30000) {
    return new Promise((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        win.webContents.removeListener("did-finish-load", onLoad);
        win.webContents.removeListener("did-fail-load", onFail);
        resolve();
      };
      const onLoad = () => finish();
      const onFail = () => finish();
      const timer = setTimeout(finish, timeoutMs);
      win.webContents.once("did-finish-load", onLoad);
      win.webContents.once("did-fail-load", onFail);
    });
  }

  function createTabWindow(tabId) {
    const win = new BrowserWindow({
      width: 1280,
      height: 900,
      minWidth: 640,
      minHeight: 480,
      title: `Gracie Browser — ${tabId}`,
      show: true,
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        partition: "persist:ricky-agent-browser",
      },
    });
    win.webContents.setWindowOpenHandler(()=>({action:'deny'}));
    win.webContents.on('will-navigate',(event,url)=>{if(!/^https?:/i.test(url)&&url!=='about:blank')event.preventDefault();});
    win.on("closed", () => {
      browserTabs.delete(tabId);
      if (activeTabId === tabId) activeTabId = browserTabs.keys().next().value || null;
    });
    win.on("focus", () => {
      activeTabId = tabId;
    });
    browserTabs.set(tabId, win);
    activeTabId = tabId;
    return win;
  }

  async function browserOpen(args) {
    const newTab = args.newTab === true;
    let tabId = typeof args.tabId === "string" && args.tabId.trim() ? args.tabId.trim() : null;
    let win = null;
    if (!newTab && tabId && browserTabs.has(tabId) && !browserTabs.get(tabId).isDestroyed()) {
      win = browserTabs.get(tabId);
      activeTabId = tabId;
    } else if (!newTab && !tabId) {
      win = getActiveWindow();
    }
    if (!win) {
      tabId = tabId || `tab-${crypto.randomBytes(3).toString("hex")}`;
      win = createTabWindow(tabId);
    } else {
      tabId = [...browserTabs.entries()].find(([, w]) => w === win)?.[0] || tabId;
    }
    const url = normalizeUrl(args.url);
    if (url) {
      const loadPromise = waitForPageLoad(win);
      await win.loadURL(url);
      await loadPromise;
    } else if (!win.webContents.getURL()) {
      await win.loadURL("about:blank");
    }
    win.show();
    win.focus();
    return {
      ok: true,
      tabId,
      url: win.webContents.getURL(),
      title: win.webContents.getTitle(),
      tabs: listTabsSummary(),
      artifact: tabsArtifact(),
    };
  }

  async function browserNavigate(args) {
    const url = normalizeUrl(args.url);
    if (!url) return { ok: false, error: "url is required." };
    return browserOpen({ ...args, url });
  }

  async function browserRead(args) {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    const maxChars = Math.max(500, Math.min(50000, Number(args.maxChars) || 8000));
    const url = win.webContents.getURL();
    const title = win.webContents.getTitle();
    const observed = await win.webContents.executeJavaScript(
      `(() => { const controls=[...document.querySelectorAll('button,a,input,textarea,select,[role="button"],[contenteditable="true"]')].filter(el=>el.getClientRects().length).slice(0,100).map(el=>{const name=el.getAttribute('aria-label')||el.labels?.[0]?.innerText||el.innerText||el.placeholder||el.name||'';return {selector:el.id?'#'+CSS.escape(el.id):null,tag:el.tagName.toLowerCase(),name:String(name).slice(0,160),type:el.type||el.getAttribute('role')||'',disabled:el.matches(':disabled'),password:el.type==='password'};});return {text:String(document.body?.innerText||'').replace(/\\s+/g,' ').trim(),controls}; })()`,
      true
    );
    const clipped = String(observed.text || "").slice(0, maxChars);
    return {
      ok: true,
      tabId: activeTabId,
      url,
      title,
      text: clipped,
      controls: observed.controls,
      artifact: {
        title: "Browser Page",
        kind: "markdown",
        content: `# ${title || "Page"}\nURL: ${url}\n\n${clipped || "(empty)"}`,
      },
    };
  }

  async function inspectBrowserAction(args) {
    const win=getActiveWindow();if(!win)return {ok:false,error:'No browser tab open.'};
    const target=await win.webContents.executeJavaScript(`(()=>{const selector=${JSON.stringify(String(args.selector||''))};let el=selector?document.querySelector(selector):Number.isFinite(${JSON.stringify(args.x??null)})&&Number.isFinite(${JSON.stringify(args.y??null)})?document.elementFromPoint(${JSON.stringify(args.x??null)},${JSON.stringify(args.y??null)}):document.activeElement;el=el?.closest('button,a,input,textarea,select,[role="button"],[contenteditable="true"]')||el;if(!el||el===document.body||el===document.documentElement)return null;return {name:String(el.getAttribute('aria-label')||el.labels?.[0]?.innerText||el.innerText||el.placeholder||el.name||'').slice(0,160),type:el.type||el.getAttribute('role')||'',password:el.type==='password',submitsForm:!!el.form&&['submit','image'].includes(el.type),disabled:el.matches(':disabled')};})()`,true);
    return {ok:true,tabId:activeTabId,url:win.webContents.getURL(),target};
  }

  async function browserClick(args) {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    if (requiresConfirmation(args)) {
      return { ok: false, requiresConfirmation: true, message: "Confirmation required." };
    }
    const selector = typeof args.selector === "string" ? args.selector.trim() : "";
    if (selector) {
      const result = await win.webContents.executeJavaScript(
        `(() => { const el = document.querySelector(${JSON.stringify(selector)}); if (!el) return { ok:false, error:"not found" }; el.scrollIntoView({block:"center"}); el.click(); return { ok:true }; })()`,
        true
      );
      if (!result?.ok) return { ok: false, error: result?.error || "click failed" };
      return { ok: true, message: `Clicked ${selector}` };
    }
    if (typeof args.x === "number" && typeof args.y === "number") {
      const x = Math.round(args.x);
      const y = Math.round(args.y);
      win.webContents.sendInputEvent({ type: "mouseDown", x, y, button: "left", clickCount: 1 });
      win.webContents.sendInputEvent({ type: "mouseUp", x, y, button: "left", clickCount: 1 });
      return { ok: true, message: `Clicked (${x},${y})` };
    }
    return { ok: false, error: "selector or x/y required" };
  }

  async function browserType(args) {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    const text = String(args.text ?? "");
    const selector = typeof args.selector === "string" ? args.selector.trim() : "";
    if (selector) {
      const focused = await win.webContents.executeJavaScript(
        `(() => { const el = document.querySelector(${JSON.stringify(selector)}); if (!el) return { ok:false }; el.focus(); if (${args.clearFirst === true ? "true" : "false"} && "value" in el) { el.value=""; el.dispatchEvent(new Event("input",{bubbles:true})); } return { ok:true }; })()`,
        true
      );
      if (!focused?.ok) return { ok: false, error: "focus failed" };
    }
    for (const char of text) win.webContents.sendInputEvent({ type: "char", keyCode: char });
    if (args.pressEnter) {
      win.webContents.sendInputEvent({ type: "keyDown", keyCode: "Return" });
      win.webContents.sendInputEvent({ type: "keyUp", keyCode: "Return" });
    }
    return { ok: true, message: "Typed." };
  }

  async function browserPressKey(args) {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    const keyMap = {
      enter: "Return",
      return: "Return",
      tab: "Tab",
      escape: "Escape",
      backspace: "Backspace",
      delete: "Delete",
      space: "Space",
      up: "Up",
      down: "Down",
      left: "Left",
      right: "Right",
    };
    const key = keyMap[String(args.key || "").toLowerCase()];
    if (!key) return { ok: false, error: `Unsupported key: ${args.key}` };
    const repeat = Math.max(1, Math.min(20, Number(args.repeat || 1)));
    for (let i = 0; i < repeat; i++) {
      win.webContents.sendInputEvent({ type: "keyDown", keyCode: key });
      win.webContents.sendInputEvent({ type: "keyUp", keyCode: key });
    }
    return { ok: true, message: `Pressed ${args.key}` };
  }

  async function browserScreenshot() {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    await fs.mkdir(dataDir, { recursive: true });
    const screenshotPath = path.join(dataDir, `agent-browser-${Date.now()}.png`);
    const captured=await win.webContents.capturePage();await fs.writeFile(screenshotPath, captured.toPNG());
    const dimensions=captured.getSize();
    return {
      ok: true,
      path: screenshotPath,
      dataUrl:'data:image/jpeg;base64,'+captured.resize({width:Math.min(1280,dimensions.width)}).toJPEG(75).toString('base64'),
      displayWidth:dimensions.width,displayHeight:dimensions.height,
      artifact: { title: "Browser Screenshot", kind: "image", content: screenshotPath },
    };
  }

  async function browserEval(args) {
    const win = getActiveWindow();
    if (!win) return { ok: false, error: "No browser tab open." };
    const expression = String(args.expression || "").trim();
    if (!expression) return { ok: false, error: "expression required" };
    try {
      const result = await win.webContents.executeJavaScript(
        `(() => { const r = eval(${JSON.stringify(expression)}); try { return JSON.stringify(r,null,2); } catch { return String(r); } })()`,
        true
      );
      const content = String(result ?? "undefined").slice(0, 24000);
      return { ok: true, result: content, artifact: { title: "Browser Eval", kind: "code", language: "json", content } };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }

  function browserCloseAll() {
    for (const [, win] of browserTabs.entries()) {
      if (!win.isDestroyed()) {
        win.removeAllListeners("closed");
        win.destroy();
      }
    }
    browserTabs.clear();
    activeTabId = null;
    return { ok: true, message: "Browser closed." };
  }

  // ── Playwright optional ─────────────────────────────────────────────────

  async function probePlaywright() {
    if (playwrightAvailable !== null) return playwrightAvailable;
    try {
      require.resolve("playwright");
      playwrightAvailable = true;
    } catch {
      playwrightAvailable = false;
    }
    return playwrightAvailable;
  }

  async function playwrightLaunch(args) {
    if (!(await probePlaywright())) {
      return {
        ok: false,
        error: "Playwright not installed. Run: npm install playwright && npx playwright install chromium",
      };
    }
    const { chromium } = require("playwright");
    if (playwrightBrowser) {
      try {
        await playwrightBrowser.close();
      } catch {
        /* ignore */
      }
    }
    playwrightBrowser = await chromium.launch({ headless: Boolean(args.headless) });
    const context = await playwrightBrowser.newContext({ viewport: { width: 1280, height: 800 } });
    playwrightPage = await context.newPage();
    if (args.url) {
      await playwrightPage.goto(normalizeUrl(args.url), { waitUntil: "domcontentloaded", timeout: 60000 });
    }
    return { ok: true, message: "Playwright launched.", url: playwrightPage.url() };
  }

  async function playwrightNavigate(args) {
    if (!playwrightPage) return { ok: false, error: "Call playwright_launch first." };
    const url = normalizeUrl(args.url);
    if (!url) return { ok: false, error: "url required" };
    await playwrightPage.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 });
    return { ok: true, url: playwrightPage.url(), title: await playwrightPage.title() };
  }

  async function playwrightClick(args) {
    if (!playwrightPage) return { ok: false, error: "Call playwright_launch first." };
    if (requiresConfirmation(args)) return { ok: false, requiresConfirmation: true, message: "Confirmation required." };
    await playwrightPage.click(String(args.selector || ""), { timeout: 15000 });
    return { ok: true, message: `Clicked ${args.selector}` };
  }

  async function playwrightType(args) {
    if (!playwrightPage) return { ok: false, error: "Call playwright_launch first." };
    const selector = String(args.selector || "");
    const text = String(args.text ?? "");
    if (args.clearFirst) await playwrightPage.fill(selector, text);
    else await playwrightPage.type(selector, text);
    if (args.pressEnter) await playwrightPage.press(selector, "Enter");
    return { ok: true, message: "Typed." };
  }

  async function playwrightRead(args) {
    if (!playwrightPage) return { ok: false, error: "Call playwright_launch first." };
    const maxChars = Math.max(500, Math.min(50000, Number(args.maxChars) || 8000));
    const title = await playwrightPage.title();
    const url = playwrightPage.url();
    const text = (await playwrightPage.innerText("body").catch(() => ""))
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, maxChars);
    return {
      ok: true,
      url,
      title,
      text,
      artifact: { title: "Playwright Page", kind: "markdown", content: `# ${title}\n${url}\n\n${text}` },
    };
  }

  async function playwrightScreenshot() {
    if (!playwrightPage) return { ok: false, error: "Call playwright_launch first." };
    await fs.mkdir(dataDir, { recursive: true });
    const screenshotPath = path.join(dataDir, `playwright-${Date.now()}.png`);
    await playwrightPage.screenshot({ path: screenshotPath });
    return {
      ok: true,
      path: screenshotPath,
      artifact: { title: "Playwright Screenshot", kind: "image", content: screenshotPath },
    };
  }

  async function playwrightClose() {
    if (playwrightBrowser) {
      try {
        await playwrightBrowser.close();
      } catch {
        /* ignore */
      }
    }
    playwrightBrowser = null;
    playwrightPage = null;
    return { ok: true, message: "Playwright closed." };
  }

  // ── Tool specs ──────────────────────────────────────────────────────────

  const toolSpecs = [
    {
      type: "function",
      name: "terminal_run",
      description: "Run a shell command with user permissions. Requires computer mode.",
      parameters: {
        type: "object",
        properties: { command: { type: "string" }, cwd: { type: "string" }, timeoutMs: { type: "number" } },
        required: ["command"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "workspace_status",
      description: "Show workspace and venv status.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
    {
      type: "function",
      name: "workspace_setup",
      description: "Create Python venv and/or Node project in data/workspace; install packages.",
      parameters: {
        type: "object",
        properties: {
          kind: { type: "string", enum: ["python", "node", "both"] },
          packages: { type: "array", items: { type: "string" } },
        },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "workspace_run",
      description: "Run shell/python/node inside workspace.",
      parameters: {
        type: "object",
        properties: {
          runtime: { type: "string", enum: ["shell", "python", "node"] },
          command: { type: "string" },
          code: { type: "string" },
          timeoutMs: { type: "number" },
        },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "workspace_write_file",
      description: "Write file under data/workspace.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" }, content: { type: "string" } },
        required: ["path", "content"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "workspace_read_file",
      description: "Read file under data/workspace.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" } },
        required: ["path"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "project_scan",
      description: "Scan any folder (another bot, docs, codebase): tree, languages, priority files.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" }, maxFiles: { type: "number" } },
        required: ["path"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "project_read",
      description: "Read one file from a project or absolute path.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string" },
          root: { type: "string" },
          maxChars: { type: "number" },
          force: { type: "boolean" },
        },
        required: ["path"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "project_search",
      description: "Search text across files in a folder.",
      parameters: {
        type: "object",
        properties: { path: { type: "string" }, query: { type: "string" }, maxFiles: { type: "number" } },
        required: ["path", "query"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "project_learn",
      description:
        "LEARN FROM A FOLDER: recursively scan any bot/project/docs folder, read key files and documents, extract structure and content, and SAVE durable knowledge under data/knowledge/. Use whenever the user wants Gracie to study another bot or a folder of files and improve from it. Optional name sets the knowledge pack id.",
      parameters: {
        type: "object",
        properties: {
          path: { type: "string", description: "Absolute or relative path to the folder to learn from." },
          name: { type: "string", description: "Optional name for this knowledge pack." },
          maxFiles: { type: "number" },
        },
        required: ["path"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "project_recall",
      description:
        "List or load saved knowledge packs from data/knowledge/. Call with no id to list; with id to load full learned content so you can use it in answers and improve behavior from that bot/docs.",
      parameters: {
        type: "object",
        properties: { id: { type: "string" }, maxChars: { type: "number" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_open",
      description: "Open multi-tab agent browser. newTab:true for another tab.",
      parameters: {
        type: "object",
        properties: { url: { type: "string" }, newTab: { type: "boolean" }, tabId: { type: "string" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_navigate",
      description: "Navigate agent browser.",
      parameters: {
        type: "object",
        properties: { url: { type: "string" }, tabId: { type: "string" }, newTab: { type: "boolean" } },
        required: ["url"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_tabs",
      description: "List browser tabs.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
    {
      type: "function",
      name: "browser_tab_focus",
      description: "Focus a tab by id.",
      parameters: {
        type: "object",
        properties: { tabId: { type: "string" } },
        required: ["tabId"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_tab_close",
      description: "Close a browser tab.",
      parameters: {
        type: "object",
        properties: { tabId: { type: "string" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_read",
      description: "Read active browser page text.",
      parameters: {
        type: "object",
        properties: { maxChars: { type: "number" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_click",
      description: "Click in agent browser.",
      parameters: {
        type: "object",
        properties: {
          selector: { type: "string" },
          x: { type: "number" },
          y: { type: "number" },
          confirmed: { type: "boolean" },
          risk: { type: "string", enum: ["low", "may_send_or_modify", "private_or_sensitive"] },
        },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_type",
      description: "Type in agent browser.",
      parameters: {
        type: "object",
        properties: {
          text: { type: "string" },
          selector: { type: "string" },
          clearFirst: { type: "boolean" },
          pressEnter: { type: "boolean" },
        },
        required: ["text"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_press_key",
      description: "Press key in agent browser.",
      parameters: {
        type: "object",
        properties: {
          key: {
            type: "string",
            enum: ["enter", "return", "tab", "escape", "backspace", "delete", "space", "up", "down", "left", "right"],
          },
          repeat: { type: "number" },
        },
        required: ["key"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_screenshot",
      description: "Screenshot agent browser.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
    {
      type: "function",
      name: "browser_eval",
      description: "Run JS in agent browser page.",
      parameters: {
        type: "object",
        properties: { expression: { type: "string" } },
        required: ["expression"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "browser_close",
      description: "Close all agent browser tabs.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
    {
      type: "function",
      name: "playwright_launch",
      description: "Optional Playwright. Needs: npm install playwright && npx playwright install chromium",
      parameters: {
        type: "object",
        properties: { url: { type: "string" }, headless: { type: "boolean" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "playwright_navigate",
      description: "Playwright navigate.",
      parameters: {
        type: "object",
        properties: { url: { type: "string" } },
        required: ["url"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "playwright_click",
      description: "Playwright click.",
      parameters: {
        type: "object",
        properties: {
          selector: { type: "string" },
          confirmed: { type: "boolean" },
          risk: { type: "string", enum: ["low", "may_send_or_modify", "private_or_sensitive"] },
        },
        required: ["selector"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "playwright_type",
      description: "Playwright type.",
      parameters: {
        type: "object",
        properties: {
          selector: { type: "string" },
          text: { type: "string" },
          clearFirst: { type: "boolean" },
          pressEnter: { type: "boolean" },
        },
        required: ["selector", "text"],
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "playwright_read",
      description: "Playwright read page.",
      parameters: {
        type: "object",
        properties: { maxChars: { type: "number" } },
        additionalProperties: false,
      },
    },
    {
      type: "function",
      name: "playwright_screenshot",
      description: "Playwright screenshot.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
    {
      type: "function",
      name: "playwright_close",
      description: "Close Playwright.",
      parameters: { type: "object", properties: {}, additionalProperties: false },
    },
  ];

  const handlerNames = new Set(toolSpecs.map((t) => t.name));

  async function execute(name, args, context = {}) {
    switch (name) {
      case "terminal_run": {
        const blocked = requireComputerMode();
        if (blocked) return blocked;
        return runTerminalCommand(args, {signal:context.signal});
      }
      case "workspace_status":
        return workspaceStatus();
      case "workspace_setup":
        return workspaceSetup(args);
      case "workspace_run":
        return workspaceRun(args);
      case "workspace_write_file":
        return workspaceWriteFile(args);
      case "workspace_read_file":
        return workspaceReadFile(args);
      case "project_scan":
        return projectScan(args);
      case "project_read":
        return projectRead(args);
      case "project_search":
        return projectSearch(args);
      case "project_learn":
        return projectLearn(args);
      case "project_recall":
        return projectRecall(args);
      case "browser_open":
        return browserOpen(args);
      case "browser_navigate":
        return browserNavigate(args);
      case "browser_tabs":
        return {
          ok: true,
          tabs: listTabsSummary(),
          activeTabId,
          artifact: tabsArtifact(),
        };
      case "browser_tab_focus": {
        const tabId = String(args.tabId || "").trim();
        if (!tabId || !browserTabs.has(tabId) || browserTabs.get(tabId).isDestroyed()) {
          return { ok: false, error: `Unknown tab: ${tabId}` };
        }
        activeTabId = tabId;
        browserTabs.get(tabId).show();
        browserTabs.get(tabId).focus();
        return { ok: true, tabId, tabs: listTabsSummary(), artifact: tabsArtifact() };
      }
      case "browser_tab_close": {
        const tabId = String(args.tabId || activeTabId || "").trim();
        if (!tabId || !browserTabs.has(tabId)) return { ok: false, error: "No such tab." };
        const win = browserTabs.get(tabId);
        if (win && !win.isDestroyed()) win.close();
        browserTabs.delete(tabId);
        if (activeTabId === tabId) activeTabId = browserTabs.keys().next().value || null;
        return { ok: true, closed: tabId, tabs: listTabsSummary(), artifact: tabsArtifact() };
      }
      case "browser_read":
        return browserRead(args);
      case "browser_click":
        return browserClick(args);
      case "browser_type":
        return browserType(args);
      case "browser_press_key":
        return browserPressKey(args);
      case "browser_screenshot":
        return browserScreenshot();
      case "browser_eval":
        return browserEval(args);
      case "browser_close":
        return browserCloseAll();
      case "playwright_launch":
        return playwrightLaunch(args);
      case "playwright_navigate":
        return playwrightNavigate(args);
      case "playwright_click":
        return playwrightClick(args);
      case "playwright_type":
        return playwrightType(args);
      case "playwright_read":
        return playwrightRead(args);
      case "playwright_screenshot":
        return playwrightScreenshot();
      case "playwright_close":
        return playwrightClose();
      default:
        return null;
    }
  }

  function cleanup() {
    browserCloseAll();
    void playwrightClose();
  }

  async function knowledgeInstructionsSnippet(maxChars = 8000) {
    await ensureKnowledgeDir();
    try {
      let list = [];
      try {
        list = JSON.parse(await fs.readFile(path.join(knowledgeDir, "index.json"), "utf8"));
      } catch {
        return "";
      }
      if (!Array.isArray(list) || !list.length) return "";
      const parts = [
        "# Learned knowledge packs (from project_learn)",
        "When answering, use project_recall(id) for full detail on a pack. Summaries:",
      ];
      for (const item of list.slice(0, 8)) {
        parts.push(`- ${item.id}: ${item.root} (${item.fileCount || "?"} files, ${item.learnedAt || ""})`);
        try {
          const pack = JSON.parse(await fs.readFile(path.join(knowledgeDir, `${item.id}.json`), "utf8"));
          parts.push(String(pack.brief || "").slice(0, 1200));
        } catch {
          /* skip */
        }
      }
      return parts.join("\n").slice(0, maxChars);
    } catch {
      return "";
    }
  }

  return {
    toolSpecs,
    handlerNames,
    execute,
    cleanup,
    workspaceRoot,
    knowledgeDir,
    knowledgeInstructionsSnippet,
    inspectBrowserAction,
  };
}

module.exports = { createAgentTools };
