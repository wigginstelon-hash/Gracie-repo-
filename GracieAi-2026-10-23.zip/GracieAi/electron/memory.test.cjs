const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createMemoryStore } = require('./memory.cjs');
async function setup(t) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'gracie-memory-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  return { dir, store: createMemoryStore(dir) };
}
test('saves chats, logs, and learned preferences across a restart', async t => {
  const { dir, store } = await setup(t);
  await store.record({ role: 'user', text: 'Remember that my favorite color is teal.', provider: 'ollama' });
  await store.record({ role: 'gracie', text: 'I will remember that.' });
  await store.record({ role: 'tool', text: 'Running screen capture', provider: 'openai' });
  const restarted = createMemoryStore(dir), snapshot = await restarted.snapshot();
  assert.equal(snapshot.count, 3); assert.equal(snapshot.memories.length, 1);
  const context = await restarted.context('What is my favorite color?');
  assert.match(context.memory, /teal/); assert.equal(context.history.length, 2);
});
test('concurrent writes preserve all entries in valid append-only records', async t => {
  const { store } = await setup(t);
  await Promise.all(Array.from({ length: 120 }, (_, i) => store.record({ role: 'system', text: `Log ${i}` })));
  const latest = await store.snapshot();
  assert.equal(latest.count, 120); assert.equal(latest.entries.length, 80); assert.equal(latest.hasOlder, true);
  const older = await store.snapshot(latest.entries.at(-1).id);
  assert.equal(older.entries.length, 40); assert.equal(older.hasOlder, false);
  assert.equal(new Set([...latest.entries, ...older.entries].map(e => e.id)).size, 120);
});
test('current corrections replace old attributes; forgotten memory is not recalled', async t => {
  const { dir, store } = await setup(t);
  await store.record({ role: 'user', text: 'My favorite color is red.' });
  await store.record({ role: 'user', text: 'My favorite color is blue.' });
  assert.equal((await store.snapshot()).memories.length, 1);
  assert.doesNotMatch(JSON.stringify(await store.context('color')), /color is red/);
  await store.forget((await store.snapshot()).memories[0].id);
  const restarted = createMemoryStore(dir);
  assert.doesNotMatch(JSON.stringify(await restarted.context('color')), /color is (blue|red)/);
  assert.equal((await restarted.snapshot()).count, 2); // Raw archive is retained.
});
test('edited memories survive a restart and do not reintroduce source wording', async t => {
  const { dir, store } = await setup(t);
  await store.record({ role: 'user', text: 'I prefer very long replies.' });
  const id = (await store.snapshot()).memories[0].id;
  await store.saveMemory({ id, text: 'I prefer concise replies.' });
  const context = await createMemoryStore(dir).context('replies');
  assert.match(context.memory, /concise/); assert.doesNotMatch(JSON.stringify(context), /very long/);
});
test('recalls relevant older messages without promoting assistant or tool claims', async t => {
  const { store } = await setup(t);
  await store.record({ role: 'user', text: 'The garden project needs cedar planters.' });
  await store.record({ role: 'gracie', text: 'The garden has imaginary diamonds.' });
  for (let i = 0; i < 8; i++) await store.record({ role: 'user', text: `Unrelated current subject ${i}` });
  const context = await store.context('garden project');
  assert.match(context.memory, /cedar/); assert.doesNotMatch(context.memory, /diamonds/);
});
test('recovers after a partial trailing record without discarding the file', async t => {
  const { dir, store } = await setup(t);
  await store.record({ role: 'user', text: 'First message' });
  await fs.appendFile(store.file, '{"partial":');
  const restarted = createMemoryStore(dir);
  await restarted.record({ role: 'user', text: 'After restart' });
  const state = await createMemoryStore(dir).snapshot();
  assert.equal(state.count, 2); assert.match(state.warning, /1 damaged/);
});
test('does not learn secrets or assistant statements as preferences', async t => {
  const { store } = await setup(t);
  await store.record({ role: 'user', text: 'Remember that my password is TEST-ONLY.' });
  await store.record({ role: 'gracie', text: 'My favorite color is gold.' });
  assert.equal((await store.snapshot()).memories.length, 0);
});

test('reviewed continuity persists, stays bounded, and respects edits and forgotten notes on reimport', async t => {
  const { dir, store } = await setup(t);
  const notes = ['The user wants an Odin-like phone utility with reliable startup.', 'The user calls the assistant Gracie, not themselves.'];
  assert.equal((await store.importNotes({ notes, source: 'Reviewed continuity' })).added, 2);
  assert.equal((await store.importNotes({ notes, source: 'Reviewed continuity' })).added, 0);
  const restarted = createMemoryStore(dir);
  const state = await restarted.snapshot();
  assert.equal(state.memories.length, 2);
  assert.match((await restarted.context('phone utility Odin')).memory, /Odin-like/);
  assert.ok((await restarted.context('phone utility Odin')).memory.length < 2200);
  const first = state.memories.find(m => m.text === notes[0]);
  await restarted.saveMemory({ id: first.id, text: 'The phone utility needs startup repair.' });
  assert.equal((await restarted.importNotes({ notes, source: 'Reviewed continuity' })).added, 0);
  await restarted.forget(first.id);
  assert.equal((await restarted.importNotes({ notes, source: 'Reviewed continuity' })).added, 0);
  await assert.rejects(restarted.importNotes({ notes: ['x'.repeat(251)] }), /250/);
});

test('fast context retrieves a compact relevant memory without replaying the long archive', async t => {
  const {store}=await setup(t);
  for(let i=0;i<6;i++) await store.saveMemory({text:'Phone coding preference '+i+' '+ 'x'.repeat(220)});
  for(let i=0;i<5;i++) await store.record({role:'user',text:'An older message '+i+' '+ 'y'.repeat(500)});
  const context=await store.context('phone coding',{fast:true});
  assert.ok(context.memory.length<=600); assert.equal(context.history.length,2);
  assert.ok(context.history.every(item=>item.content.length<=160));
  assert.equal(JSON.parse(context.memory.split('\n')[1]).userNotes.length,2);
  assert.equal((await store.context('What is 18 plus 24? Reply with the number only.', {fast:true})).memory,'');
});
