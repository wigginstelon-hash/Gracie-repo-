const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {createLocalTools}=require('./local-tools.cjs'),{createProjectAgent}=require('./project-agent.cjs');
const action=(action,extra={})=>({action,path:'',query:'',offset:0,content:'',expectedHash:null,script:'none',summary:'Check results',...extra});
test('helpers cannot replace project check scripts with a fake success command',async t=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-script-policy-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const original=JSON.stringify({scripts:{test:'node --test'}});await fs.writeFile(path.join(root,'package.json'),original);
 const tools=createLocalTools();await tools.setProjectRoot(root);tools.setEditPermission(true);tools.setCheckPermission(true);
 const queue=[{steps:['Inspect']},action('write',{path:'package.json',content:JSON.stringify({scripts:{test:'echo done'}})})];let snapshot;
 const agent=createProjectAgent({tools,maxSteps:1,complete:async()=>({content:JSON.stringify(queue.shift())})});
 await assert.rejects(agent.run({message:'Fix app',model:'local',onCheckpoint:async state=>{snapshot=state;}}),/action limit/);
 assert.equal(await fs.readFile(path.join(root,'package.json'),'utf8'),original);assert.match(snapshot.events[0].result.error,/cannot change/);
});
test('cloud helper request is rejected before reading local project data',async()=>{
 let touched=false;const agent=createProjectAgent({tools:{projectStatus:()=>{touched=true;return {};}}});
 await assert.rejects(agent.run({message:'Fix',model:'cloud:cloud'}),/require a local model/);assert.equal(touched,false);
});
test('writing identical file bytes does not rewrite the file',async t=>{
 const root=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-noop-edit-'));t.after(()=>fs.rm(root,{recursive:true,force:true}));
 const tools=createLocalTools();await tools.setProjectRoot(root);tools.setEditPermission(true);
 const saved=await tools.execute('project_write_file',{path:'app.js',content:'const x=1;',expectedHash:null},{enabled:true});
 const info=await fs.stat(path.join(root,'app.js'));
 const same=await tools.execute('project_write_file',{path:'app.js',content:'const x=1;',expectedHash:saved.hash},{enabled:true});
 assert.equal(same.ok,true);assert.equal(same.unchanged,true);assert.equal((await fs.stat(path.join(root,'app.js'))).mtimeMs,info.mtimeMs);
});
