const fs=require('node:fs');
const path=require('node:path');

function launchEnvironment(env,executable,{exists=fs.existsSync}={}){
  const result={...env,OLLAMA_LOAD_TIMEOUT:'30m',OLLAMA_MAX_LOADED_MODELS:'1',OLLAMA_NUM_PARALLEL:'1',OLLAMA_MAX_QUEUE:'2',OLLAMA_KEEP_ALIVE:'60s'};
  const pathKey=Object.keys(env).find(key=>key.toLowerCase()==='path')||'PATH';
  const own=path.win32.dirname(executable).toLowerCase();
  result[pathKey]=String(env[pathKey]||'').split(';').filter(entry=>{
    const folder=entry.replace(/^"|"$/g,'');
    const normalized=path.win32.normalize(folder).toLowerCase();
    return normalized===own||normalized.startsWith(own+'\\')||!exists(path.win32.join(folder,'ggml-base.dll'));
  }).join(';');
  return result;
}
function completionBudget(messages,maxTokens=2200,contextSize,cloud=false,maxContext=8192){
  const output=Math.max(64,Math.min(12000,Math.floor(Number(maxTokens)||2200)));
  if(cloud)return {temperature:0.15,num_predict:output};
  const prompt=Math.ceil(messages.reduce((size,message)=>size+String(message.content||'').length,0)/3)+messages.length*24+128;
  const needed=prompt+output+128;
  const limit=Math.max(4096,Math.min(16384,maxContext));
  const context=contextSize?Math.max(2048,Math.min(limit,contextSize)):[2048,4096,8192,12288,16384].find(size=>size>=needed&&size<=limit)||limit;
  const available=context-prompt-128;
  if(available<Math.min(output,512))throw Error('This build part has too much input for the current local context window. The saved part is incomplete; shorten its references or existing source before resuming.');
  return {temperature:0.15,num_ctx:context,num_batch:64,num_predict:Math.min(output,available)};
}
function inferenceError(text,status){
  if(/out.of.memory|unable to allocate|failed to allocate|requires more.*memory/i.test(text))return Error('Ollama ran out of memory while loading this model. Close other model sessions or memory-heavy apps, then retry. Your selected model has not changed.');
  if(/unknown model architecture|unsupported.*architecture/i.test(text))return Error('This installed model is incompatible with the current Ollama runtime. Update Ollama or choose a compatible model. No model was switched or downloaded.');
  if(/llama.server.*(?:terminated|startup failed)|runner.*(?:stopped|crashed|terminated)|GPU discovery.*(?:fail|time|error)|unexpected EOF/i.test(text)){
    const error=Error('The local model runner stopped before finishing. Choose a smaller model before retrying; automatic reload is disabled.');error.retryableInference=true;return error;
  }
  return Error(`Ollama returned ${status||'an error'}: ${String(text).slice(0,300)}`);
}
module.exports={launchEnvironment,completionBudget,inferenceError};
