const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { EventEmitter } = require('node:events');
const { PassThrough } = require('node:stream');
const { createLocalSpeech } = require('./local-speech.cjs');

async function fixture(t, run) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'gracie-speech-test-'));
  t.after(() => fs.rm(root, { recursive: true, force: true }));
  for (const file of ['models/speech/venv/Scripts/python.exe', 'models/speech/whisper-tiny.en/model.bin', 'models/speech/whisper-tiny.en/config.json', 'models/speech/whisper-tiny.en/vocabulary.txt']) {
    await fs.mkdir(path.dirname(path.join(root, file)), { recursive: true }); await fs.writeFile(path.join(root, file), 'fixture');
  }
  const calls = [];
  const voice = createLocalSpeech({ appRoot: root, dataDir: path.join(root, 'data'), platform: 'win32', spawnImpl(command, args, options) {
    const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough();
    child.kill = () => { setImmediate(() => child.emit('close', 1)); return true; };
    calls.push({ command, args, options, child });
    setImmediate(async () => { try { await run?.(calls.at(-1)); } catch (error) { child.emit('error', error); } });
    return child;
  } });
  return { voice, calls, root };
}

test('local speech rejects unsupported formats, invalid/oversized audio and oversized text before launching a process', async t => {
  const { voice, calls } = await fixture(t);
  await assert.rejects(voice.transcribe({ mimeType: 'text/html', audio: 'YQ==' }), /WebM/);
  await assert.rejects(voice.transcribe({ mimeType: 'audio/wav', audio: '../bad' }), /invalid/);
  await assert.rejects(voice.transcribe({ mimeType: 'audio/wav', audio: 'A'.repeat(12 * 1024 * 1024 + 1) }), /large/);
  await assert.rejects(voice.synthesize({ text: 'a'.repeat(4001) }), /4,000/);
  assert.equal(calls.length, 0);
});

test('transcription uses local files, offline workers and cleans its temporary recording', async t => {
  const { voice, calls, root } = await fixture(t, async ({ args, child }) => {
    assert.equal((await fs.readFile(args[2])).toString(), 'recorded audio');
    child.stdout.end(JSON.stringify({ text: '  verification forty two  ' })); child.emit('close', 0);
  });
  assert.deepEqual(await voice.transcribe({ mimeType: 'audio/webm;codecs=opus', audio: Buffer.from('recorded audio').toString('base64') }), { text: 'verification forty two' });
  assert.equal(calls[0].options.env.HF_HUB_OFFLINE, '1');
  assert.equal(calls[0].options.shell, undefined);
  assert.equal(calls[0].options.windowsHide, true);
  assert.deepEqual(await fs.readdir(path.join(root, 'data/speech/tmp')), []);
});

test('speech sends reply text through a UTF-8 file rather than executable arguments', async t => {
  const text = 'Literal $(command) <speak> words';
  const { voice, calls, root } = await fixture(t, async ({ args, child }) => {
    assert.equal(await fs.readFile(args[1], 'utf8'), text);
    await fs.writeFile(args[2], 'wave fixture'); child.emit('close', 0);
  });
  const result = await voice.synthesize({ text });
  assert.equal(result.mimeType, 'audio/wav');
  assert.equal(Buffer.from(result.audio, 'base64').toString(), 'wave fixture');
  assert.ok(!calls[0].args.some(argument => argument.includes(text)));
  assert.deepEqual(await fs.readdir(path.join(root, 'data/speech/tmp')), []);
});

test('speech cancellation kills only its own worker, clears ownership and removes recordings', async t => {
  let started;
  const ready = new Promise(resolve => { started = resolve; });
  const { voice, calls, root } = await fixture(t, () => started());
  const pending = voice.transcribe({ mimeType: 'audio/wav', audio: 'YQ==' });
  const rejected = assert.rejects(pending, /stopped/);
  await ready;
  await assert.rejects(voice.synthesize({ text: 'another request' }), /busy/);
  voice.cancel(); await rejected;
  assert.equal(calls.length, 1);
  assert.deepEqual(await fs.readdir(path.join(root, 'data/speech/tmp')), []);
});

test('speech failures do not leak private worker output and still remove temporary audio', async t => {
  const { voice, root } = await fixture(t, ({ child }) => { child.stderr.end('private path and audio details'); child.emit('close', 2); });
  await assert.rejects(voice.transcribe({ mimeType: 'audio/wav', audio: 'YQ==' }), error => !error.message.includes('private') && /could not process/.test(error.message));
  assert.deepEqual(await fs.readdir(path.join(root, 'data/speech/tmp')), []);
});
