const fs = require('node:fs/promises');
const path = require('node:path');
const { spawn, execFile } = require('node:child_process');
const { promisify } = require('node:util');
const catalog = [
  ['claude','Claude Code'], ['codex','Codex CLI'], ['openclaw','OpenClaw'],
  ['opencode','OpenCode'], ['hermes','Hermes Agent'], ['hermes-desktop','Hermes Desktop'],
  ['droid','Droid'], ['pi','Pi'], ['cline','Cline'], ['copilot','Copilot CLI'],
  ['omp','Oh My Pi'], ['dsh','DeepSeek Harness'], ['qwen','Qwen Code'], ['terminal','Terminal'],
].map(([id,name]) => ({id,name}));
const quote = value => "'" + String(value).replace(/'/g,"''") + "'";
function launchScript(executable,id,model) {
  if (!catalog.some(app=>app.id===id)) throw Error('Unknown Ollama application.');
  if (typeof model !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_.:/-]{0,255}$/.test(model)) throw Error('Choose a valid Ollama model.');
  const args = id==='terminal' ? ['run',model] : ['launch',id,'--model',model];
  return "$ErrorActionPreference = 'Stop'\n& " + [executable,...args].map(quote).join(' ') + "\nif ($LASTEXITCODE -ne 0) { Write-Host ('Ollama exited with code ' + $LASTEXITCODE) -ForegroundColor Red }";
}
function createOllamaApps({status,env=process.env,platform=process.platform,run=promisify(execFile),start=spawn,access=fs.access}={}) {
  async function executable() {
    const candidates=[path.join(env.LOCALAPPDATA||'','Programs','Ollama','ollama.exe'), ...(env.PATH||env.Path||'').split(path.delimiter).filter(Boolean).map(dir=>path.join(dir,'ollama.exe'))];
    for(const candidate of candidates) { if(!path.isAbsolute(candidate))continue;try { await access(candidate); return candidate; } catch {} }
    throw Error('Ollama CLI was not found. Install Ollama or add its folder to PATH, then restart Gracie.');
  }
  async function list() {
    if(platform!=='win32')throw Error('This app launcher currently supports Windows.');
    const exe=await executable();
    const {stdout}=await run(exe,['launch','--help'],{timeout:10000,windowsHide:true,maxBuffer:128*1024});
    const supported=new Set([...stdout.matchAll(/^\s{2}([a-z][a-z0-9-]*)\s{2,}/gm)].map(match=>match[1]));
    return catalog.map(app=>({...app,supported:app.id==='terminal'||supported.has(app.id)}));
  }
  async function launch({id,model,folder}) {
    if(!catalog.some(app=>app.id===id))throw Error('Unknown Ollama application.');
    const apps=await list();
    if(!apps.find(app=>app.id===id)?.supported)throw Error('Your Ollama version does not support this app. Update Ollama and refresh.');
    const state=await status();
    if(!state.available)throw Error(state.message||'Ollama is offline.');
    if(!state.models.includes(model))throw Error('Choose a model listed by your Ollama server.');
    const exe=await executable();
    const script=launchScript(exe,id,model);
    const powershell=path.join(env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    await new Promise((resolve,reject)=>{
      const child=start(powershell,['-NoLogo','-NoProfile','-NoExit','-EncodedCommand',Buffer.from(script,'utf16le').toString('base64')],{cwd:folder,env:{...env,OLLAMA_HOST:state.url||env.OLLAMA_HOST||'http://127.0.0.1:11434'},detached:true,stdio:'ignore',windowsHide:false});
      child.once('error',reject);
      child.once('spawn',()=>{child.unref();resolve();});
    });
    return {opened:true,name:catalog.find(app=>app.id===id).name,model};
  }
  return {list,launch};
}
module.exports={createOllamaApps,launchScript};
