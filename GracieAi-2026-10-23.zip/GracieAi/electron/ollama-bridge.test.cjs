const test = require('node:test');
const assert = require('node:assert/strict');
const { createOllamaBridge } = require('./ollama-bridge.cjs');

test('voice bridge runs the selected local model and returns its actual answer without computer tools', async () => {
  let request;
  const client = {
    status: async () => ({ available: true, models: ['small', 'other'], defaultModel: 'small' }),
    chat: async input => { request = input; return { model: input.model, content: '37', truncated: false }; },
  };
  const bridge = createOllamaBridge({ client });
  assert.deepEqual(await bridge.run({ message: 'What is 18 + 19?', model: 'other' }), { ok: true, model: 'other', localModelAnswer: '37', truncated: false });
  assert.equal(request.message, 'What is 18 + 19?');
  assert.equal(request.useLocalTools, false);
  assert.equal(request.fastMode, true);
  assert.equal((await bridge.run({ message: 'Hello' })).model, 'small');
});

test('voice bridge rejects offline, missing, cloud, and oversized requests before inference', async () => {
  let calls = 0;
  const state = { available: true, models: ['local', 'remote:cloud'], defaultModel: 'local' };
  const client = { status: async () => state, chat: async () => { calls++; } };
  const bridge = createOllamaBridge({ client });
  await assert.rejects(bridge.run({ message: '' }), /characters/);
  await assert.rejects(bridge.run({ message: 'x'.repeat(16001) }), /characters/);
  await assert.rejects(bridge.run({ message: 'Hello', model: 'missing' }), /installed/);
  await assert.rejects(bridge.run({ message: 'Hello', model: 'remote:cloud' }), /local weights/);
  state.available = false;
  await assert.rejects(bridge.run({ message: 'Hello' }), /offline/);
  assert.equal(calls, 0);
});

test('voice bridge cancellation stops inference and releases its busy state after failures', async () => {
  let started;
  const began = new Promise(resolve => { started = resolve; });
  const client = {
    status: async () => ({ available: true, models: ['local'], defaultModel: 'local' }),
    chat: async ({ signal }) => { started(); await new Promise((_resolve, reject) => signal.addEventListener('abort', () => reject(Error('Stopped')), { once: true })); },
  };
  const bridge = createOllamaBridge({ client });
  const pending = bridge.run({ message: 'Hello', taskId: 'first' });
  await began;
  await assert.rejects(bridge.run({ message: 'Another' }), /already running/);
  bridge.stop('other');
  bridge.stop('first');
  await assert.rejects(pending, /Stopped/);
  client.chat = async () => ({ model: 'local', content: 'Recovered' });
  assert.equal((await bridge.run({ message: 'Retry' })).localModelAnswer, 'Recovered');
});

test('cancellation during connection checks never starts a model request', async () => {
  let release, called = false;
  const client = { status: () => new Promise(resolve => { release = resolve; }), chat: async () => { called = true; } };
  const bridge = createOllamaBridge({ client });
  const pending = bridge.run({ message: 'Hello' });
  bridge.stop();
  release({ available: true, models: ['local'], defaultModel: 'local' });
  await assert.rejects(pending, /abort/i);
  assert.equal(called, false);
});
