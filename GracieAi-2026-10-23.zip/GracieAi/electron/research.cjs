const dns = require('node:dns/promises');
const https = require('node:https');
const http = require('node:http');
const net = require('node:net');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { convert } = require('html-to-text');
function publicAddress(ip) {
  if(net.isIP(ip)===4) {
    const [a,b]=ip.split('.').map(Number);
    return !(a===0||a===10||a===127||a>=224||a===169&&b===254||a===172&&b>=16&&b<=31||a===192&&b===168||a===100&&b>=64&&b<=127||a===198&&(b===18||b===19));
  }
  if(net.isIP(ip)===6) { const lower=ip.toLowerCase(); return !(/^(::|fc|fd|fe[89ab]|ff)/.test(lower)); }
  return false;
}
async function checkedUrl(value, lookup = dns.lookup) {
  const url=new URL(value);
  if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.port&&!['80','443'].includes(url.port))throw new Error('Use a public HTTP or HTTPS reference link.');
  const host=url.hostname.replace(/^\[|\]$/g,'');
  if(host==='localhost'||host.endsWith('.local'))throw new Error('Private-network links are not fetched.');
  const addresses=net.isIP(host)?[{address:host,family:net.isIP(host)}]:await lookup(host,{all:true});
  if(!addresses.length||addresses.some(item=>!publicAddress(item.address)))throw new Error('Private-network links are not fetched.');
  return {url,address:addresses[0]};
}
async function fetchPublic(value, signal, redirects=0) {
  if(redirects>4)throw new Error('This reference redirected too many times.');
  const {url,address}=await checkedUrl(value);
  return new Promise((resolve,reject)=>{
    const req=(url.protocol==='https:'?https:http).get(url,{signal:AbortSignal.any([AbortSignal.timeout(20000),...(signal?[signal]:[])]),headers:{'User-Agent':'GracieAI Reference Reader/1.0','Accept':'text/html,text/plain,application/json'},lookup:(_host,options,callback)=>callback(null,options?.all?[address]:address.address,address.family)},res=>{
      if([301,302,303,307,308].includes(res.statusCode)&&res.headers.location){res.resume();resolve(fetchPublic(new URL(res.headers.location,url).href,signal,redirects+1));return;}
      if(res.statusCode<200||res.statusCode>=300){res.resume();reject(new Error(`Reference returned HTTP ${res.statusCode}.`));return;}
      if(!/text\/|application\/(json|xml|xhtml)/i.test(res.headers['content-type']||'')){res.resume();reject(new Error('This link is not a readable web page. Attach documents locally instead.'));return;}
      let bytes=0;const chunks=[];
      res.on('data',chunk=>{bytes+=chunk.length;if(bytes>1500000){req.destroy(new Error('This reference page is too large.'));return;}chunks.push(chunk);});
      res.on('end',()=>{try{const raw=Buffer.concat(chunks).toString('utf8');resolve({url:url.href,title:raw.match(/<title[^>]*>([^<]*)/i)?.[1]||url.hostname,html:raw,text:convert(raw,{wordwrap:false,selectors:[{selector:'script',format:'skip'},{selector:'style',format:'skip'},{selector:'nav',format:'skip'},{selector:'a',options:{ignoreHref:true}},{selector:'img',format:'skip'}]}).slice(0,20000)});}catch(e){reject(e);}});
      res.on('error',reject);
    });req.on('error',reject);
  });
}
function parseSearchRss(xml) {
  const field=(item,name)=>convert((item.match(new RegExp(`<${name}>([\\s\\S]*?)</${name}>`,'i'))?.[1]||'').replace(/<!\[CDATA\[|\]\]>/g,''),{wordwrap:false}).trim();
  return (String(xml).match(/<item>[\s\S]*?<\/item>/gi)||[]).slice(0,3).map(item=>({title:field(item,'title'),url:field(item,'link'),text:field(item,'description')})).filter(item=>item.url);
}
function referenceExcerpt(text,query,budget) {
  text=String(text||'');if(text.length<=budget)return text;
  const terms=[...new Set(String(query).toLowerCase().match(/[a-z0-9]{4,}/g)||[])];
  const chunks=(text.match(/[\s\S]{1,600}/g)||[]).map((content,index)=>({content,index,score:terms.filter(term=>content.toLowerCase().includes(term)).length}));
  return chunks.sort((a,b)=>b.score-a.score||a.index-b.index).slice(0,Math.ceil(budget/600)).sort((a,b)=>a.index-b.index).map(chunk=>chunk.content).join('\n').slice(0,budget);
}
async function publicSearch(query,signal) {
  const errors=[];
  const browserTopic=query.match(/\b(?:localStorage|sessionStorage|IndexedDB|Web Storage(?: API)?|WebSocket|CSS grid|CSS flexbox|ARIA)\b/i)?.[0];
  if(browserTopic)try{
    const page=await fetchPublic(`https://developer.mozilla.org/api/v1/search?q=${encodeURIComponent(browserTopic)}`,signal);
    const data=JSON.parse(page.html);const results=relevantResults((data.documents||[]).slice(0,8).map(item=>({title:String(item.title),url:new URL(item.mdn_url,'https://developer.mozilla.org').href,text:String(item.summary||'')})),browserTopic);
    if(results.length)return results;
  }catch(error){if(signal?.aborted)throw error;errors.push(error.message);}
  try{
    const page=await fetchPublic(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query.slice(0,600))}`,signal);
    const results=relevantResults(parsePublicSearchHtml(page.html),query);if(results.length)return results;
  }catch(error){if(signal?.aborted)throw error;errors.push(error.message);}
  try{
    const page=await fetchPublic(`https://www.bing.com/search?format=rss&q=${encodeURIComponent(query.slice(0,600))}`,signal);
    const results=relevantResults(parseSearchRss(page.html),query);if(results.length)return results;
  }catch(error){if(signal?.aborted)throw error;errors.push(error.message);}
  throw new Error('Public search returned no relevant readable results. Add a direct reference link or narrow the public topic.'+(errors.length?' '+errors[0]:''));
}
function parsePublicSearchHtml(html) {
  const results=[];const pattern=/<a\b([^>]*\bclass=["'][^"']*\bresult__a\b[^"']*["'][^>]*)>([\s\S]*?)<\/a>/gi;
  for(const match of String(html).matchAll(pattern)){
    try{
      const href=match[1].match(/\bhref=["']([^"']+)["']/i)?.[1];if(!href)continue;
      let url=new URL(convert(href,{wordwrap:false}),'https://duckduckgo.com');if(url.hostname.endsWith('duckduckgo.com')&&url.searchParams.get('uddg'))url=new URL(url.searchParams.get('uddg'));
      if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.hostname.endsWith('duckduckgo.com'))continue;
      const following=String(html).slice(match.index+match[0].length,match.index+match[0].length+2500);
      const snippet=following.match(/class=["'][^"']*result__snippet[^"']*["'][^>]*>([\s\S]*?)<\/(?:a|div)>/i)?.[1]||'';
      results.push({title:convert(match[2],{wordwrap:false}),url:url.href,text:convert(snippet,{wordwrap:false})});if(results.length===8)break;
    }catch{}
  }
  return results;
}
function relevantResults(results,query) {
  const stop=new Set('the and for with from that this how what use using build create make app application official documentation docs implementation examples reference limitations alternatives edge cases javascript web api specification latest current'.split(' '));
  let terms=[...new Set(String(query).toLowerCase().match(/[a-z0-9]{3,}/g)||[])].filter(term=>!stop.has(term));
  if(!terms.length)terms=[...new Set(String(query).toLowerCase().match(/[a-z0-9]{3,}/g)||[])];
  return results.filter(item=>{const text=`${item.title} ${item.url} ${item.text}`.toLowerCase();return terms.filter(term=>text.includes(term)).length>=Math.min(2,terms.length);}).slice(0,3);
}
function createResearch({ env=process.env, fetchImpl=globalThis.fetch, readPage=fetchPublic, fallbackSearch=publicSearch, directory, now=Date.now }={}) {
  async function search(query,signal) {
    if(env.GRACIE_LOCAL_ONLY==='1')throw Error('Web research is disabled in Local assistant mode.');
    if(!env.EXA_API_KEY)return fallbackSearch(query,signal);
    try {
      const response=await fetchImpl('https://api.exa.ai/search',{method:'POST',headers:{'Content-Type':'application/json','x-api-key':env.EXA_API_KEY},body:JSON.stringify({query:query.slice(0,600),type:'auto',numResults:3,contents:{text:{maxCharacters:1800}}}),signal:AbortSignal.any([AbortSignal.timeout(20000),...(signal?[signal]:[])])});
      if(!response.ok)throw new Error(`Configured web search returned HTTP ${response.status}.`);
      const data=await response.json();const results=relevantResults((Array.isArray(data.results)?data.results:[]).map(r=>({title:String(r.title||r.url),url:String(r.url||''),text:String(r.text||r.summary||'')})),query);if(!results.length)throw Error('Configured search returned off-topic results.');return results;
    } catch(error) {
      if(signal?.aborted)throw error;
      try{return await fallbackSearch(query,signal);}catch(fallbackError){throw new Error(`${error.message} ${fallbackError.message}`);}
    }
  }
  async function collect({query='',queries:plannedQueries,links=[],mode='off',signal,onProgress=()=>{}}) {
    signal?.throwIfAborted();
    if(env.GRACIE_LOCAL_ONLY==='1'){if(mode!=='off'||links.length)throw Error('Web research and reference links are disabled in Local assistant mode. Attach local documents instead.');return {sources:[],warnings:[],cached:false};}
    const results=[],warnings=[];
    if(!Array.isArray(links)||links.length>4)throw new Error('Add at most four reference links.');
    if(!['off','search','deep'].includes(mode))throw Error('Resolve automatic research to off, search, or deep before collecting sources.');
    const queries=mode==='off'?[]:Array.isArray(plannedQueries)&&plannedQueries.length?plannedQueries.filter(value=>typeof value==='string'&&value.trim()).slice(0,mode==='deep'?3:1).map(value=>value.slice(0,600)):mode==='deep'?[query,`${query} official documentation implementation`,`${query} limitations alternatives`]:[query];
    const key=crypto.createHash('sha256').update(JSON.stringify({version:2,mode,queries,links})).digest('hex');
    const cacheFile=directory?path.join(directory,key+'.json'):null;
    const ttl=/\b(?:latest|current|today|news|weather|prices?)\b/i.test(queries.join(' '))?900000:21600000;
    if(cacheFile)try{const cached=JSON.parse(await fs.readFile(cacheFile,'utf8'));if(now()-cached.savedAt>=0&&now()-cached.savedAt<ttl&&Array.isArray(cached.sources)&&cached.sources.length){onProgress('Reusing recently checked public references…');return {sources:cached.sources,warnings:[],cached:true};}}catch{}
    for(const link of links){signal?.throwIfAborted();onProgress('Reading your reference link…');try{results.push(await readPage(link,signal));}catch(e){if(signal?.aborted)throw e;warnings.push(`${link}: ${e.message}`);}}
    if(mode!=='off') {
      for(let i=0;i<queries.length;i++){signal?.throwIfAborted();onProgress(`Searching references ${i+1}/${queries.length}…`);try{results.push(...await search(queries[i],signal));}catch(e){if(signal?.aborted)throw e;warnings.push(e.message);}}
      if(mode==='deep'){
        const unique=[...new Map(results.filter(item=>item.url).map(item=>[item.url,item])).values()];
        const primary=item=>{try{const host=new URL(item.url).hostname;return /^(?:docs|developer|developers)\.|\.(?:gov|edu)$|(?:^|\.)(?:w3\.org|rfc-editor\.org|github\.com)$/i.test(host)?1:0;}catch{return 0;}};
        unique.sort((a,b)=>primary(b)-primary(a));
        for(let i=0;i<Math.min(3,unique.length);i+=2){
          signal?.throwIfAborted();onProgress('Reading supporting sources…');
          const batch=unique.slice(i,Math.min(i+2,3));const loaded=await Promise.allSettled(batch.map(source=>readPage(source.url,signal)));
          loaded.forEach((result,index)=>{if(result.status==='fulfilled')batch[index].text=result.value.text;else warnings.push(`Could not read ${batch[index].url}: ${result.reason.message}`);});signal?.throwIfAborted();
        }
        results.splice(0,results.length,...unique);
      }
    }
    const seen=new Set(),sources=[];
    for(const item of results){let url;try{url=new URL(item.url);if(!['https:','http:'].includes(url.protocol)||url.username||url.password)continue;}catch{continue;}if(seen.has(url.href))continue;seen.add(url.href);sources.push({id:sources.length+1,title:item.title.slice(0,180),url:url.href,excerpt:referenceExcerpt(item.text,query,mode==='deep'?1800:1200)});if(sources.length===6)break;}
    if((mode!=='off'||links.length)&&!sources.length)throw new Error(warnings[0]||'No usable references were returned. Try another query or link.');
    if(cacheFile&&sources.length&&!warnings.length)try{await fs.mkdir(directory,{recursive:true});const temporary=cacheFile+'.'+crypto.randomUUID()+'.tmp';await fs.writeFile(temporary,JSON.stringify({savedAt:now(),sources}),{mode:0o600});await fs.rename(temporary,cacheFile);}catch{warnings.push('References were used, but their local cache could not be saved.');}
    return {sources,warnings,cached:false};
  }
  return {collect,search};
}
module.exports={createResearch,checkedUrl,publicAddress,fetchPublic,parseSearchRss,parsePublicSearchHtml,relevantResults};
