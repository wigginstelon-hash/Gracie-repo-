const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createModelLibrary, cloudTag, validTag } = require('./model-library.cjs');
const { createOllamaClient } = require('./ollama.cjs');
const reply = data => new Response(JSON.stringify(data));
const tick = () => new Promise(resolve => setImmediate(resolve));

test('cloud catalog maps upstream names to explicit cloud routes and caches results', async () => {
  let requests = 0;
  const library = createModelLibrary({ fetchImpl: async url => {
    requests++; assert.equal(url, 'https://ollama.com/api/tags');
    return reply({ models: [{ name: 'gemma4:31b' }, { name: 'kimi-k3' }, { name: 'bad?tag' }] });
  } });
  const models = await library.cloudModels();
  assert.deepEqual(models, [{ name: 'gemma4:31b', tag: 'gemma4:31b-cloud' }, { name: 'kimi-k3', tag: 'kimi-k3:cloud' }]);
  assert.deepEqual(await library.cloudModels(), models); assert.equal(requests, 1);
  assert.equal(cloudTag('gpt-oss:20b'), 'gpt-oss:20b-cloud');
});

test('catalog failures remain retryable and malformed results are rejected', async () => {
  let count = 0;
  const library = createModelLibrary({ fetchImpl: async () => ++count === 1 ? new Response('', { status: 503 }) : reply({ models: [] }) });
  await assert.rejects(library.cloudModels(), /catalog/);
  assert.deepEqual(await library.cloudModels(), []);
  const invalid = createModelLibrary({ fetchImpl: async () => reply({}) });
  await assert.rejects(invalid.cloudModels(), /unreadable/);
});

test('pulls require valid local tags; creation never starts a download', () => {
  let calls = 0;
  const library = createModelLibrary({ fetchImpl: async () => { calls++; return reply({}); } });
  for (const value of ['../secret', 'https://host/model', 'model;command', '', 'gemma4:cloud', 'gemma4:31b-cloud']) {
    assert.throws(() => library.startPull(value), /exact local model tag/);
  }
  assert.equal(validTag('huihui_ai/Qwen3.8-abliterated:latest'), true);
  assert.equal(library.pullStatus(), null); assert.equal(calls, 0);
});

test('download reads split progress lines, blocks simultaneous pulls and confirms success', async () => {
  let push;
  let request;
  const body = new ReadableStream({ start(c) { push = c; } });
  const library = createModelLibrary({ fetchImpl: async (url, options) => { request = { url, options }; return new Response(body); } });
  assert.equal(library.startPull('qwen3:4b').active, true);
  assert.throws(() => library.startPull('other:1b'), /already running/);
  await tick();
  push.enqueue(new TextEncoder().encode('{"status":"pulling layer","total":100,"comp'));
  push.enqueue(new TextEncoder().encode('leted":25}\n'));
  await tick();
  assert.equal(library.pullStatus().completed, 25);
  push.enqueue(new TextEncoder().encode('{"status":"pulling layer","digest":"second-layer","total":50}\n'));
  await tick();
  assert.equal(library.pullStatus().completed, 0); assert.equal(library.pullStatus().total, 50);
  push.enqueue(new TextEncoder().encode('{"status":"success"}')); push.close();
  await tick();
  assert.equal(library.pullStatus().done, true); assert.equal(library.pullStatus().active, false);
  assert.equal(request.url.href, 'http://127.0.0.1:11434/api/pull');
  assert.deepEqual(JSON.parse(request.options.body), { model: 'qwen3:4b', stream: true });
});

test('download reports server errors, incomplete streams, network failures and cancellation', async () => {
  for (const response of [new Response('{"error":"model not found"}\n'), new Response('{"status":"pulling"}\n'), new Response('', { status: 500 })]) {
    const library = createModelLibrary({ fetchImpl: async () => response });
    library.startPull('missing:1b'); await tick();
    assert.equal(library.pullStatus().active, false); assert.ok(library.pullStatus().error); assert.equal(library.pullStatus().done, false);
  }
  const network = createModelLibrary({ fetchImpl: async () => { throw new TypeError('offline'); } });
  network.startPull('qwen3:4b'); await tick(); assert.match(network.pullStatus().error, /offline/);
  const cancelled = createModelLibrary({ fetchImpl: async (_url, { signal }) => new Promise((_resolve, reject) => signal.addEventListener('abort', () => reject(new Error('aborted')))) });
  cancelled.startPull('qwen3:4b'); cancelled.cancelPull(); await tick();
  assert.equal(cancelled.pullStatus().active, false); assert.match(cancelled.pullStatus().error, /stopped/);
});

test('cloud chat uses signed-in local Ollama with explicit cloud tag and excludes saved context by default', async () => {
  let sent;
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, options) => {
    if (String(url) === 'https://ollama.com/api/tags') return reply({ models: [{ name: 'gemma4:31b' }] });
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'local:latest' }] });
    assert.equal(url.origin, 'http://127.0.0.1:11434');
    sent = JSON.parse(options.body); return reply({ message: { content: 'Cloud reply' } });
  } });
  const input = { model: 'gemma4:31b-cloud', message: 'Hello', memory: 'Private saved memory', history: [{ role: 'user', content: 'Private earlier chat' }] };
  assert.equal((await client.chat(input)).model, 'gemma4:31b-cloud');
  assert.equal(sent.model, 'gemma4:31b-cloud'); assert.equal(sent.messages.length, 2);
  assert.doesNotMatch(JSON.stringify(sent), /Private/); assert.equal(sent.keep_alive, undefined);
  await client.chat({ ...input, includeSavedContext: true });
  assert.match(JSON.stringify(sent), /Private saved memory/); assert.equal(sent.messages.length, 3);
  await assert.rejects(client.chat({ ...input, model: 'fake:cloud' }), /not installed/);
  await assert.rejects(client.chat({ ...input, model: 'gemma4:31b' }), /not installed/);
});

test('registered cloud models keep saved context private and authentication errors are surfaced', async () => {
  let sent;
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'custom:latest', remote_host: 'https://ollama.com' }] });
    sent = JSON.parse(options.body); return new Response('Sign in to Ollama', { status: 401 });
  } });
  await assert.rejects(client.chat({ model: 'custom:latest', message: 'Hello', memory: 'SECRET' }), /401.*Sign in/);
  assert.doesNotMatch(JSON.stringify(sent), /SECRET/);
});

test('cloud service failures give actionable errors without exposing sign-in response details', async () => {
  for (const [status, pattern] of [[401, /Sign in/], [403, /disabled/], [429, /usage limit/], [502, /connection/]]) {
    const client = createOllamaClient({ env: {}, fetchImpl: async url => {
      if (url.pathname === '/api/tags') return reply({ models: [{ name: 'gemma4:cloud' }] });
      return new Response('private-signin-response', { status });
    } });
    await assert.rejects(client.chat({ message: 'Hello', model: 'gemma4:cloud' }), error => pattern.test(error.message) && !error.message.includes('private-signin-response'));
  }
});
