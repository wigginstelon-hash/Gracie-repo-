function validateChecks(checks){
  if(!Array.isArray(checks)||!checks.length||checks.length>24)throw Error('Include 1–24 meaningful ordered app checks.');
  checks.forEach((check,index)=>{
    const fail=detail=>{throw Error(`Check ${index+1}: ${detail}. Received ${JSON.stringify(check).slice(0,700)}`);};
    if(!check||typeof check!=='object')fail('expected a check object');
    if(!['click','input','none'].includes(check.event))fail('event must be click, input or none');
    if(!['textContent','value','checked'].includes(check.property))fail('property must be textContent, value or checked');
    for(const key of ['selector','expectSelector','includes'])if(typeof check[key]!=='string'||!check[key].trim()||check[key].length>500)fail(key+' must be a nonempty string of at most 500 characters');
    if(check.event==='input'&&typeof check.value!=='string'||check.value!==undefined&&typeof check.value!=='string')fail('value must be an explicit quoted string; typing "12" requires value:"12", separate from includes');
    if(check.event!=='input'&&check.value)fail('value is only applied by input events; type into an editable control in a separate step before clicking');
  });
  return checks;
}
module.exports={validateChecks};
