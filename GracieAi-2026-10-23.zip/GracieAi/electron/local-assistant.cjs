const {validTag,isCloudTag}=require('./model-library.cjs');
const {getProfile}=require('./personalities.cjs');

async function setupLocalAssistant({baseModel='qwen3.5:4b',name='gracie-assistant:latest',url='http://127.0.0.1:11434',fetchImpl=globalThis.fetch,signal}={}) {
  const address=new URL(url);
  if(!['http:','https:'].includes(address.protocol)||!['localhost','127.0.0.1','[::1]'].includes(address.hostname)||address.username||address.password)throw Error('Local setup must use Ollama on this computer.');
  if(!validTag(name)||!validTag(baseModel)||isCloudTag(name)||isCloudTag(baseModel)||name===baseModel)throw Error('Choose separate valid local model names.');
  async function request(route,body){
    const response=await fetchImpl(new URL(route,address.origin),{method:body?'POST':'GET',headers:{'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.any([AbortSignal.timeout(60000),...(signal?[signal]:[])])});
    const data=await response.json();if(!response.ok||data.error)throw Error(data.error||'Ollama setup failed: '+response.status);return data;
  }
  signal?.throwIfAborted();
  const tags=await request('/api/tags');
  const models=Array.isArray(tags.models)?tags.models:[];
  const existing=models.find(model=>model.name===name);
  if(existing){if(existing.remote_host||existing.remote_model)throw Error('The Gracie profile name belongs to a cloud model. Choose another name.');return {created:false,name,existing:true};}
  const base=models.find(model=>model.name===baseModel);
  if(!base||base.remote_host||base.remote_model)throw Error('Install the chosen local base model in Ollama before creating Gracie. No model was downloaded.');
  if(!(base.size>0&&base.size<7*1024**3))throw Error('Choose a compact base model under 7 GiB for this Gracie profile.');
  signal?.throwIfAborted();
  await request('/api/create',{model:name,from:baseModel,system:getProfile().prompt,parameters:{num_ctx:4096,num_batch:64,temperature:0.6,repeat_penalty:1},stream:false});
  const installed=await request('/api/tags');
  if(!installed.models?.some(model=>model.name===name&&!model.remote_host&&!model.remote_model))throw Error('Ollama did not confirm the local Gracie profile.');
  return {created:true,name,baseModel};
}
module.exports={setupLocalAssistant};
