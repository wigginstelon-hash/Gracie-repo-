function allowMedia({ contents, mainContents, permission, details, trustedUrl, localOnly }) {
  if (contents !== mainContents || permission !== 'media' || details?.isMainFrame !== true || details.requestingUrl !== trustedUrl) return false;
  return !localOnly || (details.mediaTypes?.length > 0 && details.mediaTypes.every(type => type === 'audio'));
}
module.exports = { allowMedia };
