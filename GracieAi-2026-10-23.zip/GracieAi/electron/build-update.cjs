function updatedBuild(saved,message){
  const note=String(message||'').trim();
  if(!note)throw Error('Type an update for this build.');
  if(!saved||saved.request?.workMode!=='build')throw Error('No app build is available to update.');
  const combined=String(saved.request.message||'')+'\n\nUSER UPDATE (apply to this same app; retain earlier requirements unless changed below):\n'+note;
  if(combined.length>200000)throw Error('The build request and update exceed 200,000 characters. Shorten the update; your draft is kept.');
  const next=structuredClone(saved);
  next.request.message=combined;next.completed=false;next.partial='Build update saved. Replanning with your new instructions.';delete next.failure;
  if(next.checkpoint?.kind==='build'){
    const job=next.checkpoint,stages=job.staged||{};
    job.previousDesign=stages.plan||job.previousDesign;
    job.previousModules={...job.previousModules,...Object.fromEntries(Object.entries(stages).filter(([key,value])=>key.startsWith('module_')&&typeof value?.javascript==='string').map(([key,value])=>[key.slice(7),value.javascript]))};
    job.previous=job.draft||job.previous;
    job.previousRequest=job.request?.message||saved.request.message;
    job.request={...job.request,...next.request};
    job.staged=null;job.draft=null;job.stage='generate';job.attempt=0;job.strategy='staged';job.error='';
    for(const key of ['checkFailure','checksToPreserve','featureFailures','missingOutputRepair','invalidTargetChecks','validation'])delete job[key];
  }
  return next;
}
module.exports={updatedBuild};
