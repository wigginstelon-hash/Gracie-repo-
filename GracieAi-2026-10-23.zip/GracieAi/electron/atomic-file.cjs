const fs=require('node:fs/promises');
async function renameWithRetry(from,to,{rename=fs.rename,wait=ms=>new Promise(resolve=>setTimeout(resolve,ms))}={}){
  for(let attempt=0;;attempt++){
    try{return await rename(from,to);}catch(error){if(!['EPERM','EACCES','EBUSY'].includes(error.code)||attempt>=5)throw error;await wait(40*2**attempt);}
  }
}
module.exports={renameWithRetry};
