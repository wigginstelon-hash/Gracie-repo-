param([ValidateSet('applications','services','tasks','startup','enrollment','remoteSettings','ports')][string]$Category)
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding($false)
$items=New-Object System.Collections.Generic.List[object]
$issues=New-Object System.Collections.Generic.List[string]
$keyword='(?i)anydesk|teamviewer|screenconnect|connectwise|splashtop|rustdesk|remote|intune|manageengine|meshcentral|kaseya|ninjaone|atera|logmein|bomgar'
function Add-Finding($Name,$Publisher,$FilePath,$Status,$Source,$Explanation) {
    $review=([string]$Name -match $keyword)
    $items.Add([pscustomobject]@{name=[string]$Name;publisher=[string]$Publisher;path=[string]$FilePath;status=[string]$Status;source=[string]$Source;explanation=if($review){'Name matches a remote-access or management keyword. Verify the publisher and purpose. This alone does not establish remote control or a payment lock.'}else{[string]$Explanation};confidence=if($review){'needs review'}else{'informational'}})
}
function Read-Part([string]$Label,[scriptblock]$Action) {
    try { & $Action } catch { $issues.Add($Label+': '+$_.Exception.Message) }
}
switch ($Category) {
  'applications' {
    foreach($key in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall')) {
      Read-Part $key { if(Test-Path -LiteralPath $key){ foreach($entry in Get-ItemProperty ($key+'\*') -ErrorAction Stop){ if($entry.DisplayName){Add-Finding $entry.DisplayName $entry.Publisher $entry.InstallLocation 'Registered' $key 'Registered desktop application. Registration does not prove it is running.'} } } }
    }
  }
  'services' {
    Read-Part 'Win32_Service' { foreach($entry in Get-CimInstance Win32_Service -OperationTimeoutSec 10){
      $exe='';if($entry.PathName -match '^"([^"]+)"'){$exe=$Matches[1]}elseif($entry.PathName -match '^(.+?\.exe)\b'){$exe=$Matches[1]}
      Add-Finding ($entry.DisplayName+' ['+$entry.Name+']') '' $exe $entry.State 'Win32_Service' 'Windows service inventory. A service name or running state alone does not identify a remote lock.'
    } }
  }
  'tasks' {
    Read-Part 'Task Scheduler' { foreach($entry in Get-ScheduledTask){Add-Finding ($entry.TaskPath+$entry.TaskName) $entry.Author '' $entry.State 'Task Scheduler' 'Registered scheduled task. Task arguments are omitted to avoid collecting embedded secrets.'} }
  }
  'startup' {
    foreach($key in @('HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce','HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce')){
      Read-Part $key { if(Test-Path -LiteralPath $key){foreach($property in (Get-ItemProperty -LiteralPath $key).PSObject.Properties){if($property.Name -notmatch '^PS'){Add-Finding $property.Name '' '' 'Configured' $key 'Startup registration. Command arguments are omitted; registration is not evidence the program is running.'}}} }
    }
    foreach($folder in @([Environment]::GetFolderPath('Startup'),[Environment]::GetFolderPath('CommonStartup'))){
      Read-Part 'Startup folder' {if($folder -and (Test-Path -LiteralPath $folder)){foreach($entry in Get-ChildItem -LiteralPath $folder -File){Add-Finding $entry.Name '' $entry.FullName 'Present' 'Startup folder' 'File in a startup folder. Target commands were not executed.'}}}
    }
  }
  'enrollment' {
    Read-Part 'Windows enrollment registry' {
      $key='HKLM:\SOFTWARE\Microsoft\Enrollments'
      $count=if(Test-Path -LiteralPath $key){@(Get-ChildItem -LiteralPath $key).Count}else{0}
      Add-Finding 'Windows enrollment registry entries' '' '' ([string]$count) $key 'Registry entry count is an indicator only. Entries can be stale; this does not verify active management, ownership or a payment lock.'
    }
    Read-Part 'Computer domain membership' {
      $entry=Get-CimInstance Win32_ComputerSystem -OperationTimeoutSec 10
      Add-Finding 'Domain membership' '' '' ([string]$entry.PartOfDomain) 'Win32_ComputerSystem.PartOfDomain' 'Domain membership is an organizational-management indicator. Cloud enrollment and active MDM enforcement are not verified by this check.'
    }
  }
  'remoteSettings' {
    Read-Part 'Remote Desktop setting' {
      $key='HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'
      $entry=Get-ItemProperty -LiteralPath $key
      if($null -eq $entry.fDenyTSConnections){throw 'Remote Desktop setting was not returned.'}
      Add-Finding 'Remote Desktop connections' '' '' $(if($entry.fDenyTSConnections -eq 0){'Allowed by this setting'}else{'Denied by this setting'}) $key 'Local setting only. Firewall policy, edition support and actual reachability have not been tested.'
    }
    Read-Part 'Remote Assistance setting' {
      $key='HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance'
      if(Test-Path -LiteralPath $key){$entry=Get-ItemProperty -LiteralPath $key;Add-Finding 'Remote Assistance' '' '' ([string]$entry.fAllowToGetHelp) $key 'Local Remote Assistance setting (1 enabled, 0 disabled). Empty means unspecified; reachability is not tested.'}else{Add-Finding 'Remote Assistance' '' '' 'Not configured at this key' $key 'No setting at this registry location; other policy sources were not evaluated.'}
    }
  }
  'ports' {
    Read-Part 'TCP listeners' {foreach($entry in Get-NetTCPConnection -State Listen){Add-Finding ('TCP '+$entry.LocalPort) '' '' ('Listening; PID '+$entry.OwningProcess) 'Get-NetTCPConnection' 'Local TCP listening port. No connection or remote probe was made. A listener alone does not prove remote control.'}}
    Read-Part 'UDP endpoints' {foreach($entry in Get-NetUDPEndpoint){Add-Finding ('UDP '+$entry.LocalPort) '' '' ('Bound; PID '+$entry.OwningProcess) 'Get-NetUDPEndpoint' 'Local UDP endpoint. No packets were sent; this does not establish remote access.'}}
  }
}
$status=if($issues.Count){if($items.Count){'partial'}else{'unavailable'}}else{'checked'}
if($items.Count -gt 1000){$issues.Add('Output limited to the first 1000 entries.');$status='partial'}
[pscustomobject]@{items=@($items | Select-Object -First 1000);status=$status;reason=($issues -join '; ')} | ConvertTo-Json -Depth 6 -Compress
