const test=require('node:test');const assert=require('node:assert/strict');
const {createComputerTasks,isTaskRequest}=require('./computer-tasks.cjs');
const {createOllamaClient}=require('./ollama.cjs');
const properties={x:{type:'number'},y:{type:'number'},text:{type:'string'},appName:{type:'string'},key:{type:'string'},selector:{type:'string'},url:{type:'string'},command:{type:'string'},risk:{type:'string'},confirmed:{type:'boolean'}};
const specs=['computer_open_app','computer_type_text','computer_click','computer_press_key','ui_inspect','screen_snapshot','browser_open','browser_read','browser_click','terminal_run'].map(name=>({name,description:name,parameters:{type:'object',properties,additionalProperties:false}}));
function fixture(options={}){
  const calls=[],approvals=[],modes=[];let time=1;
  const state={ok:true,windowId:'7',title:'Notes',elements:[{name:'Add item',type:'Button',bounds:{x:10,y:10,width:100,height:30}}],focused:{name:'Note',type:'Edit'}};
  const page={ok:true,tabId:'tab-1',url:'https://example.com/',target:{name:'Show details',type:'button'}};
  const tasks=createComputerTasks({specs,now:()=>time,inspectNative:async()=>structuredClone(state),inspectBrowser:async()=>structuredClone(page),onMode:mode=>modes.push(mode),confirm:async action=>{approvals.push(action);return false;},dispatch:async(name,args)=>{calls.push({name,args});return name==='ui_inspect'?structuredClone(state):name==='browser_read'?structuredClone(page):{ok:true};},...options});
  const task=tasks.begin({message:'Open Notepad and type a note for me.'});
  return {tasks,task,calls,approvals,modes,state,page,advance:()=>{time+=121000;}};
}
test('only a human task request grants automatic computer access; conversation stays passive',()=>{
  for(const message of ['Open Calculator','Can you please browse example.com?','Use my computer to test this app','Build a notes app','Open the browser. Do not use any previous project.'])assert.equal(isTaskRequest(message),true,message);
  for(const message of ['Hello','What is computer use?','Explain how to open Notepad','Do not use my computer','How can I build a calculator?'])assert.equal(isTaskRequest(message),false,message);
  const {tasks}=fixture();assert.equal(tasks.begin({message:'Open Notepad',enabled:false}),null);assert.equal(tasks.begin({message:'Hi'}),null);
});
test('common app opening and fresh inspected typing/clicking run without routine approvals',async()=>{
  const f=fixture();assert.equal((await f.tasks.execute(f.task,'computer_open_app',{appName:'notepad'})).ok,true);
  assert.equal((await f.tasks.execute(f.task,'computer_click',{x:20,y:20})).ok,false);
  await f.tasks.execute(f.task,'ui_inspect');assert.equal((await f.tasks.execute(f.task,'computer_click',{x:20,y:20})).ok,true);
  assert.match((await f.tasks.execute(f.task,'computer_type_text',{text:'hello'})).error,/Inspect/);
  await f.tasks.execute(f.task,'ui_inspect');assert.equal((await f.tasks.execute(f.task,'computer_type_text',{text:'hello'})).ok,true);
  assert.equal(f.approvals.length,0);assert.equal(f.modes.at(-1),'computer');f.tasks.end(f.task);assert.equal(f.modes.at(-1),'display');
});
test('changed and stale foreground observations cannot trigger desktop input',async()=>{
  const f=fixture();await f.tasks.execute(f.task,'ui_inspect');f.state.windowId='8';
  assert.match((await f.tasks.execute(f.task,'computer_click',{x:20,y:20})).error,/changed/);
  await f.tasks.execute(f.task,'ui_inspect');f.advance();assert.match((await f.tasks.execute(f.task,'computer_click',{x:20,y:20})).error,/Inspect/);
  assert.equal(f.calls.filter(c=>c.name==='computer_click').length,0);
});
test('model-supplied approval fields cannot bypass host review for commands, destructive and unknown targets',async()=>{
  const f=fixture();assert.equal((await f.tasks.execute(f.task,'terminal_run',{command:'echo example',confirmed:true,risk:'low'})).ok,false);
  const g=fixture();g.state.elements[0].name='Delete account';await g.tasks.execute(g.task,'ui_inspect');assert.equal((await g.tasks.execute(g.task,'computer_click',{x:20,y:20,confirmed:true,risk:'low'})).ok,false);
  const h=fixture();await h.tasks.execute(h.task,'ui_inspect');assert.equal((await h.tasks.execute(h.task,'computer_click',{x:900,y:900,confirmed:true})).ok,false);
  const approvals=[...f.approvals,...g.approvals,...h.approvals];assert.equal(approvals.length,3);assert.ok(approvals.every(a=>!('confirmed' in a.args)&&!('risk' in a.args)));
  assert.equal([...f.calls,...g.calls,...h.calls].filter(c=>c.name==='terminal_run'||c.name==='computer_click').length,0);
  assert.match((await f.tasks.execute(f.task,'ui_inspect')).error,/stopped/);
});
test('cancellation during a host dialog prevents the approved action from starting',async()=>{
  let authorize;const f=fixture({confirm:()=>new Promise(resolve=>{authorize=resolve;})});
  const pending=f.tasks.execute(f.task,'terminal_run',{command:'echo example'});await new Promise(setImmediate);
  f.tasks.end(f.task);authorize(true);assert.match((await pending).error,/stopped/);assert.equal(f.calls.length,0);assert.equal(f.task.signal.aborted,true);
});
test('a new window during approval invalidates that approval',async()=>{
  let f;f=fixture({confirm:async()=>{f.state.windowId='new-window';return true;}});
  await f.tasks.execute(f.task,'ui_inspect');assert.match((await f.tasks.execute(f.task,'computer_press_key',{key:'enter'})).error,/changed during approval/);
});
test('browser actions require a current page read and sensitive targets use host review',async()=>{
  const f=fixture();assert.match((await f.tasks.execute(f.task,'browser_click',{selector:'#details'})).error,/Read/);
  f.page.target.type='submit';f.page.target.submitsForm=false;
  await f.tasks.execute(f.task,'browser_read');assert.equal((await f.tasks.execute(f.task,'browser_click',{selector:'#details'})).ok,true);assert.equal(f.approvals.length,0);
  await f.tasks.execute(f.task,'browser_read');f.page.url='https://other.example/';assert.match((await f.tasks.execute(f.task,'browser_click',{selector:'#details'})).error,/changed/);
  f.page.target.name='Buy now';await f.tasks.execute(f.task,'browser_read');assert.equal((await f.tasks.execute(f.task,'browser_click',{selector:'#buy',confirmed:true,risk:'low'})).ok,false);assert.equal(f.approvals.length,1);
});
test('unsupported protocols, invalid arguments, unknown tools and forged tasks never dispatch',async()=>{
  const f=fixture();for(const [name,args] of [['browser_open',{url:'file:///private.txt'}],['computer_click',{x:'1',y:1}],['browser_eval',{}],['computer_open_app',{appName:'notepad',extra:'bad'}]])assert.equal((await f.tasks.execute(f.task,name,args)).ok,false);
  assert.equal((await f.tasks.execute({...f.task,id:'forged'},'ui_inspect')).ok,false);assert.equal(f.calls.length,0);
});
test('computer tasks stop after their bounded action budget and do not overlap',async()=>{
  const f=fixture();for(let i=0;i<24;i++)assert.equal((await f.tasks.execute(f.task,'ui_inspect')).ok,true);
  assert.match((await f.tasks.execute(f.task,'ui_inspect')).error,/24-action/);
  let finish;const g=fixture({dispatch:()=>new Promise(resolve=>{finish=resolve;})});const pending=g.tasks.execute(g.task,'ui_inspect');
  assert.match((await g.tasks.execute(g.task,'ui_inspect')).error,/already running/);assert.match((await g.tasks.execute(g.task,'ui_inspect')).error,/already running/);finish({ok:true});await pending;
});
const reply=data=>new Response(JSON.stringify(data));
test('local and cloud models execute the same task adapter and receive real tool results',async()=>{
  for(const model of ['local','selected:cloud']){
    const bodies=[],calls=[];let round=0;
    const adapter={instructions:'Host-approved computer task.',specs:[{type:'function',function:{name:'browser_read',description:'Read page',parameters:{type:'object',properties:{}}}}],execute:async(name,args,context)=>{calls.push({name,args,context});return {ok:true,text:'Observed badge ready'};}};
    const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{
      if(url.pathname==='/api/tags')return reply({models:[{name:model}]});if(url.pathname==='/api/show')return reply({capabilities:['tools']});
      bodies.push(JSON.parse(options.body));return reply({message:++round===1?{tool_calls:[{function:{name:'browser_read',arguments:{}}}]}:{content:'Verified badge ready.'}});
    }});
    const result=await client.chat({model,message:'Check the badge.',fastMode:true,computerTools:adapter});assert.equal(result.content,'Verified badge ready.');assert.equal(calls.length,1);assert.equal(calls[0].context.cloud,model.endsWith('cloud'));
    assert.match(bodies[1].messages.at(-1).content,/Observed badge ready/);assert.match(bodies[0].messages[0].content,/Host-approved/);assert.doesNotMatch(bodies[0].messages[0].content,/no desktop tools|cannot write files/);assert.equal(bodies[0].options.num_ctx,model.endsWith('cloud')?undefined:8192);
  }
});
test('text models never receive screenshot tools and unavailable calls do not run',async()=>{
  let executed=false;
  const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>url.pathname==='/api/tags'?reply({models:[{name:'local'}]}):url.pathname==='/api/show'?reply({capabilities:['tools']}):reply({message:{tool_calls:[{function:{name:'screen_snapshot',arguments:{}}}]}})});
  await assert.rejects(client.chat({model:'local',message:'Inspect computer',computerTools:{instructions:'Task',specs:[{type:'function',function:{name:'screen_snapshot',parameters:{}}}],execute:async()=>{executed=true;}}}),/unavailable tool/);assert.equal(executed,false);
});
test('a resumed uncertain action is marked unknown instead of being replayed',async()=>{
  let executed=0;let body;
  const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>url.pathname==='/api/tags'?reply({models:[{name:'local'}]}):url.pathname==='/api/show'?reply({capabilities:['tools']}):(body=JSON.parse(options.body),reply({message:{content:'Inspect current state first.'}}))});
  await client.chat({model:'local',message:'Open Notepad',computerTools:{instructions:'Task',specs:[],execute:async()=>{executed++;}},resumeState:{messages:[{role:'system',content:'Gracie'},{role:'user',content:'Open Notepad'},{role:'assistant',content:'',tool_calls:[{function:{name:'computer_open_app',arguments:{appName:'notepad'}}}]}]}});
  assert.equal(executed,0);assert.match(body.messages.at(-1).content,/unknown completion/);
});
