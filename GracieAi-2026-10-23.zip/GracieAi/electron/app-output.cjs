const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const {renameWithRetry}=require('./atomic-file.cjs');
const launcher='@echo off\r\nsetlocal\r\nset "ELECTRON_RUN_AS_NODE="\r\npushd "%~dp0" || exit /b 1\r\n"%~dp0GracieApp.exe" %*\r\nset "appExit=%errorlevel%"\r\npopd\r\nexit /b %appExit%\r\n';

// Only the trusted packaged runtime is copied/launched. Models cannot supply paths or commands.
function createAppOutput({ configFile, defaultFolder, builder, launch }) {
  const pending = new Map();
  async function settings() {
    try { const data = JSON.parse(await fs.readFile(configFile, 'utf8')); if (typeof data.folder === 'string' && path.isAbsolute(data.folder)) return { folder: data.folder }; }
    catch (error) { if (error.code !== 'ENOENT') throw Error('The saved apps folder could not be read. Choose your apps folder again.'); }
    return { folder: path.resolve(defaultFolder) };
  }
  async function choose(folder) {
    if (!path.isAbsolute(folder)) throw Error('Choose an absolute apps folder.');
    const real = await fs.realpath(folder); if (!(await fs.stat(real)).isDirectory()) throw Error('Choose a folder for your apps.');
    await fs.mkdir(path.dirname(configFile), { recursive: true });
    const temporary = configFile + '.' + crypto.randomUUID() + '.tmp';
    await fs.writeFile(temporary, JSON.stringify({ folder: real }, null, 2)); await renameWithRetry(temporary, configFile);
    return { folder: real };
  }
  async function locate(project, parent) {
    if (!project.outputFolder || project.outputRevision !== project.readyRevision) return null;
    try {
      const folder = await fs.realpath(project.outputFolder);
      if (folder !== project.outputFolder || (parent && path.dirname(folder) !== parent)) return null;
      const marker = JSON.parse(await fs.readFile(path.join(folder, '.gracie-app.json'), 'utf8'));
      if (marker.projectId !== project.id || marker.revision !== project.readyRevision) return null;
      const executable = path.join(folder, 'GracieApp.exe');
      const info = await fs.lstat(executable); if (!info.isFile() || info.isSymbolicLink()) return null;
      if (await fs.readFile(path.join(folder,'Start-App.cmd'),'utf8') !== launcher) return null;
      return { project, folder, executable };
    } catch { return null; }
  }
  async function publish(id, { signal, onProgress = () => {} } = {}) {
    if (pending.has(id)) return pending.get(id);
    const task = (async () => {
      signal?.throwIfAborted();
      const { project, path: source } = await builder.artifact(id, 'runnable');
      const { folder: selected } = await settings();
      await fs.mkdir(selected, { recursive: true }); const parent = await fs.realpath(selected);
      const existing = await locate(project, parent); if (existing) return existing;
      onProgress('Saving the runnable app in your apps folder…');
      const staging = await fs.mkdtemp(path.join(parent, '.gracie-building-'));
      try {
        for (const entry of await fs.readdir(source)) {
          await fs.cp(path.join(source, entry), path.join(staging, entry), { recursive: true, force: false, errorOnExist: true, filter: () => { signal?.throwIfAborted(); return true; } });
        }
        signal?.throwIfAborted();
        await fs.writeFile(path.join(staging, '.gracie-app.json'), JSON.stringify({ projectId: id, revision: project.readyRevision }));
        await fs.writeFile(path.join(staging, 'Start-App.cmd'), launcher);
        await fs.writeFile(path.join(staging, 'OPEN THIS APP.txt'), `${project.title}\r\n\r\nDouble-click GracieApp.exe to run this app. No setup commands or installation needed.\r\nKeep all files in this folder together.\r\n\r\nBuilt and checked by Gracie. Version ${project.readyRevision}.\r\n`);
        const name = project.title.replace(/[^a-z0-9 -]/gi, '').trim().slice(0, 50) || 'Gracie App';
        const folder = path.join(parent, `${name} - v${project.readyRevision} - ${crypto.randomUUID().slice(0, 8)}`);
        // Refuse any collision; never replace the user's folders or an older working app.
        try { await fs.lstat(folder); throw Error('That app folder already exists. Retry to choose a fresh folder.'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
        await renameWithRetry(staging, folder);
        const updated = await builder.recordOutput(id, { folder, revision: project.readyRevision });
        return { project: updated, folder, executable: path.join(folder, 'GracieApp.exe') };
      } finally {
        // Cleanup is confined to the exact temporary child created above, never the chosen parent.
        if (path.dirname(path.resolve(staging)) === parent && path.basename(staging).startsWith('.gracie-building-')) await fs.rm(staging, { recursive: true, force: true }).catch(() => {});
      }
    })();
    pending.set(id, task);
    try { return await task; } finally { pending.delete(id); }
  }
  async function run(id) { const output = await publish(id); const error = await launch(output.executable); if (error) throw Error(error); return { ok: true, folder: output.folder }; }
  return { settings, choose, publish, run };
}
module.exports = { createAppOutput };
