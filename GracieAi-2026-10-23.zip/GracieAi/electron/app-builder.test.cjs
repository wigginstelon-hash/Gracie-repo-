const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const path=require('node:path');const os=require('node:os');
const {createAppBuilder,simpleIntent,targetProject,validateDraft,parseJson}=require('./app-builder.cjs');const {createOllamaClient}=require('./ollama.cjs');
const draft={title:'Click Counter',summary:'A counter that increments when clicked.',html:'<h1>Counter</h1><output id="count">0</output><button id="add">Add one</button>',css:'body{font:18px system-ui}',javascript:"let count=0;document.querySelector('#add').onclick=()=>document.querySelector('#count').textContent=String(++count);",checks:[{selector:'#add',event:'click',expectSelector:'#count',property:'textContent',includes:'1'}]};
async function temp(t){const folder=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-app-builder-'));t.after(()=>fs.rm(folder,{recursive:true,force:true}));return folder;}
const complete=async()=>({content:JSON.stringify(draft)});

test('staged checks open another tab before interacting with hidden controls',()=>{
  const {validateNavigation}=require('./app-generation.cjs');
  const pages=[{buttonId:'nav-one',panelId:'one'},{buttonId:'nav-two',panelId:'two'}];
  const html='<button id="nav-one">One</button><button id="nav-two">Two</button><section id="one"><input id="first"></section><section id="two"><input id="second"></section>';
  const check={selector:'#second',event:'input',value:'42',expectSelector:'#second',property:'value',includes:'42'};
  assert.throws(()=>validateNavigation([check],html,pages),/First explicitly click #nav-two/);
  validateNavigation([{selector:'#nav-two',event:'click',value:'',expectSelector:'#nav-two',property:'textContent',includes:'Two'},check],html,pages);
  assert.throws(()=>validateNavigation([{selector:'#nav-two',event:'click'}, {...check,selector:'#first',expectSelector:'#first'}],html,pages),/First explicitly click #nav-one/);
});
test('feature code checks executable references while allowing harmless comments and quoted documentation',()=>{
  const {validateFeatureScript}=require('./app-script.cjs');
  validateFeatureScript('// Do not use window.Gracie or localStorage.getItem here.\nconst explanation="require() is unavailable";let editingId=null;Gracie.subscribe(()=>document.title=String(Gracie.read().count));');
  for(const script of ['window.Gracie.change({});','globalThis["Gracie"].read();','localStorage.setItem("x","y");','const Gracie={};','require("fs");','process.env.KEY;'])assert.throws(()=>validateFeatureScript(script));
  assert.throws(()=>validateFeatureScript('const unfinished='),SyntaxError);
  assert.throws(()=>validateFeatureScript('const notesModule={init(){Gracie.subscribe(render);},render(){document.title="Notes";}};notesModule.init();'),/notesModule.render/);
  validateFeatureScript('const notesModule={init(){Gracie.subscribe(()=>notesModule.render());},render(){document.title="Notes";}};notesModule.init();');
  validateFeatureScript('if(typeof optionalBrowserFeature!=="undefined")document.title="Available";');
  assert.throws(()=>validateFeatureScript('Gracie.change({count:1});document.title=String(Gracie.read().count);'),/never subscribes/);
  assert.throws(()=>validateFeatureScript('confirm("Delete?");Gracie.change({count:1});document.title=String(Gracie.read().count);'),/Blocking alert/);
  validateFeatureScript('(()=>{function confirm(){return true;}confirm();})();');
  assert.throws(()=>validateFeatureScript('Gracie.change({notes:"x"});',{stateFields:[]}),/owns no state fields/);
  assert.throws(()=>validateFeatureScript('const raw=JSON.stringify(Gracie.read());Gracie.change(JSON.parse(raw));Gracie.subscribe(()=>{});',{backup:true}),/canonical version\/app\/data/);
  validateFeatureScript('const raw=Gracie.exportData();Gracie.importData(raw);',{backup:true});
  assert.throws(()=>validateFeatureScript('function handleDeleteExpense(){document.title="Deleted";}'),/Unbound event handlers/);
  validateFeatureScript('function handleDeleteExpense(){document.title="Deleted";}document.addEventListener("click",handleDeleteExpense);');
  assert.throws(()=>validateFeatureScript('const label="broken;'),error=>/Invalid JavaScript/.test(error.message)&&/Nearby source:\n1: const label/.test(error.message));
});
test('empty and truncated generations retry without packaging incomplete files, while authentication failures stop',async t=>{
  const folder=await temp(t);let calls=0;
  const builder=createAppBuilder({directory:folder,platform:'verification',complete:async()=>{calls++;if(calls===1)throw Error('The model returned no app content. Try another model.');if(calls===2)return {content:'{"title":"Incomplete',truncated:true};return {content:JSON.stringify(draft)};},smoke:async()=>({checks:['Verified fixture'],functional:1})});
  const result=await builder.run({request:{message:'Build a counter',model:'chosen'}});assert.equal(calls,3);assert.equal(result.project.status,'ready');
  let deniedCalls=0;const denied=createAppBuilder({directory:path.join(folder,'denied'),complete:async()=>{deniedCalls++;throw Error('Ollama returned 401: Sign in first.');}});await assert.rejects(denied.run({request:{message:'Build a counter',model:'chosen'}}),/401/);assert.equal(deniedCalls,1);
});
test('auto routing keeps conversation and plans separate from explicit app requests and edits',async()=>{
  for(const text of ['Hello Gracie','What is a desktop app?','Explain how a calculator works','Plan a desktop app','Do not build an app yet'])assert.equal(simpleIntent(text,true),'chat',text);
  for(const text of ['Build me a desktop app for notes','Create a calculator','Can you make a budget tracker?','I need a simple timer app','Add a reset button','Make it blue','Hello Gracie, build me a calculator app','Turn this code into a desktop app','Write me a small notes program'])assert.equal(simpleIntent(text,true),'build',text);
  assert.equal(targetProject('Build a new app','old'),'');assert.equal(targetProject('Build a calculator','old'),'');assert.equal(targetProject('Change this app to blue','old'),'old');
  let calls=0;const builder=createAppBuilder({directory:os.tmpdir(),complete:async input=>{calls++;assert.equal(input.model,'chosen:cloud');return{content:'```json\n{"mode":"build"}\n```'};}});
  assert.equal(await builder.route('I need a polished utility that keeps track of my daily activities.','',undefined,'chosen:cloud'),'build');assert.equal(calls,1);
  assert.equal(await builder.route('A teal counter with Add and Reset buttons','',undefined,'chosen:cloud','build'),'build');assert.equal(calls,1,'the explicit build button bypasses chat classification');
});
test('code validation rejects invalid JavaScript and native commands without executing generated code',()=>{
  assert.throws(()=>validateDraft({...draft,javascript:'function {broken'}),/Unexpected/);
  assert.throws(()=>validateDraft({...draft,javascript:'require("child_process").exec("test")'}),/Node|shell/);
  assert.throws(()=>validateDraft({...draft,javascript:'require("fs").readFileSync("private")'}),/Node|shell/);
  assert.throws(()=>validateDraft({...draft,html:'<script>const = broken</script>'}),/Unexpected/);
  assert.equal(parseJson('Here is the project: ```json\n'+JSON.stringify(draft)+'\n```').title,draft.title);
});
test('a real ZIP contains a runnable desktop host and source; later revisions preserve completed downloads',async t=>{
  const folder=await temp(t),runtime=path.join(folder,'runtime');await fs.mkdir(path.join(runtime,'resources'),{recursive:true});await fs.writeFile(path.join(runtime,'electron.exe'),'runtime fixture');await fs.writeFile(path.join(runtime,'resources','default_app.asar'),'default fixture');
  const builder=createAppBuilder({directory:path.join(folder,'projects'),runtimeRoot:runtime,platform:'win32',complete,smoke:async()=>({checks:['JavaScript syntax','Fixture smoke'],functional:1})});
  const first=await builder.run({request:{message:'Build a counter app',model:'local'}});assert.equal(first.project.status,'ready');assert.equal(first.project.hasWindows,true);
  const zipFile=await builder.artifact(first.project.id,'windows');const zip=await require('jszip').loadAsync(await fs.readFile(zipFile.path));assert.equal(await zip.file('GracieApp.exe').async('string'),'runtime fixture');assert.ok(zip.file('resources/app/index.html'));assert.ok(!zip.file('resources/default_app.asar'));
  const main=await zip.file('resources/app/main.cjs').async('string');assert.match(main,/sandbox:true/);assert.match(main,/nodeIntegration:false/);assert.doesNotMatch(main,/exec\(|spawn\(/);
  const html=await zip.file('resources/app/index.html').async('string');assert.match(html,/Content-Security-Policy/);assert.match(html,/connect-src 'none'/);
  const second=await builder.run({request:{message:'Add a reset button',model:'local',projectId:first.project.id}});assert.equal(second.project.revision,2);assert.equal(first.project.id,second.project.id);assert.equal(await fs.readFile(zipFile.path).then(b=>b.length)>0,true);
  const restarted=createAppBuilder({directory:path.join(folder,'projects'),complete});assert.equal((await restarted.list())[0].readyRevision,2);await assert.rejects(restarted.artifact('../outside','source'),/Invalid/);
});
test('failed checks trigger bounded repairs and never replace the last working app',async t=>{
  const folder=await temp(t);let generated=0,fail=false;
  const changed={...draft,title:'Counter with reset',html:draft.html+'<button id="reset">Reset</button>',javascript:draft.javascript+'document.querySelector("#reset").onclick=()=>{count=0;document.querySelector("#count").textContent="0";};'};
  const builder=createAppBuilder({directory:folder,platform:'linux',complete:async input=>{generated++;if(generated===5){const user=JSON.parse(input.messages[1].content);assert.equal(user.previous.title,changed.title);assert.match(user.previous.javascript,/#reset/);assert.match(user.checkErrors,/Missing reset/);assert.equal(user.previousRequest,'Add reset');}return{content:JSON.stringify(generated===1?draft:changed)};},smoke:async()=>{if(fail)throw Error('Missing reset control');return{checks:['Real check adapter'],functional:1};}});
  const first=await builder.run({request:{message:'Build a counter app',model:'local'}});fail=true;
  await assert.rejects(builder.run({request:{message:'Add reset',model:'local',projectId:first.project.id}}),/after repairs/);assert.equal(generated,4);
  assert.equal((await builder.manifest(first.project.id)).readyRevision,1);assert.ok((await builder.artifact(first.project.id,'source')).path.endsWith('source.zip'));
  fail=false;const repaired=await builder.run({request:{message:'Fix this app',projectId:first.project.id,model:'local'}});assert.equal(repaired.project.readyRevision,3);assert.equal(generated,5);
});

test('repair receives observed controls and the exact failed sequence instead of only a timeout message',async t=>{
  const folder=await temp(t);let calls=0,smokes=0;
  const failure={index:1,check:{selector:'#num',event:'input',value:'12',expectSelector:'#result',property:'textContent',includes:'Factors:'},completed:[],target:{tag:'input',id:'num',value:'12'},output:{tag:'div',id:'result',text:''},buttons:[{tag:'button',id:'go',text:'Calculate'}],hint:'Explicitly click the control before asserting the result.'};
  const builder=createAppBuilder({directory:folder,platform:'verification',complete:async input=>{
    const user=JSON.parse(input.messages[1].content);calls++;
    assert.match(input.messages[0].content,/Typing does not click a button/);
    if(calls===2){assert.deepEqual(user.previous,draft);assert.deepEqual(user.checkFailure,failure);assert.match(user.checkErrors,/blank result/);}
    return {content:JSON.stringify(draft)};
  },smoke:async()=>{if(++smokes===1){const error=Error('blank result');error.checkFailure=failure;throw error;}return {checks:['Real check adapter'],functional:1};}});
  const built=await builder.run({request:{message:'Build a calculator app',model:'chosen'}});assert.equal(built.project.status,'ready');assert.equal(calls,2);
  const saved=JSON.parse(await fs.readFile(path.join(folder,built.project.id,'revisions','1','build-state.json'),'utf8'));assert.equal(saved.stage,'ready');assert.equal(saved.error,'');assert.equal(saved.checkFailure,null);
});

test('a new repair of a failed first build retains its draft and failure after restart',async t=>{
  const folder=await temp(t);const first=createAppBuilder({directory:folder,platform:'verification',complete,smoke:async()=>{throw Error('Result needs a calculate click');}});
  await assert.rejects(first.run({request:{message:'Build a calculator app',model:'chosen'}}),/after repairs/);
  const project=(await first.list())[0];assert.equal(project.readyRevision,0);
  const state=JSON.parse(await fs.readFile(path.join(folder,project.id,'revisions','1','build-state.json'),'utf8'));assert.equal(state.draft,null);assert.match(state.error,/after repairs/);
  const restarted=createAppBuilder({directory:folder,platform:'verification',complete:async input=>{const user=JSON.parse(input.messages[1].content);assert.deepEqual(user.previous,draft);assert.match(user.checkErrors,/calculate click/);return {content:JSON.stringify(draft)};},smoke:async()=>({checks:['Interaction passed'],functional:1})});
  const repaired=await restarted.run({request:{message:'Fix this app',projectId:project.id,model:'chosen'}});assert.equal(repaired.project.id,project.id);assert.equal(repaired.project.readyRevision,2);
});

test('builder applies engineering and motion preferences within its real offline runtime constraints',async t=>{
  const folder=await temp(t);let system='';
  const builder=createAppBuilder({directory:folder,platform:'linux',complete:async input=>{system=input.messages[0].content;return{content:JSON.stringify(draft)};},smoke:async()=>({checks:['Interaction passed'],functional:1})});
  const result=await builder.run({request:{message:'Build a counter app',model:'local'}});
  assert.equal(result.project.status,'ready');assert.match(system,/placeholder code/);assert.match(system,/state ownership/);assert.match(system,/prefers-reduced-motion/);assert.match(system,/Do not import Tailwind/);
  assert.ok(await fs.readFile((await builder.artifact(result.project.id,'source')).path).then(data=>data.length>0));
});
test('a paused build survives restart and continues from completed files without calling the model again',async t=>{
  const folder=await temp(t);let checkpoint,calls=0;const controller=new AbortController();
  const builder=createAppBuilder({directory:folder,platform:'linux',complete:async()=>{calls++;return{content:JSON.stringify(draft)};},smoke:async()=>({checks:['App startup'],functional:1})});
  await assert.rejects(builder.run({request:{message:'Build a counter app',model:'local'},signal:controller.signal,onCheckpoint:state=>{checkpoint=state;},onProgress:stage=>{if(stage==='App files written. Checking JavaScript and app startup…')controller.abort();}}));
  assert.equal(checkpoint.kind,'build');assert.ok(checkpoint.draft);
  const restarted=createAppBuilder({directory:folder,platform:'linux',complete:async()=>{throw Error('Completed generation must not repeat');},smoke:async()=>({checks:['App startup'],functional:1})});
  const result=await restarted.run({request:{},checkpoint});assert.equal(result.project.status,'ready');assert.equal(calls,1);
});

test('complex builds save each complete stage and resume without regenerating completed screens',async t=>{
  const folder=await temp(t),controller=new AbortController();let checkpoint,sawCompactUpdate=false,sawPriorFeature=false,planningCalls=0,failUpdate=false;const stages=[];
  const stageComplete=async input=>{
    const key=Object.keys(input.format.properties)[0];stages.push(key);
    const raw=input.messages[1].content,payload=JSON.parse(raw.slice(raw.indexOf('{')));
    if(key==='title'&&!payload.previous){if(planningCalls++===0){assert.equal(input.reasoning,true);return {content:'',truncated:true};}assert.equal(input.reasoning,false);}
    if(key==='title'&&payload.previous){assert.equal(payload.previous.javascript,undefined);assert.equal(payload.previous.css,undefined);assert.equal(payload.previous.features[0].id,'counter');sawCompactUpdate=true;}
    if(key==='javascript'&&payload.previousJavascript){assert.equal(payload.previousJavascript,draft.javascript);sawPriorFeature=true;}
    if(key==='checks')assert.ok(input.format.properties.checks.items.anyOf.every(item=>item.required.includes('value')));
    const values={title:{title:'Advanced Counter',summary:'Counts three successive actions.',requirements:['Increment the counter','Display the current total','Keep controls keyboard accessible'],architecture:'One browser state value.',domContract:['#add button','#count output'],storageKey:'advanced-counter',stateSchema:JSON.stringify({type:'object',properties:{count:{type:'integer'}},required:['count']}),initialState:'{"count":0}',pages:[{buttonId:'nav-counter',panelId:'counter'}],modules:[{id:'counter',purpose:'Increment and display count',stateFields:['count'],selectors:['#add'],requirements:['Increase count on Add']}]},assignments:{assignments:[{moduleId:'counter',selector:'#count',requirement:'Render the current count from shared state.'}]},html:{html:'<button id="nav-counter">Counter</button><section id="counter">'+draft.html+'</section>'},css:{css:draft.css},checks:{checks:[1,2,3].map(value=>({...draft.checks[0],includes:String(value)}))},javascript:{javascript:draft.javascript}};
    if(key==='title'&&payload.previous){values.title.storageKey='an-unwanted-new-key';values.title.pages[0].panelId='unwanted-panel';}
    return {content:JSON.stringify(values[key])};
  };
  const options={directory:folder,platform:'verification',complete:stageComplete,smoke:async input=>{assert.equal(input.draft.checks.length,3);if(failUpdate){failUpdate=false;throw Error('Counter update failed its behavior check');}return {checks:['Three behavior steps'],functional:3};}};
  const builder=createAppBuilder(options);
  await assert.rejects(builder.run({request:{message:'Build an advanced counter app',model:'chosen'},signal:controller.signal,onCheckpoint:state=>{checkpoint=state;},onProgress:stage=>{if(stage==='Building the screens and controls saved.')controller.abort();}}),error=>{assert.equal(controller.signal.aborted,true,error.stack);return true;});
  assert.ok(checkpoint.staged.html);assert.deepEqual(stages,['title','title','assignments','html']);
  const restarted=createAppBuilder(options),result=await restarted.run({request:{},checkpoint});
  assert.deepEqual(stages,['title','title','assignments','html','css','checks','javascript']);assert.equal(result.project.status,'ready');assert.equal(result.job.strategy,'staged');assert.equal(result.project.checks.functional,3);
  failUpdate=true;const updated=await restarted.run({request:{message:'Add an advanced counter improvement',projectId:result.project.id,model:'chosen'}});
  assert.equal(sawCompactUpdate,true);assert.equal(sawPriorFeature,true);
  assert.equal(updated.job.draft.runtime.storageKey,'advanced-counter');assert.equal(updated.job.draft.runtime.pages[0].panelId,'counter');assert.equal(stages.filter(key=>key==='title').length,3);assert.equal(stages.filter(key=>key==='html').length,2);assert.equal(stages.filter(key=>key==='javascript').length,3);
});

test('interaction validation never silently truncates generated scenarios',()=>{
  const checks=Array.from({length:24},(_,index)=>({...draft.checks[0],includes:String(index+1)}));assert.equal(validateDraft({...draft,checks}).checks.length,24);
  assert.throws(()=>validateDraft({...draft,checks:[...checks,checks[0]]}),/1–24/);
  const {validatePreservedChecks}=require('./app-generation.cjs');
  validatePreservedChecks([checks[0],checks[1],checks[2]],[checks[0],checks[2]]);
  assert.throws(()=>validatePreservedChecks([checks[0]],[checks[0],checks[2]]),/retain every unrelated/);
  assert.throws(()=>validatePreservedChecks([checks[2],checks[0]],[checks[0],checks[2]]),/original order/);
});

test('resuming a cached invalid feature repairs its state subscription with reasoning and no duplicate old source',async()=>{
  const {generateStagedApp}=require('./app-generation.cjs');
  const javascript="function render(){document.querySelector('#count').textContent=String(Gracie.read().count);}document.querySelector('#add').onclick=()=>Gracie.change(s=>{s.count++;});render();";
  const plan={title:'Counter',summary:'Counts actions',requirements:['Count actions'],architecture:'Shared counter',domContract:['#add','#count'],storageKey:'counter',stateSchema:{type:'object',properties:{count:{type:'integer'}},required:['count']},initialState:{count:0},pages:[{buttonId:'nav-counter',panelId:'counter'}],modules:[{id:'counter',purpose:'Counter',needsReasoning:false,stateFields:['count'],selectors:['#add','#count'],requirements:['Increment and render count']}]};
  const job={previousModules:{counter:'older source'},staged:{version:7,plan,html:{html:'<button id="nav-counter">Counter</button><section id="counter">'+draft.html+'</section>'},css:{css:draft.css},checks:{checks:draft.checks},module_counter:{javascript}}};
  let calls=0;
  const result=await generateStagedApp({job,request:{message:'Build an advanced counter',model:'local'},save:async()=>{},onProgress:()=>{},complete:async input=>{
    calls++;assert.equal(input.reasoning,true);
    const raw=input.messages[1].content,payload=JSON.parse(raw.slice(raw.indexOf('{')));
    assert.equal(payload.previousJavascript,undefined);assert.match(payload.stageError,/never subscribes/);
    if(calls===1){assert.equal(JSON.parse(payload.previousStageOutput).javascript,javascript);return {content:JSON.stringify({javascript})};}
    assert.equal(payload.previousStageOutput,undefined);assert.match(payload.rewriteFeature,/repeatedly violated/);
    assert.match(input.messages[0].content,/Required correction/);
    return {content:JSON.stringify({javascript:javascript.replace('render();','Gracie.subscribe(render);')})};
  }});
  assert.equal(calls,2);assert.match(result.javascript,/Gracie.subscribe/);assert.equal(job.staged.failedKey,undefined);
  job.featureFailures={counter:2};job.error='Repeated click did not update the counter';job.previousModules={counter:javascript};delete job.staged.module_counter;
  await generateStagedApp({job,request:{message:'Repair the advanced counter',model:'local'},save:async()=>{},onProgress:()=>{},complete:async input=>{
    const raw=input.messages[1].content,payload=JSON.parse(raw.slice(raw.indexOf('{')));assert.equal(payload.previousJavascript,undefined);assert.equal(payload.previousStageOutput,undefined);assert.match(payload.rewriteFeature,/repeatedly violated/);assert.match(payload.stageError,/Repeated click/);return {content:JSON.stringify({javascript:draft.javascript})};
  }});
});

test('focused check repair replaces the failing action while retaining later behavior assertions',async()=>{
  const {generateStagedApp}=require('./app-generation.cjs');
  const first={...draft.checks[0],value:''},later={...first,includes:'2'},wrong={...first,expectSelector:'#error'};
  const plan={title:'Counter',summary:'Count actions',requirements:['Count actions'],architecture:'Counter',domContract:['#add','#count'],storageKey:'counter',stateSchema:{type:'object',properties:{count:{type:'integer'}},required:['count']},initialState:{count:0},pages:[{buttonId:'nav-counter',panelId:'counter'}],modules:[{id:'counter',purpose:'Counter',stateFields:['count'],selectors:['#add','#count'],requirements:['Count actions']}]};
  const job={previous:{checks:[wrong,later]},checksToPreserve:[later],checkFailure:{index:1,check:wrong,matchingOutputs:[{id:'count',text:'1'}]},staged:{version:7,plan,html:{html:'<button id="nav-counter">Counter</button><section id="counter">'+draft.html+'</section>'},css:{css:draft.css},module_counter:{javascript:draft.javascript}}};
  let calls=0;const result=await generateStagedApp({job,request:{message:'Repair counter checks',model:'local'},save:async()=>{},onProgress:()=>{},checkSchema:{type:'object',properties:Object.fromEntries(['selector','event','value','expectSelector','property','includes'].map(key=>[key,{type:'string'}])),required:['selector','event','value','expectSelector','property','includes'],additionalProperties:false},complete:async input=>{
    calls++;assert.match(input.messages[0].content,/FOCUSED CHECK REPAIR/);const raw=input.messages[1].content,payload=JSON.parse(raw.slice(raw.indexOf('{')));assert.deepEqual(payload.repairOnly,wrong);assert.equal(payload.previousChecks,undefined);assert.equal(input.format.properties.checks.maxItems,8);return {content:JSON.stringify({checks:[first]})};
  }});
  assert.equal(calls,1);assert.deepEqual(result.checks,[first,later]);
});
test('local generation requests schema output; cloud generation omits unsupported format and preserves the chosen model',async()=>{
  const bodies=[];const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{if(url.pathname==='/api/tags')return new Response(JSON.stringify({models:[{name:'local'},{name:'chosen:cloud',remote_host:'https://ollama.com'}]}));bodies.push(JSON.parse(options.body));return new Response(JSON.stringify({message:{content:'{"title":"app"}'},done_reason:'stop'}));}});
  for(const model of ['local','chosen:cloud'])await client.complete({model,messages:[{role:'user',content:'Make an app'}],format:{type:'object'},maxTokens:250});
  assert.ok(bodies[0].format);assert.equal(bodies[1].format,undefined);assert.equal(bodies[1].model,'chosen:cloud');assert.equal(bodies[0].options.num_predict,250);
});
