const {contextBridge,ipcRenderer}=require('electron');
// The host supplies the window-specific channel prefix, never an arbitrary renderer channel.
const prefix=process.argv.find(value=>value.startsWith('--gracie-native-id='))?.slice('--gracie-native-id='.length);
if(/^[a-f0-9-]{36}$/.test(prefix||''))contextBridge.exposeInMainWorld('desktop',{
  scanSystem:()=>ipcRenderer.invoke('gracie-native:'+prefix+':scanSystem'),
  openText:()=>ipcRenderer.invoke('gracie-native:'+prefix+':openText'),
  saveText:input=>ipcRenderer.invoke('gracie-native:'+prefix+':saveText',input),
  chooseFolder:()=>ipcRenderer.invoke('gracie-native:'+prefix+':chooseFolder'),
});
