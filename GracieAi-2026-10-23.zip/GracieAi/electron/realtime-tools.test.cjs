const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const ts=require('typescript');
function fixture(){
  const executed=[],ended=[],sent=[],transcripts=[];const exports={};
  const gracie={endComputerTask:async id=>{ended.push(id);},beginComputerTask:async()=>({enabled:true,taskId:'audio-task'}),executeTool:async call=>{executed.push(call);return {ok:true,text:'Observed fixture'};}};
  const source=ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/lib/realtime.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  vm.runInNewContext(source,{exports,window:{gracie},console,crypto:require('node:crypto').webcrypto,setTimeout,clearTimeout,Date});
  const callbacks=Object.fromEntries(['onConnectionState','onMood','onMouthShape','onTranscript','onArtifact','onMode','onStatus','onThumbnailReady'].map(name=>[name,()=>{}]));
  callbacks.onTranscript=entry=>transcripts.push(entry);
  callbacks.getLocalModel=()=> 'selected-local';
  const client=new exports.GracieRealtimeClient(callbacks);
  client.dc={readyState:'open',send:value=>sent.push(JSON.parse(value)),close(){this.readyState='closed';}};
  client.toolSpecs=[{name:'browser_read'}];
  const event=value=>client.handleServerEvent(JSON.stringify(value));
  return {client,event,executed,ended,sent,transcripts,gracie};
}
const tool={type:'function_call',name:'browser_read',call_id:'call-1',arguments:'{}'};
test('an API response keeps its original task identity instead of gaining a later task authorization',async()=>{
  const f=fixture();f.client.taskAuthorization=Promise.resolve({enabled:true,taskId:'original'});
  await f.event({type:'response.created',response:{id:'response-1'}});f.client.taskAuthorization=Promise.resolve({enabled:true,taskId:'new-request'});
  await f.event({type:'response.done',response:{id:'response-1',output:[tool]}});
  assert.equal(f.executed[0].taskId,'original');assert.equal(f.executed.length,1);
});
test('an early API response waits for the human audio transcript before computer tools execute',async()=>{
  const f=fixture();await f.event({type:'input_audio_buffer.speech_started'});await f.event({type:'response.created',response:{id:'audio-response'}});
  const pending=f.event({type:'response.done',response:{id:'audio-response',output:[tool]}});await new Promise(setImmediate);assert.equal(f.executed.length,0);
  await f.event({type:'conversation.item.input_audio_transcription.completed',transcript:'Open the browser'});await pending;
  assert.equal(f.executed[0].taskId,'audio-task');
});
test('a cancelled API response performs no actions and completion ends only its own task',async()=>{
  const f=fixture();f.client.taskAuthorization=Promise.resolve({enabled:true,taskId:'first'});await f.event({type:'response.created',response:{id:'first-response'}});
  await f.event({type:'response.done',response:{id:'first-response',status:'cancelled',output:[tool]}});assert.equal(f.executed.length,0);
  await f.event({type:'response.created',response:{id:'finished'}});f.client.taskAuthorization=Promise.resolve({enabled:true,taskId:'next'});
  await f.event({type:'response.done',response:{id:'finished',output:[]}});assert.equal(f.ended.at(-1),'first');
});
test('disconnecting while authorization is pending cannot run queued tools',async()=>{
  const f=fixture();await f.event({type:'input_audio_buffer.speech_started'});const pending=f.client.executeFunctionCalls([tool],f.client.taskAuthorization);
  f.client.disconnect();await pending;assert.equal(f.executed.length,0);
});

test('voice local-model answers use the current selection and appear in chat as actual tool results',async()=>{
  const f=fixture();f.client.toolSpecs=[{name:'ollama_chat'}];
  f.gracie.executeTool=async call=>{f.executed.push(call);return {ok:true,model:call.arguments.model,localModelAnswer:'37'};};
  await f.client.executeFunctionCalls([{type:'function_call',name:'ollama_chat',call_id:'local-1',arguments:'{"message":"18 + 19"}'}],Promise.resolve({enabled:false}));
  assert.equal(f.executed[0].arguments.model,'selected-local');
  assert.equal(f.transcripts.at(-1).role,'gracie');assert.match(f.transcripts.at(-1).text,/selected-local[\s\S]*37/);
  const returned=f.sent.find(event=>event.item?.type==='function_call_output');assert.equal(JSON.parse(returned.item.output).localModelAnswer,'37');
});

test('an explicit voice model choice is preserved and failed inference produces no fabricated chat answer',async()=>{
  const f=fixture();f.client.toolSpecs=[{name:'ollama_chat'}];
  f.gracie.executeTool=async call=>{f.executed.push(call);return {ok:false,error:'Model needs more memory'};};
  await f.client.executeFunctionCalls([{type:'function_call',name:'ollama_chat',call_id:'local-2',arguments:'{"message":"Test","model":"named-local"}'}],Promise.resolve({enabled:false}));
  assert.equal(f.executed[0].arguments.model,'named-local');assert.equal(f.transcripts.filter(entry=>entry.role==='gracie').length,0);
  const returned=f.sent.find(event=>event.item?.type==='function_call_output');assert.equal(JSON.parse(returned.item.output).ok,false);
});
