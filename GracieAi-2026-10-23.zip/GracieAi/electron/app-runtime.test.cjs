const test=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const {createStateStore,validateRuntime,runtimeSource}=require('./app-runtime.cjs');
const {renameWithRetry}=require('./atomic-file.cjs');
const config={storageKey:'test-workbench-v1',schema:{type:'object',properties:{tasks:{type:'array',items:{type:'object',properties:{id:{type:'string'},title:{type:'string'},done:{type:'boolean'}},required:['id','title','done']}},expenses:{type:'array',items:{type:'object',properties:{label:{type:'string'},amount:{type:'number',minimum:0}},required:['label','amount']}},notes:{type:'string'}},required:['tasks','expenses','notes']},initialState:{tasks:[],expenses:[],notes:''},pages:[{buttonId:'nav-tasks',panelId:'tasks'}]};
function storage(){const values=new Map();return {getItem:key=>values.get(key)||null,setItem:(key,value)=>values.set(key,value)};}

test('feature transactions preserve unrelated state and persist across a restart',()=>{
  const saved=storage(),store=createStateStore(config,saved);let notifications=0;store.subscribe(()=>notifications++);
  store.change(data=>data.tasks.push({id:'one',title:'Ship demo',done:false}));store.change(data=>data.expenses.push({label:'License',amount:125.5}));store.change(data=>{data.notes='Reviewed';});
  const restored=createStateStore(config,saved).read();assert.equal(restored.tasks[0].title,'Ship demo');assert.equal(restored.expenses[0].amount,125.5);assert.equal(restored.notes,'Reviewed');assert.equal(notifications,4);
  const detached=store.read();detached.tasks.length=0;assert.equal(store.read().tasks.length,1);
});
test('invalid changes and malformed or wrong-app imports cannot corrupt current state',()=>{
  const saved=storage(),store=createStateStore(config,saved);store.change(data=>{data.notes='Keep me';});const original=saved.getItem(config.storageKey);
  assert.throws(()=>store.change(data=>{data.expenses='wrong';}),/invalid/);assert.throws(()=>store.importData('{broken'));
  assert.throws(()=>store.importData(JSON.stringify({version:1,app:'another-app',data:config.initialState})),/another app/);
  assert.throws(()=>store.importData(JSON.stringify({version:1,app:config.storageKey,data:{...config.initialState,tasks:[{id:'one',title:42,done:false}]}})),/invalid/);
  assert.equal(saved.getItem(config.storageKey),original);assert.equal(store.read().notes,'Keep me');
});
test('backup round trip restores every feature after intervening changes',()=>{
  const store=createStateStore(config,storage());store.change(data=>{data.notes='Original';data.expenses.push({label:'Tools',amount:30});});const backup=store.exportData();store.change(data=>{data.notes='Changed';data.expenses=[];});store.importData(backup);assert.equal(store.read().notes,'Original');assert.equal(store.read().expenses[0].amount,30);
});
test('object patches and immutable recipe returns remain validated transactions that preserve unrelated features',()=>{
  const store=createStateStore(config,storage());store.change({notes:'Keep notes'});store.change(data=>({...data,expenses:[{label:'Tools',amount:10}]}));assert.equal(store.read().notes,'Keep notes');assert.equal(store.read().expenses[0].amount,10);assert.throws(()=>store.change({tasks:'wrong'}),/invalid/);assert.equal(store.read().expenses.length,1);
});
test('feature-scoped writes cannot overwrite unrelated data through a stale whole-state snapshot',()=>{
  const store=createStateStore(config,storage()),tasks=store.forFeature(['tasks']),costs=store.forFeature(['expenses']);const stale=tasks.read();costs.change(data=>data.expenses.push({label:'License',amount:125.5}));stale.tasks.push({id:'one',title:'Ship',done:false});tasks.change(stale);assert.equal(store.read().expenses[0].amount,125.5);assert.equal(store.read().tasks.length,1);assert.throws(()=>store.forFeature(['missing']),/must exist/);
});

test('backup-only features cannot report a silently ignored state change',()=>{
  const store=createStateStore(config,storage()),backup=store.forFeature([]);
  assert.throws(()=>backup.change({notes:'Ignored'}),/no writable state fields/);assert.equal(store.read().notes,'');
  store.change({notes:'Saved'});const exported=backup.exportData();store.change({notes:'Changed'});backup.importData(exported);assert.equal(store.read().notes,'Saved');
});
test('storage failure rolls back the in-memory transaction',()=>{
  const saved=storage(),store=createStateStore(config,saved);saved.setItem=()=>{throw Error('Quota full');};assert.throws(()=>store.change(data=>{data.notes='Unsaved';}),/Quota/);assert.equal(store.read().notes,'');
});
test('corrupt saved data is retained for recovery instead of discarded',()=>{
  const saved=storage();saved.setItem(config.storageKey,'{corrupt');const store=createStateStore(config,saved);assert.match(store.recovery(),/recovery/);assert.equal(saved.getItem(config.storageKey+':recovery'),'{corrupt');assert.equal(saved.getItem(config.storageKey),'{corrupt');
});
test('runtime rejects unsafe schemas and emits complete parseable standalone browser code',()=>{
  assert.throws(()=>validateRuntime({...config,schema:{type:'object',properties:JSON.parse('{"__proto__":{"type":"string"}}')}}),/Unsafe/);
  assert.throws(()=>validateRuntime({...config,pages:[{buttonId:'same',panelId:'same'}]}),/unique/);
  new vm.Script(runtimeSource(config));assert.doesNotMatch(runtimeSource(config),/require\(|TODO/);
});
test('temporary Windows/OneDrive locks retry without deleting the old file',async()=>{
  let attempts=0;const waits=[];await renameWithRetry('temp','saved',{rename:async()=>{if(++attempts<4)throw Object.assign(Error('locked'),{code:'EPERM'});},wait:async ms=>waits.push(ms)});assert.equal(attempts,4);assert.deepEqual(waits,[40,80,160]);
});
test('permanent file errors and persistent locks remain visible failures',async()=>{
  let attempts=0;await assert.rejects(renameWithRetry('temp','saved',{rename:async()=>{attempts++;throw Object.assign(Error('locked'),{code:'EBUSY'});},wait:async()=>{}}),/locked/);assert.equal(attempts,6);
  await assert.rejects(renameWithRetry('temp','saved',{rename:async()=>{throw Object.assign(Error('missing'),{code:'ENOENT'});}}),/missing/);
});
