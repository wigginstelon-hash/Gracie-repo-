const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createLocalTools } = require('./local-tools.cjs');
const { createOllamaClient } = require('./ollama.cjs');
const reply = data => new Response(JSON.stringify(data));

test('project reading is explicit, bounded, and confined to selected nonsecret code files', async t => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'gracie-local-tools-'));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const root = path.join(directory, 'project'); await fs.mkdir(root);
  await fs.writeFile(path.join(root, 'app.ts'), 'export const answer = 42;');
  await fs.writeFile(path.join(root, '.env.local'), 'PRIVATE');
  await fs.writeFile(path.join(root, 'credentials.json'), 'PRIVATE');
  await fs.writeFile(path.join(directory, 'outside.txt'), 'PRIVATE');
  await fs.mkdir(path.join(root, 'node_modules'));
  const tools = createLocalTools(); const enabled = { enabled: true };
  assert.equal((await tools.execute('project_read_file', { path: 'app.ts' }, enabled)).ok, false);
  await tools.setProjectRoot(root);
  assert.equal((await tools.execute('project_read_file', { path: 'app.ts' })).ok, false);
  assert.equal((await tools.execute('project_read_file', { path: 'app.ts' }, { enabled: true, cloud: true })).ok, false);
  assert.equal((await tools.execute('project_read_file', { path: 'app.ts' }, enabled)).content, 'export const answer = 42;');
  assert.deepEqual((await tools.execute('project_list_files', {}, enabled)).files.map(f => f.name), ['app.ts']);
  for (const file of ['../outside.txt', '.env.local', 'credentials.json', path.join(directory, 'outside.txt'), 'app.ts:stream']) {
    assert.equal((await tools.execute('project_read_file', { path: file }, enabled)).ok, false);
  }
  await fs.writeFile(path.join(root, 'huge.txt'), 'a'.repeat(100001));
  assert.equal((await tools.execute('project_read_file', { path: 'huge.txt' }, enabled)).ok, false);
  await t.test('external directory links are rejected',async sub=>{
    try{await fs.symlink(directory, path.join(root, 'outside-link'), process.platform === 'win32' ? 'junction' : 'dir');}catch(error){if(error.code==='EPERM'){sub.skip('Environment blocks creating directory links');return;}throw error;}
    assert.equal((await tools.execute('project_read_file', { path: 'outside-link/outside.txt' }, enabled)).ok, false);
  });
  assert.equal((await tools.execute('terminal_run', { command: 'whoami' }, enabled)).ok, false);
  await tools.setProjectRoot(''); assert.equal(tools.projectStatus().folder, '');
});

test('application requests are allowlisted and require confirmation every time', async () => {
  const launched = []; let approved = false; let confirmations = 0;
  const tools = createLocalTools({ confirmLaunch: async () => { confirmations++; return approved; }, launch: async name => { launched.push(name); } });
  const enabled = { enabled: true };
  assert.equal((await tools.execute('open_application', { app: 'notepad' }, enabled)).ok, false);
  approved = true;
  assert.equal((await tools.execute('open_application', { app: 'calculator' }, enabled)).ok, true);
  assert.equal((await tools.execute('open_application', { app: 'powershell' }, enabled)).ok, false);
  assert.equal((await tools.execute('open_application', { app: 'notepad', arguments: '/c command' }, enabled)).ok, false);
  assert.equal((await tools.execute('open_application', { app: 'notepad', confirmed: true }, enabled)).ok, false);
  assert.equal((await tools.execute('open_application', { app: 'notepad' }, { enabled: true, cloud: true })).ok, false);
  assert.deepEqual(launched, ['calculator']); assert.equal(confirmations, 2);
});

test('Ollama local tool loop sends only allowed tools and returns tool results to selected model', async () => {
  const tools = createLocalTools(); let chats = 0; let last;
  const client = createOllamaClient({ env: {}, localTools: tools, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'local:latest' }] });
    if (url.pathname === '/api/show') return reply({capabilities:['tools']});
    last = JSON.parse(options.body); chats++;
    if (chats === 1) return reply({ message: { content: '', tool_calls: [{ function: { name: 'project_list_files', arguments: {} } }] } });
    return reply({ message: { content: 'Choose a project folder first.' } });
  } });
  const result = await client.chat({ message: 'Show my project files', model: 'local:latest', useLocalTools: true });
  assert.equal(result.content, 'Choose a project folder first.'); assert.equal(chats, 2);
  assert.equal(last.model, 'local:latest'); assert.ok(last.tools.length > 0); assert.ok(last.tools.every(spec => spec.function.name !== 'open_application'));
  assert.equal(last.messages.at(-1).role, 'tool'); assert.match(last.messages.at(-1).content, /Choose a coding folder/);
  assert.equal(result.toolActivity.length, 1);
});

test('tools are omitted when disabled or cloud selected; unexpected tool calls never execute', async () => {
  for (const [name, enabled] of [['local:latest', false], ['gemma4:cloud', true]]) {
    let executed = false;
    const client = createOllamaClient({ env: {}, localTools: { specs: [], execute: async () => { executed = true; } }, fetchImpl: async (url, options) => {
      if (url.pathname === '/api/tags') return reply({ models: [{ name }] });
      assert.equal(JSON.parse(options.body).tools, undefined);
      return reply({ message: { tool_calls: [{ function: { name: 'open_application', arguments: { app: 'notepad' } } }] } });
    } });
    await assert.rejects(client.chat({ message: 'Hello', model: name, useLocalTools: enabled }), /tools are disabled/);
    assert.equal(executed, false);
  }
});

test('local tool loops have a fixed limit', async () => {
  let executed = 0;
  const client = createOllamaClient({ env: {}, localTools: { specs: require('./local-tools.cjs').specs, execute: async () => { executed++; return { ok: true }; } }, fetchImpl: async url => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'local:latest' }] });
    return reply({ message: { tool_calls: [{ function: { name: 'project_list_files', arguments: {} } }] } });
  } });
  await assert.rejects(client.chat({ message: 'List files', model: 'local:latest', useLocalTools: true }), /tool limit/);
  assert.equal(executed, 3);
});

test('resuming a local file edit marks missing tool results uncertain instead of replaying writes',async()=>{
 let executed=false;const client=createOllamaClient({env:{},localTools:{specs:require('./project-editor.cjs').specs,execute:async()=>{executed=true;}},fetchImpl:async(url,options)=>{
  if(url.pathname==='/api/tags')return reply({models:[{name:'local'}]});if(url.pathname==='/api/show')return reply({capabilities:['tools']});
  const body=JSON.parse(options.body),tool=body.messages.find(m=>m.role==='tool');assert.equal(tool.tool_name,'project_write_file');assert.match(tool.content,/unknown completion/);return reply({message:{content:'I need to inspect the file before continuing.'}});
 }});
 await client.chat({message:'Edit my file',model:'local',useLocalTools:true,resumeState:{messages:[{role:'system',content:'Use project tools.'},{role:'user',content:'Edit my file'},{role:'assistant',content:'',tool_calls:[{function:{name:'project_write_file',arguments:{path:'app.js',content:'x',expectedHash:null}}}]}],partial:'Working'}});assert.equal(executed,false);
});
