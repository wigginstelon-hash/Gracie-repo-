const fs=require('node:fs/promises');
const path=require('node:path');
const {fileURLToPath}=require('node:url');
const {execFile}=require('node:child_process');
const categories=['applications','services','tasks','startup','enrollment','remoteSettings','ports'];
const allowed=new Set(['systemInventory','textFiles','folderPicker']);
function capabilitiesFor(message){
  const text=String(message);const result=[];
  if(/\b(scan|inventory|diagnostic|inspect)\b/i.test(text)&&/\b(pc|windows|computer|installed|services|registry|remote.management)\b/i.test(text))result.push('systemInventory');
  if(/\b(file|report|editor|export|import|save|open)\b/i.test(text))result.push('textFiles');
  if(/\bfolder\s*(picker|select|browser)|\b(select|choose|pick)\b.{0,25}\bfolder\b/i.test(text))result.push('folderPicker');
  return result;
}
const fixture={scannedAt:'2026-01-01T00:00:00.000Z',findings:[{category:'services',name:'Example remote support service',publisher:'',path:'',status:'Stopped',source:'Win32_Service',explanation:'Name matches a remote-access keyword. Review its publisher and purpose; this is not evidence of a payment lock.',confidence:'needs review'}],checks:categories.map(category=>({category,status:category==='tasks'?'unavailable':'checked',count:category==='services'?1:0,reason:category==='tasks'?'Fixture: permission unavailable':''})),simulation:true};
function instructions(capabilities=[]){
  if(!capabilities.length)return '';
  return '\nNATIVE WINDOWS BACKEND ALREADY IMPLEMENTED. Do not invent PowerShell scripts, servers, endpoints, Node access, or extra backend files. Call only these supplied methods on window.desktop: '+
    (capabilities.includes('systemInventory')?'await window.desktop.scanSystem() returns {scannedAt,findings:[{category,name,publisher,path,status,source,explanation,confidence}],checks:[{category,status,count,reason}],simulation}. Show checks marked unavailable or partial separately from checked. Render all returned observations, with uncertain matches marked needs review. Only call from an explicit Scan button; do not auto-scan at startup. Scanning can take up to two minutes. Show busy state, catch errors and restore controls in finally. The backend never requests elevation or changes system settings. Do not claim absent management from empty or unavailable results. Test fixture contains a service named Example remote support service; tasks are unavailable. ':'')+
    (capabilities.includes('textFiles')?'await window.desktop.openText() opens a native file dialog, returning {canceled:true} or {canceled:false,name,text}; await window.desktop.saveText({text,defaultName}) opens Save As, returning {canceled:true} or {canceled:false,name}. Handle cancellation. Use saveText to export a report from actual scan results. Only call file dialogs from explicit user buttons. ':'')+
    (capabilities.includes('folderPicker')?'await window.desktop.chooseFolder() returns {canceled:true} or {canceled:false,path}. It selects a folder but does not grant arbitrary file operations. ':'')+
    (capabilities.includes('systemInventory')?'TEST FIXTURE COUNTS: '+JSON.stringify({findings:fixture.findings.length,needsReview:fixture.findings.filter(f=>f.confidence==='needs review').length,checked:fixture.checks.filter(c=>c.status==='checked').length,unavailable:fixture.checks.filter(c=>c.status==='unavailable').length,partial:0})+'. Assert completed results; the simulated scan resolves immediately, so a transient Scanning message is not a stable assertion. Never hard-code these fixture counts into application logic. ':'')+
    'In behavior tests these methods use a clearly marked simulated backend; do not assert machine-specific data or that real Windows checks passed. Native data belongs in transient module state unless you define a matching complete state schema. Keep unsupported features explicitly unavailable; never fabricate findings.';
}
function runCategory(category,{run=execFile,platform=process.platform,signal}={}){
  if(!categories.includes(category))return Promise.reject(Error('Unknown inventory category.'));
  if(platform!=='win32')return Promise.reject(Error('Windows inventory requires Windows.'));
  return new Promise((resolve,reject)=>{
    const executable=path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
    run(executable,['-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',path.join(__dirname,'native-inventory.ps1'),'-Category',category],{windowsHide:true,timeout:15000,maxBuffer:4*1024*1024,encoding:'utf8',signal,env:{...process.env,PSModulePath:path.join(process.env.SystemRoot||'C:\\Windows','System32','WindowsPowerShell','v1.0','Modules')}},(error,stdout)=>{
      if(error)return reject(Error(error.killed?'Windows check timed out.':error.message));
      try{const value=JSON.parse(String(stdout).replace(/^\uFEFF/,''));if(!Array.isArray(value.items)||typeof value.status!=='string')throw Error('Invalid inventory response.');resolve(value);}catch(error){reject(Error('Windows check returned invalid data: '+error.message));}
    });
  });
}
async function scanSystem({collect=runCategory,signal}={}){
  const report={scannedAt:new Date().toISOString(),findings:[],checks:[],simulation:false};
  for(const category of categories){
    signal?.throwIfAborted();
    try{const result=await collect(category,{signal});report.findings.push(...result.items.map(item=>({...item,category})));report.checks.push({category,status:result.status,count:result.items.length,reason:result.reason||''});}
    catch(error){if(signal?.aborted)throw error;report.checks.push({category,status:'unavailable',count:0,reason:String(error.message).slice(0,400)});}
  }
  return report;
}
function installNativeHost({ipcMain,dialog,window,root,capabilities=[],channelId,simulation=false,scan=scanSystem}){
  if(capabilities.some(value=>!allowed.has(value)))throw Error('Unknown native capability.');
  if(!/^[a-f0-9-]{36}$/.test(channelId||''))throw Error('Invalid native channel.');
  const handlers=new Map(),controller=new AbortController();let scanning=null,dialogBusy=false;
  const authorize=(event,capability)=>{
    if(event.sender!==window.webContents||event.senderFrame!==window.webContents.mainFrame)throw Error('Native request from an unrelated frame.');
    let file;try{file=fileURLToPath(new URL(event.senderFrame.url));}catch{throw Error('Native request requires local app content.');}
    if(path.resolve(file)!==path.resolve(root,'index.html'))throw Error('Native request outside this app.');
    if(!capabilities.includes(capability))throw Error('This app did not request that native feature.');
  };
  const handle=(name,capability,fn)=>{const channel='gracie-native:'+channelId+':'+name;const handler=async(event,input)=>{authorize(event,capability);return fn(input);};ipcMain.handle(channel,handler);handlers.set(channel,handler);};
  async function withDialog(fn){if(dialogBusy)throw Error('Close the current file dialog first.');dialogBusy=true;try{return await fn();}finally{dialogBusy=false;}}
  handle('scanSystem','systemInventory',()=>{if(simulation)return structuredClone(fixture);if(!scanning)scanning=scan({signal:controller.signal}).finally(()=>{scanning=null;});return scanning;});
  handle('openText','textFiles',()=>withDialog(async()=>{
    if(simulation)return {canceled:true};
    const selected=await dialog.showOpenDialog(window,{properties:['openFile'],filters:[{name:'Text and data',extensions:['txt','json','csv','md','log','html']}]});
    if(selected.canceled||!selected.filePaths?.[0])return {canceled:true};
    const file=selected.filePaths[0],info=await fs.stat(file);if(!info.isFile()||info.size>2*1024*1024)throw Error('Choose a text file smaller than 2 MB.');
    return {canceled:false,name:path.basename(file),text:await fs.readFile(file,'utf8')};
  }));
  handle('saveText','textFiles',input=>withDialog(async()=>{
    if(!input||typeof input.text!=='string'||Buffer.byteLength(input.text,'utf8')>4*1024*1024)throw Error('Export must contain text under 4 MB.');
    if(simulation)return {canceled:true};
    const name=String(input.defaultName||'report.txt').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,100)||'report.txt';
    const selected=await dialog.showSaveDialog(window,{defaultPath:name,properties:['showOverwriteConfirmation']});if(selected.canceled||!selected.filePath)return {canceled:true};
    await fs.writeFile(selected.filePath,input.text,'utf8');return {canceled:false,name:path.basename(selected.filePath)};
  }));
  handle('chooseFolder','folderPicker',()=>withDialog(async()=>{
    if(simulation)return {canceled:true};const selected=await dialog.showOpenDialog(window,{properties:['openDirectory']});return selected.canceled?{canceled:true}:{canceled:false,path:selected.filePaths[0]};
  }));
  const cleanup=()=>{controller.abort();for(const channel of handlers.keys())ipcMain.removeHandler(channel);};window.once('closed',cleanup);return cleanup;
}
module.exports={capabilitiesFor,instructions,scanSystem,runCategory,installNativeHost,fixture,categories};
