const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const imageTypes = new Set(['.png', '.jpg', '.jpeg', '.webp']);
const textTypes = new Set(['.txt','.md','.csv','.tsv','.json','.js','.jsx','.ts','.tsx','.py','.html','.css','.xml','.yaml','.yml','.toml','.log','.sql','.c','.cpp','.h','.cs','.java','.rs','.go']);

function createAttachments(directory, { imageToJpeg, extractPdf, extractDocx } = {}) {
  async function add(file) {
    const stat = await fs.stat(file), name = path.basename(file), ext = path.extname(file).toLowerCase();
    if (!stat.isFile() || stat.size > 12 * 1024 * 1024) throw new Error(`${name}: choose a file under 12 MB.`);
    let text = '', image = '', thumbnail = '', kind = 'document';
    if (imageTypes.has(ext)) {
      if (!imageToJpeg) throw new Error('Image processing is unavailable.');
      const converted = await imageToJpeg(await fs.readFile(file));
      image = converted.image; thumbnail = converted.thumbnail; kind = 'image';
    } else if (ext === '.pdf') text = await extractPdf(await fs.readFile(file));
    else if (ext === '.docx') text = await extractDocx(await fs.readFile(file));
    else if (textTypes.has(ext)) {
      if (stat.size > 1024 * 1024) throw new Error(`${name}: text files must be under 1 MB.`);
      text = await fs.readFile(file, 'utf8');
      if (text.includes('\0')) throw new Error(`${name}: binary files cannot be attached as text.`);
    } else throw new Error(`${name}: use a picture, PDF, Word document, or text/code file.`);
    if (kind !== 'image' && !String(text).trim()) throw new Error(`${name}: no readable text was found. Scanned PDFs need OCR or an image attachment.`);
    const entry = { id: crypto.randomUUID(), name, kind, size: stat.size, text: String(text).slice(0, 60000), image, thumbnail, truncated: String(text).length > 60000 };
    await fs.mkdir(directory, { recursive: true });
    await fs.writeFile(path.join(directory, `${entry.id}.json`), JSON.stringify(entry), { mode: 0o600 });
    return metadata(entry);
  }
  function metadata(entry) { return { id: entry.id, name: entry.name, kind: entry.kind, size: entry.size, thumbnail: entry.thumbnail, truncated: entry.truncated }; }
  async function get(ids) {
    if (!Array.isArray(ids) || ids.length > 6) throw new Error('Attach at most six files per message.');
    const entries = [];
    for (const id of new Set(ids)) {
      if (typeof id !== 'string' || !/^[0-9a-f-]{36}$/.test(id)) throw new Error('Invalid attachment reference.');
      entries.push(JSON.parse(await fs.readFile(path.join(directory, `${id}.json`), 'utf8')));
    }
    if (entries.filter(e => e.kind === 'image').length > 3) throw new Error('Attach at most three pictures per message.');
    return entries;
  }
  function excerpts(entries, query) {
    const terms = new Set(String(query).toLowerCase().match(/[a-z0-9]{4,}/g) || []);
    const budget = Math.max(600, Math.floor(6500 / Math.max(1, entries.filter(e => e.text).length)));
    return entries.filter(e => e.text).map(e => {
      const chunks = e.text.match(/[\s\S]{1,900}/g) || [];
      const ranked = chunks.map((content, index) => ({content,index,score:[...terms].filter(t => content.toLowerCase().includes(t)).length})).sort((a,b) => b.score-a.score || a.index-b.index);
      const selected = ranked.slice(0,Math.max(1,Math.ceil(budget/900))).sort((a,b) => a.index-b.index).map(c=>c.content).join('\n').slice(0,budget);
      return { name: e.name, excerpt: selected, partial: e.truncated || selected.length < e.text.length };
    });
  }
  return { add, get, metadata, excerpts };
}
module.exports = { createAttachments };
