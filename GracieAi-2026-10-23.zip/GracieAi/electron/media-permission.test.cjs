const { test } = require('node:test');
const assert = require('node:assert/strict');
const { allowMedia } = require('./media-permission.cjs');
test('local microphone permission is limited to the trusted main page and audio-only requests', () => {
  const mainContents = {}, trustedUrl = 'file:///gracie/dist/index.html';
  const request = { contents: mainContents, mainContents, trustedUrl, localOnly: true, permission: 'media', details: { isMainFrame: true, requestingUrl: trustedUrl, mediaTypes: ['audio'] } };
  assert.equal(allowMedia(request), true);
  assert.equal(allowMedia({ ...request, contents: {} }), false);
  assert.equal(allowMedia({ ...request, permission: 'geolocation' }), false);
  assert.equal(allowMedia({ ...request, details: { ...request.details, isMainFrame: false } }), false);
  assert.equal(allowMedia({ ...request, details: { ...request.details, requestingUrl: 'https://example.com' } }), false);
  assert.equal(allowMedia({ ...request, details: { ...request.details, mediaTypes: ['video'] } }), false);
  assert.equal(allowMedia({ ...request, details: { ...request.details, mediaTypes: ['audio', 'video'] } }), false);
  assert.equal(allowMedia({ ...request, details: { ...request.details, mediaTypes: [] } }), false);
});
