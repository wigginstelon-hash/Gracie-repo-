const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs/promises');const os=require('node:os');const path=require('node:path');
const {createResearchPlanner,publicTopic}=require('./research-planner.cjs');const {createResearch}=require('./research.cjs');
test('public search extracts real result links and rejects broad off-topic pages',()=>{
  const {parsePublicSearchHtml,relevantResults}=require('./research.cjs');
  const html='<a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fdeveloper.mozilla.org%2Fen-US%2Fdocs%2FWeb%2FAPI%2FWeb_Storage_API&amp;rut=track">Web Storage API - MDN</a><a class="result__snippet">Store data using localStorage and sessionStorage.</a>';
  const results=parsePublicSearchHtml(html);assert.equal(results[0].url,'https://developer.mozilla.org/en-US/docs/Web/API/Web_Storage_API');assert.match(results[0].text,/localStorage/);
  assert.equal(relevantResults([...results,{title:'WhatsApp Web',url:'https://web.whatsapp.com/',text:'Send messages'}],'Web Storage API official specification').length,1);
  assert.equal(relevantResults([{title:'JavaScript tutorial',url:'https://example.com/js',text:'Learn JavaScript'}],'JavaScript localStorage quotas').length,0);
});
test('Auto research keeps greetings, small offline apps and cosmetic edits fast',async()=>{
  let calls=0;const planner=createResearchPlanner({complete:async()=>{calls++;throw Error('Not needed');}});
  for(const input of [{message:'Hello Gracie'},{message:'Build a tiny teal counter with Add and Reset buttons',workMode:'build'},{message:'Make the background blue',workMode:'build'},{message:'What is 9 plus 8?'}])assert.equal((await planner.plan(input)).mode,'off');
  assert.equal(calls,0);
});
test('the selected AI plans focused public research for unfamiliar app features',async()=>{
  let requested;const planner=createResearchPlanner({complete:async input=>{requested=input;return {content:JSON.stringify({mode:'deep',reason:'Check calendar recurrence rules before implementing them.',queries:['RFC 5545 recurrence rule standard','JavaScript calendar recurrence edge cases']})};}});
  const plan=await planner.plan({message:'Build a calendar app with recurring events and time zone changes.',workMode:'build',model:'chosen:cloud'});
  assert.equal(requested.model,'chosen:cloud');assert.equal(plan.mode,'deep');assert.equal(plan.queries.length,2);assert.match(plan.reason,/recurrence/);assert.match(requested.messages[0].content,/untrusted task data/);
});
test('explicit depth/off choices win and current-fact requests cannot silently disable research',async()=>{
  const planner=createResearchPlanner({complete:async()=>({content:'{"mode":"off","queries":[],"reason":"No search"}'})});
  assert.equal((await planner.plan({message:'Research the latest API version',requestedMode:'off'})).mode,'off');
  assert.equal((await planner.plan({message:'A basic notes app',requestedMode:'deep'})).queries.length,3);
  assert.equal((await planner.plan({message:'What is the latest stable version of Electron?'})).mode,'search');
  assert.equal((await planner.plan({message:'Deep research JavaScript date recurrence edge cases'})).mode,'deep');
});
test('malformed, truncated and unavailable planning falls back to bounded useful research; cancellation propagates',async()=>{
  for(const complete of [async()=>({content:'bad JSON'}),async()=>({content:'{}',truncated:true}),async()=>{throw Error('Model busy');}]){
    const plan=await createResearchPlanner({complete}).plan({message:'Build a spaced repetition study app using an evidence-based scheduling algorithm.',workMode:'build'});
    assert.equal(plan.mode,'deep');assert.ok(plan.queries.length<=3);
  }
  const controller=new AbortController();controller.abort();await assert.rejects(createResearchPlanner().plan({message:'Build a calendar',signal:controller.signal}));
});
test('public search topics omit embedded code, credentials, email and local file paths',async()=>{
  const task='Build a calendar with recurrence. C:\\private\\secrets.txt Contact me@example.com api_key=secret-value ```javascript\nconst privateCustomer = "sensitive";\n```';
  const clean=publicTopic(task);assert.match(clean,/calendar with recurrence/);assert.doesNotMatch(clean,/private|secrets|me@example|secret-value|privateCustomer|sensitive/);
  let sent;const planner=createResearchPlanner({complete:async input=>{sent=JSON.stringify(input);return {content:'{"mode":"deep","reason":"Read specs","queries":["Calendar recurrence standard"]}'};}});
  await planner.plan({message:task,workMode:'build'});assert.doesNotMatch(sent,/secret-value|privateCustomer|sensitive|me@example/);
});
test('research follows the planned query angles, prioritizes primary docs and deduplicates source reads',async()=>{
  const queries=[],reads=[];const research=createResearch({env:{},fallbackSearch:async query=>{queries.push(query);return [{title:'Blog',url:'https://example.com/post',text:'snippet'},{title:'Official docs',url:'https://docs.example.org/reference',text:'snippet'}];},readPage:async url=>{reads.push(url);return {url,title:'Loaded',text:'Complete implementation reference'};}});
  const result=await research.collect({query:'calendar recurrence',mode:'deep',queries:['Recurrence standard','JavaScript edge cases']});
  assert.deepEqual(queries,['Recurrence standard','JavaScript edge cases']);assert.equal(reads.length,2);assert.equal(result.sources[0].url,'https://docs.example.org/reference');assert.match(result.sources[0].excerpt,/Complete implementation/);
});
test('research cache survives restart, expires and never suppresses a cancellation',async t=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-research-'));t.after(()=>fs.rm(directory,{recursive:true,force:true}));let time=1000000,calls=0;
  const options={directory,now:()=>time,env:{},fallbackSearch:async()=>{calls++;return [{title:'Docs',url:'https://example.com/docs',text:'Useful reference'}];}};
  assert.equal((await createResearch(options).collect({query:'DOM storage',mode:'search'})).cached,false);
  assert.equal((await createResearch(options).collect({query:'DOM storage',mode:'search'})).cached,true);assert.equal(calls,1);
  time+=21600001;assert.equal((await createResearch(options).collect({query:'DOM storage',mode:'search'})).cached,false);assert.equal(calls,2);
  const controller=new AbortController();controller.abort();await assert.rejects(createResearch(options).collect({query:'DOM storage',mode:'search',signal:controller.signal}));
});
test('time-sensitive research uses a shorter cache lifetime',async t=>{
  const directory=await fs.mkdtemp(path.join(os.tmpdir(),'gracie-research-current-'));t.after(()=>fs.rm(directory,{recursive:true,force:true}));let time=1000000,calls=0;
  const research=createResearch({directory,now:()=>time,env:{},fallbackSearch:async()=>{calls++;return[{title:'Current',url:'https://example.com/current',text:'Current release'}];}});
  await research.collect({query:'Latest release',mode:'search'});time+=900001;await research.collect({query:'Latest release',mode:'search'});assert.equal(calls,2);
});
