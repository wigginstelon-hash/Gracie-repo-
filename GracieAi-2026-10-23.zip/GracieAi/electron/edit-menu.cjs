const { Menu } = require('electron');

function installEditMenu(window) {
  // Frameless windows must retain standard editing shortcuts even without a menu bar.
  window.webContents.on('before-input-event', (event,input)=>{
    if(input.type!=='keyDown'||input.alt||!(input.control||input.meta)||window.isDestroyed())return;
    const key=String(input.key||'').toLowerCase();
    const action=key==='z'?(input.shift?'redo':'undo'):!input.shift?({v:'paste',c:'copy',x:'cut',a:'selectAll',y:'redo'})[key]:null;
    if(action){event.preventDefault();window.webContents[action]();}
  });
  window.webContents.on('context-menu', (_event, params) => {
    if (window.isDestroyed()) return;
    const flags = params.editFlags || {};
    const editable = params.isEditable === true;
    const privateField = params.formControlType === 'input-password';
    const template = [];
    if (editable) {
      template.push(
        { role: 'undo', enabled: Boolean(flags.canUndo) },
        { role: 'redo', enabled: Boolean(flags.canRedo) },
        { type: 'separator' },
        { role: 'cut', enabled: Boolean(flags.canCut) && !privateField },
      );
    }
    if (editable || params.selectionText) {
      template.push({ role: 'copy', enabled: Boolean(flags.canCopy) && !privateField });
    }
    if (editable) {
      template.push(
        { role: 'paste', enabled: Boolean(flags.canPaste) },
        { type: 'separator' },
        { role: 'selectAll', enabled: Boolean(flags.canSelectAll) },
      );
    }
    if (template.length) Menu.buildFromTemplate(template).popup({ window });
  });
}

module.exports = { installEditMenu };
