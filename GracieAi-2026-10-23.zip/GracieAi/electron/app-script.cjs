const {parse}=require('acorn');
const {analyze}=require('eslint-scope');
const globals=require('globals');
const browserNames=[...Object.keys(globals.browser),...Object.keys(globals.es2026),'Gracie'];
function validateBrowserScript(source,{feature=false,stateFields,backup=false}={}){
  let tree;
  try{tree=parse(source,{ecmaVersion:'latest',sourceType:'script',locations:true,ranges:true});}
  catch(error){
    const line=error.loc?.line||1,lines=String(source).split('\n');
    throw new SyntaxError('Invalid JavaScript: '+error.message+'. Repair the actual code, retaining all feature behavior. Nearby source:\n'+lines.slice(Math.max(0,line-3),line+2).map((text,index)=>(Math.max(1,line-2)+index)+': '+text).join('\n'),{cause:error});
  }
  const typeChecks=new Set(),methods=new Map(),apiReferences=new Set(),dialogs=[];
  const property=node=>node.computed?(node.property.type==='Literal'?node.property.value:undefined):node.property.name;
  function bindsGracie(node){
    if(!node)return false;
    if(node.type==='Identifier')return node.name==='Gracie';
    if(node.type==='ObjectPattern')return node.properties.some(item=>bindsGracie(item.value||item.argument));
    if(node.type==='ArrayPattern')return node.elements.some(bindsGracie);
    if(node.type==='AssignmentPattern')return bindsGracie(node.left);
    if(node.type==='RestElement')return bindsGracie(node.argument);
    return false;
  }
  function visit(node){
    if(!node||typeof node!=='object')return;
    if(node.type==='UnaryExpression'&&node.operator==='typeof'&&node.argument.type==='Identifier')typeChecks.add(node.argument);
    if(node.type==='VariableDeclarator'&&node.id.type==='Identifier'&&node.init?.type==='ObjectExpression')for(const item of node.init.properties){if(item.type==='Property'&&(item.method||['FunctionExpression','ArrowFunctionExpression'].includes(item.value.type))){const key=item.key.name||item.key.value;const owners=methods.get(key)||new Set();owners.add(node.id.name);methods.set(key,owners);}}
    if(node.type==='ImportExpression'||node.type==='CallExpression'&&node.callee.type==='Identifier'&&node.callee.name==='require'||node.type==='Identifier'&&['ipcRenderer','child_process'].includes(node.name))throw Error('Use browser APIs for this app, not imports, Node or shell commands.');
    if(feature&&node.type==='VariableDeclarator'&&bindsGracie(node.id))throw Error('The local constant Gracie is already supplied. Keep ephemeral UI variables locally, but do not declare another Gracie.');
    if(node.type==='MemberExpression'&&node.object.type==='Identifier'){
      const object=node.object.name,key=property(node);
      if(object==='Gracie')apiReferences.add(key);
      if(feature&&(['window','globalThis'].includes(object)&&['Gracie','localStorage','sessionStorage'].includes(key)||['localStorage','sessionStorage'].includes(object)||object==='Gracie'&&key==='subscribers'))throw Error('Use the supplied Gracie.read(), change(), subscribe(), exportData() and importData(). Do not implement another state manager, access browser storage directly, or bypass the feature-scoped API.');
      if(object==='process'&&['env','execPath'].includes(key))throw Error('Use browser APIs for this app, not Node or shell commands.');
    }
    if(node.type==='CallExpression'){
      if(node.callee.type==='Identifier'&&['alert','confirm','prompt'].includes(node.callee.name))dialogs.push(node.callee);
      if(node.callee.type==='MemberExpression'&&node.callee.object.type==='Identifier'&&['window','globalThis'].includes(node.callee.object.name)&&['alert','confirm','prompt'].includes(property(node.callee)))dialogs.push(node.callee.object);
    }
    for(const value of Object.values(node))if(Array.isArray(value)){for(const child of value)if(child?.type)visit(child);}else if(value?.type)visit(value);
  }
  visit(tree);
  const scopes=analyze(tree,{ecmaVersion:2026,sourceType:'script',ignoreEval:true,optimistic:true});const unresolved=new Set(scopes.globalScope.through.map(ref=>ref.identifier));scopes.addGlobals(browserNames);
  const missing=[...new Map(scopes.globalScope.through.filter(ref=>!typeChecks.has(ref.identifier)).map(ref=>[ref.identifier.name,ref.identifier])).values()];
  const issues=[];
  const unboundHandlers=feature?scopes.scopes.flatMap(scope=>scope.variables.filter(variable=>/^(?:handle[A-Z_]|on[A-Z_])/.test(variable.name)&&variable.defs.some(def=>def.type==='FunctionName')&&!variable.references.length).map(variable=>variable.name)):[];
  if(unboundHandlers.length)issues.push('Unbound event handlers: '+unboundHandlers.join(', ')+'. These functions are never referenced, so their actions cannot run. Attach each requested action to its actual control, using stable-container event delegation or binding newly created row buttons during rendering.');
  if(missing.length)issues.push('Undefined JavaScript names: '+missing.slice(0,5).map(node=>{const owners=[...(methods.get(node.name)||[])];return node.name+' (line '+node.loc.start.line+(owners.length===1?'; this is an object method: use '+owners[0]+'.'+node.name:'')+')';}).join(', ')+'. Define functions locally or reference their actual object. The host supplies Gracie, not a render function.');
  if(feature&&Array.isArray(stateFields)&&!stateFields.length&&apiReferences.has('change'))issues.push('This feature owns no state fields and cannot call Gracie.change(). For backups use ONLY Gracie.exportData() and Gracie.importData(text), which validate and restore the host backup format for all features. Do not serialize Gracie.read() or implement a second import format.');
  if(feature&&backup&&(apiReferences.has('read')&&!apiReferences.has('exportData')||apiReferences.has('change')&&!apiReferences.has('importData')))issues.push('Backup features must use Gracie.exportData() for export and Gracie.importData(text) for restore. These handle the canonical version/app/data envelope and validate every feature before committing. Do not replace them with JSON.stringify(Gracie.read()) or Gracie.change(parsedData).');
  if(feature&&apiReferences.has('read')&&apiReferences.has('change')&&!apiReferences.has('subscribe'))issues.push('This feature reads and writes shared state but never subscribes. Register its defined render function with Gracie.subscribe(render) once. This immediately renders initial state and refreshes the view after saves, deletes and imports; an initial render() call alone is insufficient.');
  if(feature&&dialogs.some(node=>unresolved.has(node)))issues.push('Blocking alert/confirm/prompt dialogs halt unattended checks. Use inline feedback or an HTML dialog with explicit buttons. Bind dynamic row actions through their stable list container or while creating each row, rather than before rows exist.');
  if(issues.length)throw Error(issues.join('\n'));
  return source;
}
module.exports={validateBrowserScript,validateFeatureScript:(source,options={})=>validateBrowserScript(source,{...options,feature:true})};
