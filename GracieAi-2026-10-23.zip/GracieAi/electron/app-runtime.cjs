function validateSchema(schema,depth=0){
  if(depth<=8&&schema&&Array.isArray(schema.type)){
    if(!schema.type.length||schema.type.length>7||new Set(schema.type).size!==schema.type.length||schema.type.some(type=>typeof type!=='string'))throw Error('Schema type choices must be unique supported type names.');
    for(const type of schema.type)validateSchema({...schema,type},depth);return;
  }
  if(depth>8||!schema||typeof schema!=='object'||!['object','array','string','number','integer','boolean','null'].includes(schema.type))throw Error('The app state needs a supported, bounded schema.');
  if(schema.type==='object'){
    if(!schema.properties||typeof schema.properties!=='object'||Array.isArray(schema.properties)||Object.keys(schema.properties).length>64)throw Error('Object state needs named properties.');
    for(const [key,child] of Object.entries(schema.properties)){if(['__proto__','constructor','prototype'].includes(key))throw Error('Unsafe state field.');validateSchema(child,depth+1);}
    if(schema.required!==undefined&&(!Array.isArray(schema.required)||schema.required.some(key=>typeof key!=='string'||!Object.hasOwn(schema.properties,key))))throw Error('Invalid required state fields.');
  }
  if(schema.type==='array')validateSchema(schema.items,depth+1);
  if(schema.enum!==undefined&&(!Array.isArray(schema.enum)||schema.enum.length>64))throw Error('Invalid state choices.');
}
function validateValue(value,schema,location='state',depth=0){
  if(depth>8)throw Error('Imported data is too deeply nested.');
  const fail=()=>{throw Error(location+' has an invalid value.');};
  if(Array.isArray(schema.type)){
    for(const type of schema.type){try{validateValue(value,{...schema,type},location,depth);return;}catch{}}
    fail();
  }
  if(schema.enum&&!schema.enum.includes(value))fail();
  if(schema.type==='object'){
    if(!value||typeof value!=='object'||Array.isArray(value))fail();
    if(location==='state')for(const key of Object.keys(schema.properties))if(!Object.hasOwn(value,key))fail();
    for(const key of schema.required||[])if(!Object.hasOwn(value,key))fail();
    for(const [key,item] of Object.entries(value)){
      if(['__proto__','constructor','prototype'].includes(key)||!Object.hasOwn(schema.properties,key))fail();
      validateValue(item,schema.properties[key],location+'.'+key,depth+1);
    }
  }else if(schema.type==='array'){
    if(!Array.isArray(value)||value.length>Math.min(10000,Number(schema.maxItems)||10000)||value.length<(Number(schema.minItems)||0))fail();
    value.forEach((item,index)=>validateValue(item,schema.items,location+'['+index+']',depth+1));
  }else if(schema.type==='string'){
    if(typeof value!=='string'||value.length>Math.min(100000,Number(schema.maxLength)||100000)||value.length<(Number(schema.minLength)||0))fail();
  }else if(schema.type==='number'||schema.type==='integer'){
    if(typeof value!=='number'||!Number.isFinite(value)||schema.type==='integer'&&!Number.isInteger(value)||schema.minimum!==undefined&&value<schema.minimum||schema.maximum!==undefined&&value>schema.maximum)fail();
  }else if(schema.type==='boolean'){if(typeof value!=='boolean')fail();}
  else if(value!==null)fail();
}
function validateRuntime(config){
  if(!config||typeof config.storageKey!=='string'||!config.storageKey.trim()||config.storageKey.length>100||!Array.isArray(config.pages)||!config.pages.length||config.pages.length>8)throw Error('The app needs a storage key and navigation contract.');
  validateSchema(config.schema);if(config.schema.type!=='object')throw Error('The app state must be one object with separate feature fields.');validateValue(config.initialState,config.schema);
  for(const key of Object.keys(config.schema.properties))if(!Object.hasOwn(config.initialState,key))throw Error('Initial state must include every feature field: '+key);
  const identifiers=new Set();for(const page of config.pages)for(const key of ['buttonId','panelId']){if(typeof page[key]!=='string'||!/^[A-Za-z][\w:-]{0,79}$/.test(page[key])||identifiers.has(page[key]))throw Error('Navigation IDs must be valid and unique.');identifiers.add(page[key]);}
  return config;
}
function createStateStore(config,storage){
  validateRuntime(config);let state=structuredClone(config.initialState),recovery='',pendingRecovery='';const listeners=new Set();
  const clone=value=>structuredClone(value);
  try{
    const raw=storage.getItem(config.storageKey);
    if(raw){
      try{if(raw.length>2*1024*1024)throw Error('Saved data is too large.');const stored=JSON.parse(raw);if(stored.version!==1||stored.app!==config.storageKey||!stored.data||typeof stored.data!=='object'||Array.isArray(stored.data))throw Error('Saved data belongs to a different app or version.');const restored={...clone(config.initialState),...stored.data};validateValue(restored,config.schema);state=restored;}
      catch(error){recovery='Saved data could not be loaded. Your original data is retained in recovery storage.';try{storage.setItem(config.storageKey+':recovery',raw);}catch{pendingRecovery=raw;recovery='Saved data could not be loaded. The original entry is unchanged; free some storage before saving new data.';}}
    }
  }catch{recovery='Browser storage is unavailable. Changes cannot be saved until storage is available.';}
  function commit(next){
    validateValue(next,config.schema);const encoded=JSON.stringify({version:1,app:config.storageKey,data:next});if(encoded.length>2*1024*1024)throw Error('This app’s saved data exceeds its 2 MB limit. Export a backup and reduce the data.');
    if(pendingRecovery){storage.setItem(config.storageKey+':recovery',pendingRecovery);pendingRecovery='';}storage.setItem(config.storageKey,encoded);state=clone(next);for(const listener of listeners)listener();return clone(state);
  }
  const api={
    read:()=>clone(state),
    change:recipe=>{let next=clone(state);if(typeof recipe==='function'){const returned=recipe(next);if(returned&&typeof returned==='object'&&!Array.isArray(returned))next={...next,...returned};}else if(recipe&&typeof recipe==='object'&&!Array.isArray(recipe))next={...next,...recipe};else throw Error('State changes need a function or object patch.');return commit(next);},
    subscribe:listener=>{listeners.add(listener);listener();return()=>listeners.delete(listener);},
    exportData:()=>JSON.stringify({version:1,app:config.storageKey,data:state},null,2),
    importData:text=>{if(typeof text!=='string'||text.length>2*1024*1024)throw Error('Choose a JSON backup smaller than 2 MB.');const value=JSON.parse(text);if(value.version!==1||value.app!==config.storageKey)throw Error('This backup belongs to another app or version.');return commit(value.data);},
    recovery:()=>recovery,
  };
  api.forFeature=fields=>{
    if(!Array.isArray(fields)||fields.some(field=>!Object.hasOwn(config.schema.properties,field)))throw Error('Feature state fields must exist in the shared schema.');
    return Object.freeze({read:api.read,subscribe:api.subscribe,exportData:api.exportData,importData:api.importData,recovery:api.recovery,change:recipe=>{
      if(!fields.length)throw Error('This feature owns no writable state fields. Use importData() to restore a validated backup for all features.');
      const current=api.read();let partial=Object.fromEntries(fields.map(field=>[field,current[field]]));
      if(typeof recipe==='function'){const returned=recipe(partial);if(returned&&typeof returned==='object'&&!Array.isArray(returned))partial={...partial,...returned};}
      else if(recipe&&typeof recipe==='object'&&!Array.isArray(recipe))partial={...partial,...recipe};else throw Error('State changes need a function or object patch.');
      return api.change(next=>{for(const field of fields)next[field]=partial[field];});
    }});
  };
  return api;
}
function installRuntime(config){
  const store=createStateStore(config,localStorage);Object.defineProperty(window,'Gracie',{value:Object.freeze(store),writable:false,configurable:false});
  const nativeFeedback=new WeakMap();
  document.addEventListener('invalid',event=>{
    const field=event.target,form=field.form;if(!form||!field.validationMessage)return;
    let output=form.querySelector('[role="alert"],[id$="-error"]');
    if(!output&&form.parentElement?.querySelectorAll('form').length===1){const nearby=form.parentElement.querySelectorAll('[role="alert"],[id$="-error"]');if(nearby.length===1)output=nearby[0];}
    if(!output){output=document.createElement('p');output.className='gracie-runtime-error';form.appendChild(output);}
    const previous=nativeFeedback.get(field);
    nativeFeedback.set(field,{output,message:field.validationMessage,display:previous?.display??output.style.getPropertyValue('display'),priority:previous?.priority??output.style.getPropertyPriority('display')});
    output.setAttribute('role','alert');output.textContent=field.validationMessage;output.hidden=false;
    if(getComputedStyle(output).display==='none')output.style.setProperty('display','block','important');
    if(!output.id)output.id='gracie-validation-'+Math.random().toString(36).slice(2);
    const descriptions=new Set((field.getAttribute('aria-describedby')||'').split(/\s+/).filter(Boolean));descriptions.add(output.id);field.setAttribute('aria-describedby',[...descriptions].join(' '));field.setAttribute('aria-invalid','true');event.preventDefault();
  },true);
  document.addEventListener('input',event=>{
    const field=event.target,feedback=nativeFeedback.get(field);if(!feedback||!field.validity?.valid)return;
    field.removeAttribute('aria-invalid');
    if(feedback.output.textContent===feedback.message){feedback.output.textContent='';if(feedback.display)feedback.output.style.setProperty('display',feedback.display,feedback.priority);else feedback.output.style.removeProperty('display');}
    nativeFeedback.delete(field);
  });
  function show(page){
    for(const item of config.pages){
      const panel=document.getElementById(item.panelId),button=document.getElementById(item.buttonId),active=item===page;
      if(!panel||!button)throw Error('Missing navigation control: '+(!panel?item.panelId:item.buttonId));
      panel.hidden=!active;panel.classList.toggle('active',active);panel.classList.toggle('hidden',!active);
      if(active){panel.style.removeProperty('display');if(getComputedStyle(panel).display==='none')panel.style.setProperty('display','block','important');}
      else panel.style.setProperty('display','none','important');
      button.setAttribute('aria-controls',item.panelId);button.setAttribute('aria-current',active?'page':'false');button.classList.toggle('active',active);
    }
  }
  for(const page of config.pages){const button=document.getElementById(page.buttonId);if(!button)throw Error('Missing navigation button: '+page.buttonId);button.setAttribute('type','button');button.addEventListener('click',()=>show(page));}
  show(config.pages[0]);
  if(store.recovery()){const banner=document.createElement('p');banner.setAttribute('role','alert');banner.className='gracie-runtime-error';banner.textContent=store.recovery();document.body.prepend(banner);}
}
function runtimeSource(config){validateRuntime(config);return [validateSchema,validateValue,validateRuntime,createStateStore,installRuntime].map(fn=>fn.toString()).join('\n')+'\ninstallRuntime('+JSON.stringify(config)+');\n';}
module.exports={validateRuntime,validateSchema,validateValue,createStateStore,runtimeSource};
