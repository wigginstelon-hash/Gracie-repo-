const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createOllamaClient } = require('./ollama.cjs');
const { profiles, getProfile } = require('./personalities.cjs');
const reply = data => new Response(JSON.stringify(data));
test('complex local generation uses supported reasoning and an explicit larger context for a compact hybrid model',async()=>{
  const bodies=[];
  const client=createOllamaClient({env:{},resourceCheck:async()=>{},fetchImpl:async(url,options)=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'qwen3.5:9b',size:6550825550,capabilities:['thinking'],details:{family:'qwen35',parameter_size:'9.0B'}}]});
    if(url.pathname==='/api/ps')return reply({models:[]});
    if(url.pathname==='/api/show')return reply({thinking:{values:[false,true],default:true}});
    bodies.push(JSON.parse(options.body));return reply({message:{content:'Complete reply'}});
  }});
  await client.chat({model:'qwen3.5:9b',message:'Hello',fastMode:true});
  await client.complete({model:'qwen3.5:9b',reasoning:true,maxTokens:6500,messages:[{role:'user',content:'x'.repeat(6000)}]});
  assert.equal(bodies[0].think,false);assert.equal(bodies[0].options.temperature,0.7);assert.equal(bodies[1].think,true);assert.equal(bodies[1].options.num_ctx,12288);assert.equal(bodies[1].options.num_predict,6500);assert.equal(bodies[1].options.temperature,0.6);assert.equal(bodies[1].options.top_p,0.95);assert.equal(bodies[1].options.repeat_penalty,1);
});
test('a failed local memory preflight cannot dispatch chat or app generation and never blocks cloud',async()=>{
  let chats=0,guards=0;
  const client=createOllamaClient({env:{},resourceCheck:async()=>{guards++;throw Error('Insufficient working memory');},fetchImpl:async(url)=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'large',size:18e9},{name:'chosen:cloud',remote_host:'https://ollama.com'}]});
    if(url.pathname==='/api/ps')return reply({models:[]});
    chats++;return reply({message:{content:'Cloud reply'}});
  }});
  await assert.rejects(client.chat({model:'large',message:'Hello'}),/working memory/);
  await assert.rejects(client.complete({model:'large',messages:[{role:'user',content:'Build'}]}),/working memory/);
  assert.equal(chats,0);assert.equal(guards,2);
  assert.equal((await client.chat({model:'chosen:cloud',message:'Hello'})).content,'Cloud reply');assert.equal(guards,2);
});
test('chooses installed Gracie model when configured model is missing', async () => {
  const client = createOllamaClient({ env: { OLLAMA_MODEL: 'missing' }, fetchImpl: async () => reply({ models: [{ name: 'gracie-local:latest' }] }) });
  assert.equal((await client.status()).defaultModel, 'gracie-local:latest');
});

test('prefers the tested compact local model as the default while respecting explicit configuration', async () => {
  const models = [{ name: 'gracie-local:latest' }, { name: 'qwen3.5:9b' }];
  const client = createOllamaClient({ env: {}, fetchImpl: async () => reply({ models }) });
  assert.equal((await client.status()).defaultModel, 'qwen3.5:9b');
  const configured = createOllamaClient({ env: { OLLAMA_MODEL: 'gracie-local:latest' }, fetchImpl: async () => reply({ models }) });
  assert.equal((await configured.status()).defaultModel, 'gracie-local:latest');
});
test('passes selected profile, model, bounded history and current message', async () => {
  let body;
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'test' }] });
    body = JSON.parse(options.body); return reply({ message: { content: 'Hello' } });
  } });
  assert.equal((await client.chat({ model: 'test', personality: 'writer', message: 'Hi', history: [{ role: 'system', content: 'bad' }, { role: 'user', content: 'previous' }] })).content, 'Hello');
  assert.match(body.messages[0].content, /clichés/);
  assert.equal(body.messages.length, 3);
  assert.equal(body.messages[2].content, 'Hi');
  assert.equal(body.model, 'test');
  assert.equal(body.think, false);
});
test('rejects remote URLs and accepts IPv6 loopback', () => {
  assert.throws(() => createOllamaClient({ env: { OLLAMA_URL: 'http://example.com' } }).baseUrl(), /this computer/);
  assert.equal(createOllamaClient({ env: { OLLAMA_URL: 'http://[::1]:11434' } }).baseUrl(), 'http://[::1]:11434');
});

test('keeps installed tags and metadata together and routes every selection unchanged', async () => {
  const names = ['huihui_ai/Qwen3.8-abliterated:latest', 'llama3.2-vision:latest', 'gemma4:26b', 'gracie-local:latest'];
  const models = names.map(name => ({ name, size: 7816589186, details: { parameter_size: '10.7B', quantization_level: 'Q4_K_M', family: 'mllama' } }));
  const sent = [];
  const client = createOllamaClient({ env: {},resourceCheck:async()=>{}, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models });
    if (url.pathname === '/api/ps') return reply({models:[]});
    sent.push(JSON.parse(options.body).model);
    return reply({ message: { content: 'Connected' } });
  } });
  const state = await client.status();
  assert.deepEqual(state.models, names);
  assert.equal(state.modelDetails[1].parameters, '10.7B');
  assert.equal(state.modelDetails[1].size, 7816589186);
  for (const model of names) assert.equal((await client.chat({ model, message: 'Hello' })).model, model);
  assert.deepEqual(sent, names);
  await assert.rejects(client.chat({ model: 'removed-model', message: 'Hello' }), /not installed/);
  assert.equal(sent.length, names.length);
});
test('reports offline, empty model library, and missing selection', async () => {
  const offline = createOllamaClient({ env: {}, fetchImpl: async () => { throw new TypeError('fetch failed'); } });
  assert.match((await offline.status()).message, /Open the Ollama/);
  const empty = createOllamaClient({ env: {}, fetchImpl: async () => reply({ models: [] }) });
  assert.equal((await empty.status()).defaultModel, '');
  await assert.rejects(empty.chat({ message: 'Hi', model: 'missing' }), /not installed/);
});
test('deadline also covers response body', async () => {
  const client = createOllamaClient({ env: {}, statusTimeout: 10, fetchImpl: async (_url, { signal }) => ({ ok: true, text: () => new Promise((resolve, reject) => signal.addEventListener('abort', () => reject(new Error('aborted')))) }) });
  assert.match((await client.status()).message, /too long/);
});
test('profile IDs are unique and unknown IDs fall back', () => {
  assert.equal(new Set(profiles.map(p => p.id)).size, 1);
  assert.equal(getProfile('writer').id, 'gracie');
  assert.equal(getProfile('unknown').id, 'gracie');
});

test('streams split UTF-8 chunks before completion and returns the complete visible reply', async () => {
  const chunks = [];
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'test' }] });
    assert.equal(JSON.parse(options.body).stream, true);
    const bytes = new TextEncoder().encode('{"message":{"content":"Hello "},"done":false}\n{"message":{"content":"🌎"},"done":true}\n');
    return new Response(new ReadableStream({ start(c) { c.enqueue(bytes.slice(0, 14)); c.enqueue(bytes.slice(14, bytes.length - 15)); c.enqueue(bytes.slice(bytes.length - 15)); c.close(); } }));
  } });
  const result = await client.chat({ model: 'test', message: 'Hi', onChunk: token => chunks.push(token) });
  assert.equal(result.content, 'Hello 🌎'); assert.deepEqual(chunks, ['Hello ', '🌎']);
});

test('stream interruption and embedded errors are surfaced after preserving emitted content', async () => {
  for (const tail of ['', '{"error":"model runner stopped"}\n']) {
    const chunks = [];
    const client = createOllamaClient({ env: {}, fetchImpl: async url => url.pathname === '/api/tags'
      ? reply({ models: [{ name: 'test' }] }) : new Response('{"message":{"content":"Partial reply"},"done":false}\n' + tail) });
    await assert.rejects(client.chat({ model: 'test', message: 'Hi', onChunk: token => chunks.push(token) }), /interrupted|runner stopped/);
    assert.deepEqual(chunks, ['Partial reply']);
  }
});

test('stopping a reply aborts the underlying Ollama request', async () => {
  const controller = new AbortController();
  let began;
  const started = new Promise(resolve => { began = resolve; });
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, { signal } = {}) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'test' }] });
    began();
    return new Promise((_resolve, reject) => signal.addEventListener('abort', () => reject(new Error('aborted'))));
  } });
  const response = client.chat({ model: 'test', message: 'Hello', signal: controller.signal, onChunk: () => {} });
  await started; controller.abort();
  await assert.rejects(response, /Reply stopped/);
});

test('fast mode bounds context and output, increases prompt batch size, and keeps the selected local model warm', async () => {
  let body;
  const client = createOllamaClient({ env: {}, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'gracie-local:latest' }] });
    body = JSON.parse(options.body); return reply({ message: { content: 'Answer' }, done_reason: 'stop' });
  } });
  const result = await client.chat({ model: 'gracie-local:latest', fastMode: true, message: 'Write a simple add function', memory: 'x'.repeat(3000), history: Array.from({length:12}, () => ({role:'user',content:'y'.repeat(4000)})) });
  assert.equal(body.model, 'gracie-local:latest'); assert.equal(body.keep_alive, '30m');
  assert.equal(body.options.num_batch, 256); assert.equal(body.options.num_predict, 1536);
  assert.equal(body.messages.length, 4); assert.ok(body.messages[1].content.length <= 240);
  assert.ok(body.messages[0].content.length < 1900); assert.equal(result.truncated, false);
  await client.chat({ model: 'gracie-local:latest', fastMode: true, message: 'Hello Gracie', memory: 'PRIVATE OLD CONTEXT', history: [{role:'user',content:'UNRELATED OLD TASK'}] });
  assert.equal(body.messages.length, 2); assert.doesNotMatch(JSON.stringify(body), /PRIVATE OLD CONTEXT|UNRELATED OLD TASK/);
  assert.equal(body.options.num_predict,192,'ordinary greetings retain the short fast-reply budget');
});

test('a length-limited code draft is reported as incomplete instead of returned as finished code',async()=>{
  const client=createOllamaClient({env:{},fetchImpl:async url=>url.pathname==='/api/tags'?reply({models:[{name:'test'}]}):reply({message:{content:'function add(a,b) {'},done_reason:'length'})});
  await assert.rejects(client.chat({model:'test',fastMode:true,message:'Implement a JavaScript function'}),/draft is incomplete/);
});

test('engineering preferences reach normal, fast, cloud and restored conversations without repeating policy blocks',async()=>{
  const bodies=[];
  const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'},{name:'chosen:cloud',remote_host:'https://ollama.com'}]});bodies.push(JSON.parse(options.body));return reply({message:{content:'Reviewed.'}});}});
  for(const input of [{model:'test'},{model:'test',fastMode:true},{model:'chosen:cloud'}])await client.chat({...input,message:'Review this design'});
  for(const body of bodies){assert.match(body.messages[0].content,/complete/);assert.match(body.messages[0].content,/state/);assert.match(body.messages[0].content,/motion/);assert.match(body.messages[0].content,/review/i);}
  const {applyStandards}=require('./engineering-standards.cjs');
  const original={messages:[{role:'system',content:applyStandards('Original capability boundaries',{fast:true})},{role:'user',content:'Review this design'}],contextSize:2048};
  await client.chat({model:'test',message:'Review this design',resumeState:original});
  const restored=bodies.at(-1).messages[0].content;
  assert.match(restored,/Original capability boundaries/);assert.equal(restored.split('[Gracie working standards]').length,2);assert.match(restored,/Tailwind/);
  assert.doesNotMatch(original.messages[0].content,/Tailwind/,'the saved checkpoint is not mutated');
});

function delayedStream(signal, parts) {
  return new Response(new ReadableStream({
    start(controller) {
      let ended = false;
      const timers = parts.map(([delay, part]) => setTimeout(() => {
        if (ended) return;
        controller.enqueue(new TextEncoder().encode(JSON.stringify(part) + '\n'));
        if (part.done) { ended = true; controller.close(); }
      }, delay));
      signal.addEventListener('abort', () => { if (!ended) { ended = true; timers.forEach(clearTimeout); controller.error(new Error('aborted')); } }, { once: true });
    },
  }));
}

test('slow initial loading and ongoing tokens use separate deadlines with no fixed total cutoff', async () => {
  const chunks = [];
  const client = createOllamaClient({ env: {}, chatTimeout: 300, idleTimeout: 160, fetchImpl: async (url, options) => {
    if (url.pathname === '/api/tags') return reply({ models: [{ name: 'test' }] });
    assert.ok(options.dispatcher, 'local requests override hidden HTTP timeouts');
    return delayedStream(options.signal, [[200,{message:{content:'A'}}],[300,{message:{content:'B'}}],[400,{message:{content:'C'},done:true}]]);
  } });
  assert.equal((await client.chat({ model:'test',message:'Hello',onChunk:t=>chunks.push(t) })).content, 'ABC');
  assert.deepEqual(chunks, ['A','B','C']);
});

test('thinking tokens keep the connection alive without showing private thinking', async () => {
  const chunks=[];
  const client=createOllamaClient({env:{},chatTimeout:200,idleTimeout:150,fetchImpl:async(url,options)=>url.pathname==='/api/tags'?reply({models:[{name:'test'}]}):delayedStream(options.signal,[[100,{message:{thinking:'hidden'}}],[200,{message:{thinking:'hidden too'}}],[300,{message:{content:'Answer'},done:true}]])});
  assert.equal((await client.chat({model:'test',message:'Hi',onChunk:t=>chunks.push(t)})).content,'Answer');
  assert.deepEqual(chunks,['Answer']);
});

test('a real stalled stream aborts while preserving the visible partial reply', async () => {
  const chunks=[];
  const client=createOllamaClient({env:{},chatTimeout:500,idleTimeout:50,fetchImpl:async(url,options)=>url.pathname==='/api/tags'?reply({models:[{name:'test'}]}):delayedStream(options.signal,[[10,{message:{content:'Partial'}}]])});
  await assert.rejects(client.chat({model:'test',message:'Hi',onChunk:t=>chunks.push(t)}),/stopped making progress/);
  assert.deepEqual(chunks,['Partial']);
});

test('transport timeout errors are distinguished from an offline Ollama service', async () => {
  const client=createOllamaClient({env:{},fetchImpl:async()=>{throw new TypeError('fetch failed',{cause:{code:'UND_ERR_HEADERS_TIMEOUT'}});}});
  assert.match((await client.status()).message,/connection timed out/);
});

test('model memory and runtime compatibility failures show useful errors without raw file paths', async () => {
  for (const [error, expected] of [['failed to allocate CUDA_Host buffer at C:\\private\\weights',/ran out of memory/],['unknown model architecture: mllama at C:\\private\\weights',/incompatible/]]) {
    const client=createOllamaClient({env:{},fetchImpl:async url=>url.pathname==='/api/tags'?reply({models:[{name:'test'}]}):new Response(JSON.stringify({error}),{status:500})});
    await assert.rejects(client.chat({model:'test',message:'Hi'}),failure=>{assert.match(failure.message,expected);assert.doesNotMatch(failure.message,/private|weights/);return true;});
  }
});

test('normal chat bounds old history and sizes context for the current prompt', async () => {
  let body;
  const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'}]});body=JSON.parse(options.body);return reply({message:{content:'Okay'}});}});
  await client.chat({model:'test',message:'x'.repeat(6000),history:Array.from({length:12},()=>({role:'user',content:'y'.repeat(8000)}))});
  assert.ok(body.messages.slice(1,-1).reduce((n,item)=>n+item.content.length,0)<=6000);
  assert.equal(body.messages.at(-1).content.length,6000);
  assert.equal(body.options.num_ctx,8192);
  assert.equal(body.options.num_batch,256);
});

test('Ollama launch isolates conflicting DLL directories without changing model paths or the parent environment',()=>{
  const {launchEnvironment}=require('./ollama-runtime.cjs');
  const env={Path:'C:\\Windows;C:\\llama.cpp;C:\\Ollama;C:\\Tools',OLLAMA_MODELS:'D:\\My models',OLLAMA_NUM_PARALLEL:'4'};
  const result=launchEnvironment(env,'C:\\Ollama\\ollama.exe',{exists:file=>file==='C:\\llama.cpp\\ggml-base.dll'||file==='C:\\Ollama\\ggml-base.dll'});
  assert.equal(result.Path,'C:\\Windows;C:\\Ollama;C:\\Tools');assert.equal(result.OLLAMA_MODELS,env.OLLAMA_MODELS);assert.equal(result.OLLAMA_NUM_PARALLEL,'1');assert.equal(result.OLLAMA_MAX_LOADED_MODELS,'1');assert.equal(env.OLLAMA_NUM_PARALLEL,'4');
});

test('completion reserves prompt plus output space and leaves cloud context to its provider',()=>{
  const {completionBudget}=require('./ollama-runtime.cjs');
  assert.equal(completionBudget([{content:'x'.repeat(7000)}],2600).num_ctx,8192);
  assert.throws(()=>completionBudget([{content:'x'.repeat(30000)}],4096,8192),/too large/);
  assert.equal(completionBudget([{content:'x'.repeat(30000)}],6500,8192,true).num_ctx,undefined);
});

test('inference is serialized and a cancelled queued request never reaches Ollama',async()=>{
  let running=0,peak=0,calls=0;const controller=new AbortController();
  const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'}]});calls++;peak=Math.max(peak,++running);await new Promise(resolve=>setTimeout(resolve,50));running--;return reply({message:{content:'ok'}});}});
  const first=client.complete({model:'test',messages:[{role:'user',content:'A'}]});
  await new Promise(resolve=>setTimeout(resolve,5));
  const cancelled=client.complete({model:'test',messages:[{role:'user',content:'B'}],signal:controller.signal});
  const third=client.complete({model:'test',messages:[{role:'user',content:'C'}]});
  const rejected=assert.rejects(cancelled);controller.abort();await Promise.all([first,third,rejected]);assert.equal(peak,1);assert.equal(calls,2);
});

test('a transient runner failure retries once with a smaller batch and the same model; memory errors do not retry',async()=>{
  const bodies=[];const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'}]});bodies.push(JSON.parse(options.body));return bodies.length===1?new Response(JSON.stringify({error:'llama-server process has terminated: exit status 1'}),{status:500}):reply({message:{content:'Recovered'}});}});
  assert.equal((await client.complete({model:'test',messages:[{role:'user',content:'Hello'}]})).content,'Recovered');assert.equal(bodies.length,2);assert.equal(bodies[1].model,'test');assert.equal(bodies[1].options.num_batch,64);
  let calls=0;const memory=createOllamaClient({env:{},fetchImpl:async url=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'}]});calls++;return new Response(JSON.stringify({error:'failed to allocate CUDA_Host buffer'}),{status:500});}});
  await assert.rejects(memory.complete({model:'test',messages:[{role:'user',content:'Hello'}]}),/ran out of memory/);assert.equal(calls,1);
});

test('a runner failure after visible text preserves the partial response and is never replayed',async()=>{
  let calls=0;const chunks=[];const client=createOllamaClient({env:{},fetchImpl:async url=>{if(url.pathname==='/api/tags')return reply({models:[{name:'test'}]});calls++;return new Response(JSON.stringify({message:{content:'Partial'}})+'\n'+JSON.stringify({error:'runner crashed unexpectedly'})+'\n');}});
  await assert.rejects(client.complete({model:'test',messages:[{role:'user',content:'Hello'}],onChunk:text=>chunks.push(text)}),/runner stopped/);assert.deepEqual(chunks,['Partial']);assert.equal(calls,1);
});

test('named thinking controls are discovered and cloud inference uses a supported low level instead of false',async()=>{
  const bodies=[];let shows=0;const client=createOllamaClient({env:{},fetchImpl:async(url,options)=>{
    if(url.pathname==='/api/tags')return reply({models:[{name:'gpt-oss:20b-cloud',remote_host:'https://ollama.com',capabilities:['completion','thinking']}]});
    if(url.pathname==='/api/show'){shows++;return reply({thinking:{values:['low','medium','high'],default:'medium'}});}
    bodies.push(JSON.parse(options.body));return reply({message:{content:'{"ok":true}'},done_reason:'stop'});
  }});
  await client.complete({model:'gpt-oss:20b-cloud',messages:[{role:'user',content:'Return JSON'}]});await client.chat({model:'gpt-oss:20b-cloud',message:'Hello'});
  assert.equal(shows,1);assert.ok(bodies.every(body=>body.think==='low'));assert.ok(bodies.every(body=>body.options.num_ctx===undefined));
});

test('a response budget exhausted before visible content is reported as truncated rather than an empty service reply',async()=>{
  const client=createOllamaClient({env:{},fetchImpl:async url=>url.pathname==='/api/tags'?reply({models:[{name:'test'}]}):reply({message:{content:''},done_reason:'length'})});
  const result=await client.complete({model:'test',messages:[{role:'user',content:'Return code'}]});assert.equal(result.truncated,true);assert.equal(result.content,'');
});
