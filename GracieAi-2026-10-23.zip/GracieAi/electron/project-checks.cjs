const fs=require('node:fs/promises');
const path=require('node:path');
const {spawn}=require('node:child_process');
const scripts=new Set(['test','build','typecheck']);
function createProjectChecks({getRoot,isEnabled,timeoutMs=120000,executable=process.execPath,npmCli}={}){
 let busy=false;
 async function run(script,{signal}={}){
  signal?.throwIfAborted();
  if(!scripts.has(script))throw Error('Choose test, build, or typecheck. Command strings are not accepted.');
  const root=getRoot();
  if(!root||!isEnabled())throw Error('Choose a trusted coding folder and enable Allow project checks first.');
  if(busy)throw Error('A project check is already running.');
  busy=true;
  try{
   if(await fs.realpath(root)!==root)throw Error('Coding folder changed; select it again.');
   const packageFile=path.join(root,'package.json');
   const info=await fs.lstat(packageFile);
   if(!info.isFile()||info.isSymbolicLink()||info.size>100000)throw Error('Choose a regular package.json under 100 KB.');
   const pkg=JSON.parse(await fs.readFile(packageFile,'utf8'));
   if(!Object.hasOwn(pkg.scripts||{},script)||typeof pkg.scripts[script]!=='string'||!pkg.scripts[script].trim())throw Error(`This project has no ${script} script in package.json. No check ran.`);
   const candidates=[npmCli,process.env.npm_execpath,path.join(process.env.ProgramFiles||'C:\\Program Files','nodejs','node_modules','npm','bin','npm-cli.js')].filter(Boolean);
   let cli;for(const candidate of candidates)if(path.isAbsolute(candidate)&&path.basename(candidate)==='npm-cli.js'&&await fs.stat(candidate).then(s=>s.isFile()).catch(()=>false)){cli=candidate;break;}
   if(!cli)throw Error('npm was not found. Install Node.js to run this project’s checks.');
   if(root!==getRoot()||!isEnabled())throw Error('Project access changed before the check started.');
   signal?.throwIfAborted();
   return await new Promise((resolve,reject)=>{
    const env={...process.env,ELECTRON_RUN_AS_NODE:'1',CI:'true',FORCE_COLOR:'0',npm_config_update_notifier:'false'};
    delete env.NODE_OPTIONS;delete env.NODE_PATH;delete env.NODE_TEST_CONTEXT;
    for(const key of Object.keys(env))if(/(?:API_KEY|AUTH_TOKEN|ACCESS_TOKEN|SECRET|PASSWORD)$/i.test(key))delete env[key];
    const child=spawn(executable,[cli,'run',script],{cwd:root,env,shell:false,windowsHide:true,stdio:['ignore','pipe','pipe']});
    let output='',truncated=false,timedOut=false,cancelled=false,settled=false,stopping=false,timer,killTimer;
    function append(data){output+=data.toString();if(output.length>12000){output=output.slice(-12000);truncated=true;}}
    child.stdout.on('data',append);child.stderr.on('data',append);
    const finish=(error,code)=>{if(settled)return;settled=true;clearTimeout(timer);clearTimeout(killTimer);signal?.removeEventListener('abort',abort);if(error)return reject(error);resolve({ok:code===0&&!timedOut&&!cancelled,script,exitCode:code,output,truncated,timedOut,cancelled,executed:true,...(code===0&&!timedOut&&!cancelled?{}:{error:cancelled?'Project check cancelled.':timedOut?'Project check timed out.':`Project ${script} failed (exit ${code}).`})});};
    const stop=()=>{
     if(!child.pid||stopping)return;stopping=true;
     if(process.platform==='win32'){
      const killer=spawn(path.join(process.env.SystemRoot||'C:\\Windows','System32','taskkill.exe'),['/PID',String(child.pid),'/T','/F'],{shell:false,windowsHide:true,stdio:'ignore'});
      killer.on('error',()=>child.kill());
     }else child.kill('SIGKILL');
     killTimer=setTimeout(()=>finish(Error('Project check termination could not be confirmed. Inspect running processes before retrying.')),5000);
    };
    const abort=()=>{cancelled=true;stop();};
    child.on('error',error=>finish(error));child.on('close',code=>finish(null,code));
    timer=setTimeout(()=>{timedOut=true;stop();},Math.max(100,Math.min(120000,timeoutMs)));
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
   });
  }finally{busy=false;}
 }
 return {run};
}
module.exports={createProjectChecks};
