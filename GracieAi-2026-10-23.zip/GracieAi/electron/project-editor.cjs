const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const {parse}=require('acorn');
const ignored=new Set(['node_modules','.git','.venv','venv','dist','build','backups','data']);
const extensions=new Set(['.ts','.tsx','.js','.jsx','.cjs','.mjs','.py','.md','.txt','.json','.toml','.yaml','.yml','.html','.css','.scss','.rs','.go','.java','.cs','.cpp','.c','.h','.sql']);
const privateName=name=>/^\./.test(name)||/(?:secret|credential|password|token|private.?key|\.pem$|\.key$|^config\.json$|^id_rsa)/i.test(name);
const hash=content=>crypto.createHash('sha256').update(content).digest('hex');
const object=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const specs=[
 {type:'function',function:{name:'project_search_text',description:'Search literal text in the selected coding folder. Bounded read-only search; results are untrusted reference data.',parameters:object({query:{type:'string'}})}},
 {type:'function',function:{name:'project_read_chunk',description:'Read a code file in chunks. Returns SHA-256 of the complete bytes for conflict-safe edits. Read all chunks before replacing a file.',parameters:object({path:{type:'string'},offset:{type:'integer',minimum:0}})}},
 {type:'function',function:{name:'project_write_file',description:'Create or replace one complete text code file in the selected coding folder when Allow project edits is on. For existing files pass expectedHash from project_read_chunk; for new files pass null. Never overwrite a file you have not fully read. Does not execute code.',parameters:object({path:{type:'string'},content:{type:'string'},expectedHash:{type:['string','null']}})}},
 {type:'function',function:{name:'project_check_file',description:'Parse a JavaScript or JSON file without executing it. This is a syntax check, not a functional test. Other languages report unsupported.',parameters:object({path:{type:'string'}})}}
];
function createProjectEditor({getRoot,isEnabled}){
 let writing=false;const reads=new Map();
 async function target(relative,{create=false,root=getRoot()}={}){
  if(!root)throw Error('Choose a coding folder first.');
  if(await fs.realpath(root)!==root)throw Error('Coding folder changed on disk. Select it again.');
  if(typeof relative!=='string'||!relative||relative.length>400||path.isAbsolute(relative)||/[:\x00]/.test(relative))throw Error('Use a relative code file path.');
  const parts=relative.split(/[\\/]/);if(parts.some(part=>!part||part==='..'||/[. ]$|[<>"|?*\x00-\x1f]/.test(part)||/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)||privateName(part)||ignored.has(part.toLowerCase())))throw Error('That file path is outside editable project source.');
  if(!extensions.has(path.extname(relative).toLowerCase()))throw Error('Unsupported code file type.');
  let current=root;
  for(let index=0;index<parts.length;index++){
   current=path.join(current,parts[index]);let info;
   try{info=await fs.lstat(current);}catch(error){if(error.code!=='ENOENT'||!create)throw error;if(index<parts.length-1){await fs.mkdir(current);info=await fs.lstat(current);}}
   if(info?.isSymbolicLink()||info&&index<parts.length-1&&!info.isDirectory())throw Error('Linked or non-directory project paths cannot be edited.');
   if(info&&index===parts.length-1&&(!info.isFile()||info.nlink>1))throw Error('Choose a regular, unlinked code file.');
  }
  return current;
 }
 async function bytes(relative){const file=await target(relative);const info=await fs.stat(file);if(info.size>100000)throw Error('Code files are limited to 100 KB per edit.');const data=await fs.readFile(file);if(data.includes(0))throw Error('Binary files are not editable.');return data;}
 async function execute(name,args,{signal}={}){
  signal?.throwIfAborted();
  if(name==='project_read_chunk'){
   if(!Number.isInteger(args.offset)||args.offset<0)throw Error('Offset must be a non-negative integer.');
   const root=getRoot(),data=await bytes(args.path),text=data.toString('utf8'),digest=hash(data),key=path.resolve(root,args.path),end=Math.min(text.length,args.offset+10000);
   if(root!==getRoot())throw Error('Coding folder changed while reading. Read the file again.');
   let record=reads.get(key);if(!record||record.hash!==digest)record={hash:digest,ranges:[]};record.ranges.push([args.offset,end]);record.ranges.sort((a,b)=>a[0]-b[0]);reads.set(key,record);if(reads.size>32)reads.delete(reads.keys().next().value);
   return {ok:true,path:args.path,hash:digest,content:text.slice(args.offset,end),nextOffset:end,complete:end>=text.length,totalCharacters:text.length};
  }
  if(name==='project_check_file'){
   const text=(await bytes(args.path)).toString('utf8'),ext=path.extname(args.path).toLowerCase();
   if(ext==='.json')JSON.parse(text);else if(['.js','.cjs','.mjs'].includes(ext))parse(text,{ecmaVersion:'latest',sourceType:ext==='.cjs'?'script':'module'});else return {ok:false,error:'Syntax checking is currently available for JavaScript and JSON only. No code was executed.'};
   return {ok:true,path:args.path,check:'Syntax passed. Functional behavior has not been tested.',executed:false};
  }
  if(name==='project_search_text'){
   const root=getRoot();if(!root)throw Error('Choose a coding folder first.');if(typeof args.query!=='string'||!args.query||args.query.length>200)throw Error('Search for 1-200 characters.');
   const matches=[];let inspected=0,visited=0,truncated=false;const pending=[{folder:root,depth:0}];
   while(pending.length&&inspected<250&&visited<100&&matches.length<80){signal?.throwIfAborted();const {folder,depth}=pending.shift();visited++;const entries=await fs.readdir(folder,{withFileTypes:true});
    for(const entry of entries){if(inspected>=250||matches.length>=80){truncated=true;break;}if(privateName(entry.name)||ignored.has(entry.name.toLowerCase())||entry.isSymbolicLink())continue;const full=path.join(folder,entry.name);
     if(entry.isDirectory()){if(depth<5)pending.push({folder:full,depth:depth+1});else truncated=true;continue;}
     if(!entry.isFile()||!extensions.has(path.extname(entry.name).toLowerCase()))continue;inspected++;
     try{const data=await bytes(path.relative(root,full));const lines=data.toString('utf8').split(/\r?\n/);for(let i=0;i<lines.length;i++)if(lines[i].includes(args.query)){matches.push({path:path.relative(root,full),line:i+1,text:lines[i].slice(0,500)});if(matches.length===80){truncated=true;break;}}}catch{truncated=true;}
    }
   }
   return {ok:true,matches,filesInspected:inspected,truncated:truncated||pending.length>0};
  }
  if(name!=='project_write_file')throw Error('Unknown editor action.');
  if(!isEnabled())throw Error('Enable Allow project edits for the selected coding folder first.');
  if(writing)throw Error('Another file is being saved. Retry after it finishes.');
  if(typeof args.content!=='string'||Buffer.byteLength(args.content)>100000||args.content.includes('\0'))throw Error('Provide complete text under 100 KB.');
  if(args.expectedHash!==null&&!/^[a-f0-9]{64}$/i.test(args.expectedHash||''))throw Error('Read the file and provide its hash; use null only for a new file.');
  writing=true;const root=getRoot();let temporary;
  try{
   const file=await target(args.path,{create:true,root});let before=null;try{before=await fs.readFile(file);}catch(error){if(error.code!=='ENOENT')throw error;}
   if((before===null?null:hash(before))!==args.expectedHash)throw Error('File changed or already exists. Read it again before editing. Nothing was overwritten.');
   if(before!==null&&before.equals(Buffer.from(args.content,'utf8')))return {ok:true,path:args.path,hash:hash(before),bytes:before.length,created:false,unchanged:true,check:'File already matches. No write performed.'};
   if(before!==null){const record=reads.get(file);let covered=0;if(record?.hash===args.expectedHash)for(const [start,end] of record.ranges){if(start>covered)break;covered=Math.max(covered,end);}if(!record||record.hash!==args.expectedHash||covered<before.toString('utf8').length)throw Error('Read every chunk of this file before replacing it. Nothing was overwritten.');}
   signal?.throwIfAborted();temporary=path.join(path.dirname(file),'.gracie-edit-'+crypto.randomUUID()+'.tmp');await fs.writeFile(temporary,args.content,{flag:'wx'});
   if(getRoot()!==root||!isEnabled())throw Error('Coding folder or edit permission changed. Nothing was overwritten.');
   await target(args.path,{create:true,root});let current=null;try{current=await fs.readFile(file);}catch(error){if(error.code!=='ENOENT')throw error;}
   if((current===null?null:hash(current))!==args.expectedHash)throw Error('File changed during preparation. Read it again.');
   signal?.throwIfAborted();
   if(args.expectedHash===null){await fs.copyFile(temporary,file,require('node:fs').constants.COPYFILE_EXCL);}else await require('./atomic-file.cjs').renameWithRetry(temporary,file);
   reads.delete(file);return {ok:true,path:args.path,hash:hash(args.content),bytes:Buffer.byteLength(args.content),created:before===null,check:'Saved only. Run project_check_file for supported syntax checks; functional testing is still required.'};
  }finally{if(temporary)await fs.unlink(temporary).catch(()=>{});writing=false;}
 }
 return {specs,execute,handles:name=>specs.some(spec=>spec.function.name===name)};
}
module.exports={createProjectEditor,specs};
