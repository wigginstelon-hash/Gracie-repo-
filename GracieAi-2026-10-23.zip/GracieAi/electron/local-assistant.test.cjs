const {test}=require('node:test');
const assert=require('node:assert/strict');
const {setupLocalAssistant}=require('./local-assistant.cjs');
const {createOllamaClient}=require('./ollama.cjs');
const {createResearch}=require('./research.cjs');
const reply=data=>new Response(JSON.stringify(data));

test('Gracie local profile reuses installed compact weights, preserves its identity and verifies installation',async()=>{
 let created=false;const requests=[];
 const result=await setupLocalAssistant({fetchImpl:async(url,options)=>{
  requests.push({path:url.pathname,body:options.body&&JSON.parse(options.body)});
  if(url.pathname==='/api/tags')return reply({models:[{name:'qwen3.5:4b',size:3.3e9},...(created?[{name:'gracie-assistant:latest',size:3.3e9}]:[])]});
  assert.equal(url.pathname,'/api/create');created=true;return reply({status:'success'});
 }});
 assert.equal(result.created,true);const body=requests.find(r=>r.path==='/api/create').body;
 assert.equal(body.from,'qwen3.5:4b');assert.match(body.system,/You are Gracie/);assert.equal(body.parameters.num_ctx,4096);
 assert.ok(requests.every(r=>r.path!=='/api/pull'));
});

test('local setup never overwrites an existing profile, downloads missing weights or accepts remote/cloud bases',async()=>{
 let posts=0;const fetchImpl=async(_url,options)=>{if(options.method==='POST')posts++;return reply({models:[{name:'gracie-assistant:latest',size:3e9}]});};
 assert.equal((await setupLocalAssistant({fetchImpl})).created,false);assert.equal(posts,0);
 await assert.rejects(setupLocalAssistant({url:'https://example.com',fetchImpl}),/this computer/);
 await assert.rejects(setupLocalAssistant({baseModel:'foo:cloud',fetchImpl}),/local model names/);
 await assert.rejects(setupLocalAssistant({fetchImpl:async()=>reply({models:[]})}),/No model was downloaded/);
 await assert.rejects(setupLocalAssistant({fetchImpl:async()=>reply({models:[{name:'qwen3.5:4b',size:18e9}]})}),/compact/);
});

test('local setup fails if creation is not confirmed in the installed tag list',async()=>{
 await assert.rejects(setupLocalAssistant({fetchImpl:async url=>url.pathname==='/api/tags'?reply({models:[{name:'qwen3.5:4b',size:3.3e9}]}):reply({status:'success'})}),/did not confirm/);
});

test('Local assistant mode hides cloud aliases and cannot dispatch remote inference or model discovery',async()=>{
 let chatCalls=0;const client=createOllamaClient({env:{GRACIE_LOCAL_ONLY:'1'},resourceCheck:async()=>{},fetchImpl:async(url)=>{
  assert.equal(url.hostname,'127.0.0.1');
  if(url.pathname==='/api/tags')return reply({models:[{name:'gracie-assistant:latest',size:3e9},{name:'remote-alias',remote_host:'https://ollama.com'},{name:'test:cloud'}]});
  if(url.pathname==='/api/ps')return reply({models:[]});chatCalls++;return reply({message:{content:'Local answer'}});
 }});
 const state=await client.status();assert.equal(state.localOnly,true);assert.deepEqual(state.models,['gracie-assistant:latest']);assert.equal(state.defaultModel,'gracie-assistant:latest');
 await assert.rejects(client.chat({model:'test:cloud',message:'Hello'}),/disabled/);
 await assert.rejects(client.complete({model:'test:cloud',messages:[{role:'user',content:'Hello'}]}),/disabled/);
 await assert.rejects(client.chat({model:'remote-alias',message:'Hello'}),/not installed/);
 await assert.rejects(client.library.cloudModels(),/disabled/);assert.throws(()=>client.library.startPull('qwen3:4b'),/Downloads/);
 assert.equal(chatCalls,0);assert.equal((await client.chat({model:'gracie-assistant:latest',message:'Hello'})).content,'Local answer');assert.equal(chatCalls,1);
});

test('local research cannot contact search, fetch references or reuse online cache as a fresh check',async()=>{
 let network=0;const denied=async()=>{network++;throw Error('Network contacted');};
 const research=createResearch({env:{GRACIE_LOCAL_ONLY:'1'},fetchImpl:denied,readPage:denied,fallbackSearch:denied});
 assert.deepEqual((await research.collect({mode:'off'})).sources,[]);
 await assert.rejects(research.collect({mode:'search',query:'weather'}),/disabled/);
 await assert.rejects(research.collect({mode:'off',links:['https://example.com']}),/disabled/);
 await assert.rejects(research.search('weather'),/disabled/);assert.equal(network,0);
});

test('cancellation during model status checks aborts before inference can start',async()=>{
 const controller=new AbortController();let chats=0,started;
 const began=new Promise(resolve=>{started=resolve;});
 const client=createOllamaClient({env:{},fetchImpl:async(url,{signal})=>{
  if(url.pathname==='/api/tags'){started();return new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(Error('aborted')),{once:true}));}
  chats++;return reply({message:{content:'Unexpected'}});
 }});
 const task=client.chat({model:'test',message:'Hello',signal:controller.signal});const stopped=assert.rejects(task,/Reply stopped/);await began;controller.abort();await stopped;assert.equal(chats,0);
});

test('project instructions distinguish concurrency hashes from content and compact weights are the default',async()=>{
 const {projectInstructions}=require('./local-tools.cjs');assert.match(projectInstructions,/content field, not the hash/);
 const client=createOllamaClient({env:{},fetchImpl:async()=>reply({models:[{name:'qwen3.5:9b'},{name:'qwen3.5:4b'},{name:'gracie-local:latest'}]})});
 assert.equal((await client.status()).defaultModel,'qwen3.5:4b');
});

test('tool-call JSON returned as prose never executes an action and is labelled honestly',async()=>{
 let executed=0;const localTools={specs:[{type:'function',function:{name:'project_read_chunk',parameters:{type:'object'}}}],execute:async()=>{executed++;return {ok:true};}};
 const client=createOllamaClient({env:{},resourceCheck:async()=>{},localTools,fetchImpl:async url=>{
  if(url.pathname==='/api/tags')return reply({models:[{name:'text-tool'}]});if(url.pathname==='/api/ps')return reply({models:[]});if(url.pathname==='/api/show')return reply({capabilities:['tools']});
  return reply({message:{content:JSON.stringify({name:'project_read_chunk',arguments:{path:'data.txt'}})}});
 }});
 const result=await client.chat({model:'text-tool',message:'Read data.txt',useLocalTools:true});assert.equal(executed,0);assert.deepEqual(result.toolActivity,[]);assert.match(result.warning,/No tool was executed/);
});

test('ordinary arithmetic without a selected project advertises no filesystem or application tools',async()=>{
 const localTools=require('./local-tools.cjs').createLocalTools();let inference;
 const client=createOllamaClient({env:{},resourceCheck:async()=>{},localTools,fetchImpl:async(url,options)=>{
  if(url.pathname==='/api/tags')return reply({models:[{name:'local'}]});if(url.pathname==='/api/ps')return reply({models:[]});if(url.pathname==='/api/show')return reply({capabilities:['tools']});
  inference=JSON.parse(options.body);return reply({message:{content:'42'}});
 }});
 const result=await client.chat({model:'local',message:'What is 19 plus 23? Reply with only the number.',useLocalTools:true});
 assert.equal(result.content,'42');assert.equal(inference.tools,undefined);assert.deepEqual(result.toolActivity,[]);
});

test('unrequested application calls are rejected before dispatch even if a project is selected',async()=>{
 let dispatched=0;const localTools={specs:require('./local-tools.cjs').specs,projectStatus:()=>({folder:'selected'}),execute:async()=>{dispatched++;return {ok:true};}};
 const client=createOllamaClient({env:{},resourceCheck:async()=>{},localTools,fetchImpl:async url=>{
  if(url.pathname==='/api/tags')return reply({models:[{name:'local'}]});if(url.pathname==='/api/ps')return reply({models:[]});if(url.pathname==='/api/show')return reply({capabilities:['tools']});
  return reply({message:{tool_calls:[{function:{name:'open_application',arguments:{app:'calculator'}}}]}});
 }});
 await assert.rejects(client.chat({model:'local',message:'What is 19 plus 23?',useLocalTools:true}),/unavailable tool/);assert.equal(dispatched,0);
});

test('cancelled application approval halts the task and propagates the request cancellation signal',async()=>{
 let launched=0;const controller=new AbortController();const tools=require('./local-tools.cjs').createLocalTools({confirmLaunch:async(_name,{signal})=>{assert.equal(signal,controller.signal);return false;},launch:async()=>{launched++;}});
 const result=await tools.execute('open_application',{app:'calculator'},{enabled:true,signal:controller.signal});assert.equal(result.haltTask,true);assert.equal(launched,0);
});
