const fs = require('node:fs/promises');
const path = require('node:path');
const { spawn } = require('node:child_process');

function createLocalSpeech({ appRoot, dataDir, speechRoot = path.join(appRoot, 'models', 'speech'), spawnImpl = spawn, platform = process.platform }) {
  const python = path.join(speechRoot, 'venv', 'Scripts', 'python.exe');
  const model = path.join(speechRoot, 'whisper-tiny.en');
  let active;
  async function status() {
    const exists = file => fs.access(file).then(() => true, () => false);
    const runtime = platform === 'win32' && await exists(python);
    return { transcription: runtime && await exists(path.join(model, 'model.bin')) && await exists(path.join(model, 'config.json')) && await exists(path.join(model, 'vocabulary.txt')),
      synthesis: runtime, language: 'English', maxRecordingSeconds: 45 };
  }
  function cancel() { active?.abort(); }
  function run(executable, args, signal) {
    return new Promise((resolve, reject) => {
      signal.throwIfAborted();
      const child = spawnImpl(executable, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'],
        env: { ...process.env, HF_HUB_OFFLINE: '1', HF_HUB_DISABLE_TELEMETRY: '1', PYTHONUTF8: '1' } });
      let stdout = '', stderr = '', settled = false;
      const finish = error => { if (settled) return; settled = true; signal.removeEventListener('abort', abort); error ? reject(error) : resolve(stdout); };
      const abort = () => { child.kill(); };
      signal.addEventListener('abort', abort, { once: true });
      child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
      const receive = (current, chunk) => { const next = current + chunk.toString('utf8'); if (next.length > 1024 * 1024) { child.kill(); finish(Error('Local speech returned too much output.')); } return next; };
      child.stdout.on('data', chunk => { stdout = receive(stdout, chunk); });
      child.stderr.on('data', chunk => { stderr = receive(stderr, chunk); });
      child.once('error', () => finish(Error('The local speech runtime could not start. Run the local speech setup first.')));
      child.once('close', code => finish(signal.aborted ? Error('Local speech stopped.') : code === 0 ? null : Error(stderr.includes('No module named') ? 'Local speech dependencies are missing. Run the local speech setup.' : 'Local speech could not process this request. Check the recording and local speech installation.')));
      if (signal.aborted) abort();
    });
  }
  async function task(operation) {
    if (active) throw Error('Local speech is busy. Stop it before starting another request.');
    const controller = new AbortController(); active = controller;
    const timer = setTimeout(() => controller.abort(), 120000);
    let folder;
    try {
      const temporary = path.join(dataDir, 'speech', 'tmp'); await fs.mkdir(temporary, { recursive: true });
      folder = await fs.mkdtemp(path.join(temporary, 'request-'));
      controller.signal.throwIfAborted();
      return await operation(folder, controller.signal);
    } finally {
      clearTimeout(timer);
      try { if (folder) await fs.rm(folder, { recursive: true, force: true, maxRetries: 3, retryDelay: 50 }); }
      finally { if (active === controller) active = undefined; }
    }
  }
  async function transcribe(input) {
    const extensions = { 'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/wav': 'wav', 'audio/x-wav': 'wav' };
    const type = String(input?.mimeType || '').split(';')[0];
    if (!extensions[type]) throw Error('Use a WebM, Ogg or WAV audio recording.');
    if (typeof input?.audio !== 'string' || !input.audio || input.audio.length > 12 * 1024 * 1024 || !/^[A-Za-z0-9+/]*={0,2}$/.test(input.audio)) throw Error('The audio recording is empty, invalid or too large.');
    const audio = Buffer.from(input.audio, 'base64');
    if (!audio.length || audio.length > 8 * 1024 * 1024) throw Error('Audio recordings must be at most 8 MB.');
    if (!(await status()).transcription) throw Error('Local transcription is not installed. Run the local speech setup first.');
    return task(async (folder, signal) => {
      const recording = path.join(folder, 'recording.' + extensions[type]); await fs.writeFile(recording, audio);
      const output = await run(python, [path.join(appRoot, 'scripts', 'local-transcribe.py'), model, recording], signal);
      const result = JSON.parse(output);
      if (typeof result.text !== 'string' || result.text.length > 16000) throw Error('The local transcription response was invalid.');
      return { text: result.text.trim() };
    });
  }
  async function synthesize(input) {
    if (!(await status()).synthesis) throw Error('Local speech output is not installed. Run the local speech setup first.');
    if (typeof input?.text !== 'string' || !input.text.trim() || input.text.length > 4000) throw Error('Choose between 1 and 4,000 characters to read aloud.');
    return task(async (folder, signal) => {
      const text = path.join(folder, 'text.txt'), output = path.join(folder, 'speech.wav');
      await fs.writeFile(text, input.text, 'utf8');
      await run(python, [path.join(appRoot, 'scripts', 'local-speak.py'), text, output], signal);
      const stat = await fs.stat(output); if (stat.size > 32 * 1024 * 1024) throw Error('The generated speech is too large. Read a shorter reply.');
      return { audio: (await fs.readFile(output)).toString('base64'), mimeType: 'audio/wav' };
    });
  }
  return { status, transcribe, synthesize, cancel };
}
module.exports = { createLocalSpeech };
