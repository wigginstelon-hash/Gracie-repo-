const os=require('node:os');
const {execFile}=require('node:child_process');
const GiB=1024**3;
function assessModelMemory({size,gpuBytes=0,totalBytes,freeBytes,loaded=[],modelName}) {
  const available=Math.max(0,Math.min(totalBytes,freeBytes)-3*GiB);
  if(!Number.isFinite(size)||size<=0)return {allowed:false,available,required:Infinity};
  // Only free VRAM on one GPU. Never assume other models will be evicted.
  const gpuBudget=Math.max(0,gpuBytes-1.5*GiB);
  const resident=modelName&&loaded.find(m=>m.name===modelName||m.model===modelName);
  const host=resident?Math.max(0,(Number(resident.size)||0)-(Number(resident.size_vram)||0)):0;
  const vram=resident?Math.max(0,Number(resident.size_vram)||0):0;
  const required=Math.max(0,size-gpuBudget-vram-host)+1.5*GiB;
  return {allowed:required<=available,required,available,gpuBytes};
}
function createResourceCheck({memory=os,gpuQuery}={}) {
  return async({model,loaded=[]})=>{
    let gpuBytes=0;
    try {
      const output=gpuQuery?await gpuQuery():await new Promise((resolve,reject)=>execFile('nvidia-smi',['--query-gpu=memory.free','--format=csv,noheader,nounits'],{windowsHide:true,timeout:3000,maxBuffer:16000},(error,stdout)=>error?reject(error):resolve(stdout)));
      gpuBytes=Math.max(0,...String(output).trim().split(/\r?\n/).map(line=>(Number(line.trim())||0)*1024**2));
    } catch {} // Unknown GPU must fall back to RAM checks, never bypass them.
    const result=assessModelMemory({size:model?.size,modelName:model?.name,gpuBytes,totalBytes:memory.totalmem(),freeBytes:memory.freemem(),loaded});
    return {...result,estimatedFit:result.allowed,allowed:true,warning:result.allowed?undefined:'This model may exceed currently available memory, or its size is unknown. Ollama will decide whether it can load it. Loading may be slow or fail; Stop remains available.'};
  };
}
module.exports={assessModelMemory,createResourceCheck};
