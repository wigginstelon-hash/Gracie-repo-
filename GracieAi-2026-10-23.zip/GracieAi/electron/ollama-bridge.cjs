const { isCloudTag } = require('./model-library.cjs');

function createOllamaBridge({ client, status = () => client.status() }) {
  let active = null;
  async function run({ message, model, taskId } = {}) {
    if (active) throw Error('A local-model voice request is already running. Wait or disconnect voice to stop it.');
    const prompt = String(message || '').trim();
    if (!prompt || prompt.length > 16000) throw Error('Send a local-model question between 1 and 16,000 characters.');
    const job = { controller: new AbortController(), taskId };
    active = job;
    try {
      const state = await status();
      job.controller.signal.throwIfAborted();
      if (!state.available) throw Error(state.message || 'Ollama is offline. Open Ollama and retry.');
      const chosen = String(model || state.defaultModel || '');
      if (!state.models.includes(chosen)) throw Error('Choose an installed local model in Settings first.');
      if (isCloudTag(chosen) || state.modelDetails?.find(item => item.name === chosen)?.cloud) {
        throw Error('This tool runs local weights. Choose a local model; cloud models remain available in typed Ollama chat.');
      }
      const result = await client.chat({ message: prompt, model: chosen, fastMode: true, useLocalTools: false, signal: job.controller.signal });
      job.controller.signal.throwIfAborted();
      return { ok: true, model: result.model, localModelAnswer: result.content, truncated: result.truncated };
    } finally {
      if (active === job) active = null;
    }
  }
  function stop(taskId) {
    if (active && (!taskId || active.taskId === taskId)) active.controller.abort();
  }
  return { run, stop };
}

module.exports = { createOllamaBridge };
