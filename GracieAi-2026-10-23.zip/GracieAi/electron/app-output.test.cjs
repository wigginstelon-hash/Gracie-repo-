const test = require('node:test'); const assert = require('node:assert/strict');
const fs = require('node:fs/promises'); const path = require('node:path'); const os = require('node:os');
const { createAppOutput } = require('./app-output.cjs');
async function fixture(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'gracie-output-'));
  t.after(async () => { const resolved = await fs.realpath(root); assert.equal(path.dirname(resolved), await fs.realpath(os.tmpdir())); assert.ok(path.basename(resolved).startsWith('gracie-output-')); await fs.rm(resolved,{recursive:true,force:true}); });
  const source = path.join(root,'runtime'); await fs.mkdir(path.join(source,'resources','app'),{recursive:true});
  await fs.writeFile(path.join(source,'GracieApp.exe'),'trusted runtime fixture'); await fs.writeFile(path.join(source,'resources','app','index.html'),'<button>Counter</button>');
  let project = {id:'project-one',title:'Counter / App',readyRevision:1,hasWindows:true};
  const builder = { artifact:async(id,kind)=>{assert.equal(id,project.id);assert.equal(kind,'runnable');return {project:{...project},path:source};},recordOutput:async(_id,output)=>{project={...project,outputFolder:output.folder,outputRevision:output.revision};return {...project};} };
  const launched=[]; const options={configFile:path.join(root,'settings','output.json'),defaultFolder:path.join(root,'Apps'),builder,launch:async executable=>{launched.push(executable);return '';}};
  return {root,source,builder,options,launched,output:createAppOutput(options),revision:n=>{project={...project,readyRevision:n};}};
}
test('finished apps are copied into ready-to-run folders and the selected folder survives restart',async t=>{
  const f=await fixture(t);const destination=path.join(f.root,'Chosen Apps');await fs.mkdir(destination);
  await fs.writeFile(path.join(destination,'existing-user-file.txt'),'keep this'); await f.output.choose(destination);
  const published=await f.output.publish('project-one');assert.equal(path.dirname(published.folder),await fs.realpath(destination));
  assert.equal(await fs.readFile(published.executable,'utf8'),'trusted runtime fixture');assert.equal(await fs.readFile(path.join(published.folder,'resources','app','index.html'),'utf8'),'<button>Counter</button>');
  assert.match(await fs.readFile(path.join(published.folder,'OPEN THIS APP.txt'),'utf8'),/Double-click GracieApp.exe/);
  assert.equal((await f.output.publish('project-one')).folder,published.folder,'repeated clicks reuse the prepared version');
  const restarted=createAppOutput(f.options);assert.equal((await restarted.settings()).folder,await fs.realpath(destination));
  await restarted.run('project-one');assert.deepEqual(f.launched,[published.executable]);assert.equal(await fs.readFile(path.join(destination,'existing-user-file.txt'),'utf8'),'keep this');
});
test('new versions and a changed destination preserve every previous working app',async t=>{
  const f=await fixture(t);const first=await f.output.publish('project-one');f.revision(2);await fs.writeFile(path.join(f.source,'resources','app','index.html'),'Version two');
  const second=await f.output.publish('project-one');assert.notEqual(second.folder,first.folder);
  assert.match(await fs.readFile(path.join(first.folder,'resources','app','index.html'),'utf8'),/Counter/);
  assert.equal(await fs.readFile(path.join(second.folder,'resources','app','index.html'),'utf8'),'Version two');
  const next=path.join(f.root,'Other Apps');await fs.mkdir(next);await f.output.choose(next);const third=await f.output.publish('project-one');assert.equal(path.dirname(third.folder),await fs.realpath(next));assert.notEqual(third.folder,second.folder);
});
test('missing or altered output registration is repaired instead of launching an arbitrary path',async t=>{
  const f=await fixture(t);const first=await f.output.publish('project-one');await fs.writeFile(path.join(first.folder,'.gracie-app.json'),JSON.stringify({projectId:'another-project',revision:1}));
  await f.output.run('project-one');assert.equal(f.launched.length,1);assert.notEqual(f.launched[0],first.executable);
  assert.equal(await fs.readFile(first.executable,'utf8'),'trusted runtime fixture');
});
test('cancelled folder preparation removes only its own staging directory and can be retried',async t=>{
  const f=await fixture(t);const controller=new AbortController();
  await assert.rejects(f.output.publish('project-one',{signal:controller.signal,onProgress:()=>controller.abort()}));
  assert.deepEqual(await fs.readdir((await f.output.settings()).folder),[]);
  assert.ok((await f.output.publish('project-one')).executable.endsWith('GracieApp.exe'));
});
